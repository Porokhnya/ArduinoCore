﻿namespace CoreConfig
{
    partial class SignalEditForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SignalEditForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOK = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.cbSchedule = new System.Windows.Forms.CheckBox();
            this.plSchedule = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dtpTo = new System.Windows.Forms.DateTimePicker();
            this.dtpFrom = new System.Windows.Forms.DateTimePicker();
            this.weekdays = new System.Windows.Forms.CheckedListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cbOperands = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lblDataHint = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tbSensorName = new System.Windows.Forms.TextBox();
            this.tbFrom = new System.Windows.Forms.TextBox();
            this.tbTo = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.dgvActions = new System.Windows.Forms.DataGridView();
            this.colActionType = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.btnTo = new System.Windows.Forms.Button();
            this.btnFrom = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.plSchedule.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvActions)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnOK);
            this.panel1.Controls.Add(this.btnCancel);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 549);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(673, 56);
            this.panel1.TabIndex = 11;
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.LightSalmon;
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.ForeColor = System.Drawing.Color.Black;
            this.btnCancel.Location = new System.Drawing.Point(549, 4);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(112, 37);
            this.btnCancel.TabIndex = 5;
            this.btnCancel.Text = "Отмена";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnOK
            // 
            this.btnOK.BackColor = System.Drawing.Color.LightGreen;
            this.btnOK.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOK.ForeColor = System.Drawing.Color.Black;
            this.btnOK.Location = new System.Drawing.Point(431, 4);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(112, 37);
            this.btnOK.TabIndex = 6;
            this.btnOK.Text = "ОК";
            this.btnOK.UseVisualStyleBackColor = false;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.cbSchedule);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(673, 40);
            this.panel2.TabIndex = 0;
            // 
            // cbSchedule
            // 
            this.cbSchedule.AutoSize = true;
            this.cbSchedule.Checked = true;
            this.cbSchedule.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbSchedule.Location = new System.Drawing.Point(16, 14);
            this.cbSchedule.Name = "cbSchedule";
            this.cbSchedule.Size = new System.Drawing.Size(148, 17);
            this.cbSchedule.TabIndex = 9;
            this.cbSchedule.Text = "Работа по расписанию?";
            this.cbSchedule.UseVisualStyleBackColor = true;
            this.cbSchedule.Click += new System.EventHandler(this.clSchedule_CheckedChanged);
            // 
            // plSchedule
            // 
            this.plSchedule.Controls.Add(this.groupBox1);
            this.plSchedule.Dock = System.Windows.Forms.DockStyle.Top;
            this.plSchedule.Location = new System.Drawing.Point(0, 40);
            this.plSchedule.Name = "plSchedule";
            this.plSchedule.Padding = new System.Windows.Forms.Padding(12, 0, 12, 12);
            this.plSchedule.Size = new System.Drawing.Size(673, 108);
            this.plSchedule.TabIndex = 12;
            this.plSchedule.Visible = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.dtpTo);
            this.groupBox1.Controls.Add(this.dtpFrom);
            this.groupBox1.Controls.Add(this.weekdays);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(12, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(649, 96);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Расписание";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(371, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(139, 13);
            this.label3.TabIndex = 18;
            this.label3.Text = "Время окончания работы:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 13);
            this.label2.TabIndex = 17;
            this.label2.Text = "Время начала работы:";
            // 
            // dtpTo
            // 
            this.dtpTo.CustomFormat = "HH:mm";
            this.dtpTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpTo.Location = new System.Drawing.Point(516, 66);
            this.dtpTo.Name = "dtpTo";
            this.dtpTo.ShowUpDown = true;
            this.dtpTo.Size = new System.Drawing.Size(118, 20);
            this.dtpTo.TabIndex = 16;
            this.dtpTo.Value = new System.DateTime(2018, 1, 27, 0, 0, 0, 0);
            // 
            // dtpFrom
            // 
            this.dtpFrom.CustomFormat = "HH:mm";
            this.dtpFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpFrom.Location = new System.Drawing.Point(138, 66);
            this.dtpFrom.Name = "dtpFrom";
            this.dtpFrom.ShowUpDown = true;
            this.dtpFrom.Size = new System.Drawing.Size(118, 20);
            this.dtpFrom.TabIndex = 15;
            this.dtpFrom.Value = new System.DateTime(2018, 1, 27, 0, 0, 0, 0);
            // 
            // weekdays
            // 
            this.weekdays.CheckOnClick = true;
            this.weekdays.ColumnWidth = 80;
            this.weekdays.FormattingEnabled = true;
            this.weekdays.Items.AddRange(new object[] {
            "ПН",
            "ВТ",
            "СР",
            "ЧТ",
            "ПТ",
            "СБ",
            "ВС"});
            this.weekdays.Location = new System.Drawing.Point(11, 37);
            this.weekdays.MultiColumn = true;
            this.weekdays.Name = "weekdays";
            this.weekdays.Size = new System.Drawing.Size(623, 19);
            this.weekdays.TabIndex = 14;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 13);
            this.label1.TabIndex = 13;
            this.label1.Text = "Дни недели:";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.groupBox2);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 148);
            this.panel3.Name = "panel3";
            this.panel3.Padding = new System.Windows.Forms.Padding(12, 0, 12, 12);
            this.panel3.Size = new System.Drawing.Size(673, 193);
            this.panel3.TabIndex = 13;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnTo);
            this.groupBox2.Controls.Add(this.btnFrom);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.tbTo);
            this.groupBox2.Controls.Add(this.tbFrom);
            this.groupBox2.Controls.Add(this.tbSensorName);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.lblDataHint);
            this.groupBox2.Controls.Add(this.cbOperands);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(12, 0);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox2.Size = new System.Drawing.Size(649, 181);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Настройки";
            // 
            // cbOperands
            // 
            this.cbOperands.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbOperands.FormattingEnabled = true;
            this.cbOperands.Location = new System.Drawing.Point(214, 36);
            this.cbOperands.Name = "cbOperands";
            this.cbOperands.Size = new System.Drawing.Size(420, 21);
            this.cbOperands.TabIndex = 12;
            this.cbOperands.SelectedIndexChanged += new System.EventHandler(this.cbOperands_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(211, 21);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Тип сравнения:";
            // 
            // lblDataHint
            // 
            this.lblDataHint.AutoSize = true;
            this.lblDataHint.Location = new System.Drawing.Point(11, 70);
            this.lblDataHint.Name = "lblDataHint";
            this.lblDataHint.Size = new System.Drawing.Size(101, 13);
            this.lblDataHint.TabIndex = 13;
            this.lblDataHint.Text = "Диапазон данных:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(11, 21);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 13);
            this.label6.TabIndex = 15;
            this.label6.Text = "Имя датчика:";
            // 
            // tbSensorName
            // 
            this.tbSensorName.Location = new System.Drawing.Point(14, 37);
            this.tbSensorName.MaxLength = 9;
            this.tbSensorName.Name = "tbSensorName";
            this.tbSensorName.Size = new System.Drawing.Size(163, 20);
            this.tbSensorName.TabIndex = 16;
            // 
            // tbFrom
            // 
            this.tbFrom.Enabled = false;
            this.tbFrom.Location = new System.Drawing.Point(14, 92);
            this.tbFrom.MaxLength = 50;
            this.tbFrom.Name = "tbFrom";
            this.tbFrom.Size = new System.Drawing.Size(263, 20);
            this.tbFrom.TabIndex = 17;
            // 
            // tbTo
            // 
            this.tbTo.Enabled = false;
            this.tbTo.Location = new System.Drawing.Point(331, 92);
            this.tbTo.MaxLength = 50;
            this.tbTo.Name = "tbTo";
            this.tbTo.Size = new System.Drawing.Size(263, 20);
            this.tbTo.TabIndex = 18;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.SystemColors.Info;
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label7.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label7.Location = new System.Drawing.Point(14, 120);
            this.label7.Name = "label7";
            this.label7.Padding = new System.Windows.Forms.Padding(4);
            this.label7.Size = new System.Drawing.Size(620, 58);
            this.label7.TabIndex = 19;
            this.label7.Text = resources.GetString("label7.Text");
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.groupBox3);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(0, 341);
            this.panel4.Name = "panel4";
            this.panel4.Padding = new System.Windows.Forms.Padding(12, 0, 12, 8);
            this.panel4.Size = new System.Drawing.Size(673, 208);
            this.panel4.TabIndex = 14;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.dgvActions);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox3.Location = new System.Drawing.Point(12, 0);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(12);
            this.groupBox3.Size = new System.Drawing.Size(649, 200);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Действия";
            // 
            // dgvActions
            // 
            this.dgvActions.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dgvActions.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvActions.BackgroundColor = System.Drawing.SystemColors.Window;
            this.dgvActions.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvActions.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colActionType});
            this.dgvActions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvActions.Location = new System.Drawing.Point(12, 25);
            this.dgvActions.MultiSelect = false;
            this.dgvActions.Name = "dgvActions";
            this.dgvActions.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvActions.Size = new System.Drawing.Size(625, 163);
            this.dgvActions.TabIndex = 0;
            this.dgvActions.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgvActions_DataError);
            this.dgvActions.DefaultValuesNeeded += new System.Windows.Forms.DataGridViewRowEventHandler(this.dgvActions_DefaultValuesNeeded);
            // 
            // colActionType
            // 
            this.colActionType.HeaderText = "Действие";
            this.colActionType.Name = "colActionType";
            this.colActionType.Width = 350;
            // 
            // btnTo
            // 
            this.btnTo.BackColor = System.Drawing.Color.LightGreen;
            this.btnTo.Enabled = false;
            this.btnTo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTo.ForeColor = System.Drawing.Color.Black;
            this.btnTo.Image = global::CoreConfig.Properties.Resources.data;
            this.btnTo.Location = new System.Drawing.Point(600, 92);
            this.btnTo.Name = "btnTo";
            this.btnTo.Size = new System.Drawing.Size(34, 20);
            this.btnTo.TabIndex = 20;
            this.btnTo.UseVisualStyleBackColor = false;
            this.btnTo.Click += new System.EventHandler(this.btnTo_Click);
            // 
            // btnFrom
            // 
            this.btnFrom.BackColor = System.Drawing.Color.LightGreen;
            this.btnFrom.Enabled = false;
            this.btnFrom.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFrom.ForeColor = System.Drawing.Color.Black;
            this.btnFrom.Image = global::CoreConfig.Properties.Resources.data;
            this.btnFrom.Location = new System.Drawing.Point(283, 92);
            this.btnFrom.Name = "btnFrom";
            this.btnFrom.Size = new System.Drawing.Size(34, 20);
            this.btnFrom.TabIndex = 14;
            this.btnFrom.UseVisualStyleBackColor = false;
            this.btnFrom.Click += new System.EventHandler(this.btnFrom_Click);
            // 
            // SignalEditForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(673, 605);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.plSchedule);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "SignalEditForm";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Управление сигналом";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.plSchedule.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvActions)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.CheckBox cbSchedule;
        private System.Windows.Forms.Panel plSchedule;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dtpTo;
        private System.Windows.Forms.DateTimePicker dtpFrom;
        private System.Windows.Forms.CheckedListBox weekdays;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox cbOperands;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblDataHint;
        private System.Windows.Forms.TextBox tbTo;
        private System.Windows.Forms.TextBox tbFrom;
        private System.Windows.Forms.TextBox tbSensorName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnFrom;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnTo;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DataGridView dgvActions;
        private System.Windows.Forms.DataGridViewComboBoxColumn colActionType;
    }
}