﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DataGridViewNumericUpDownElements;

namespace CoreConfig
{
    public partial class SignalEditForm : Form
    {
        public SignalEditMode EditMode = SignalEditMode.AddNew;
        public SignalConfigData Signal = null;

        private class OperandHolder
        {
            public SignalOperands Operand = SignalOperands.sopCompareNoData;
            public override string ToString()
            {
                return EnumHelpers.GetEnumDescription(Operand);
            }

            public OperandHolder(SignalOperands op)
            {
                Operand = op;
            }
        }

        private DataGridViewNumericUpDownColumn nudColumn = null;

        

        public SignalEditForm(SignalConfigData _signal = null)
        {
            InitializeComponent();

            FillOperands();

            RecomputeForm(false);

            Signal = _signal;
            if(_signal == null)
            {
                Signal = new SignalConfigData();
            }
            else
            {
                EditMode = SignalEditMode.EditExisting;
                FillForm();
            }

            RecomputeForm(this.cbSchedule.Checked);

            nudColumn = new DataGridViewNumericUpDownColumn();
            nudColumn.HeaderText = "Номер сигнала";
            nudColumn.Width = 180;
            nudColumn.DecimalPlaces = 0;
            nudColumn.Minimum = 0;
            nudColumn.Maximum = 80;
            //nudColumn.DefaultCellStyle.NullValue = "1";

            this.dgvActions.Columns.Add(nudColumn);

            foreach(SignalActions act in Enum.GetValues(typeof(SignalActions)))
            {
                this.colActionType.Items.Add(EnumHelpers.GetEnumDescription(act));
            }

            //this.colActionType.DefaultCellStyle.NullValue = EnumHelpers.GetEnumDescription(SignalActions.saRaiseSignal);

        }

        private void FillOperands()
        {
            foreach (SignalOperands st in Enum.GetValues(typeof(SignalOperands)))
            {
                
                cbOperands.Items.Add(new OperandHolder(st));
            }

            cbOperands.SelectedIndex = 0;

        }

        private void FillForm()
        {
            //TODO: Тут заполняем форму из существующего сигнала!!!

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void clSchedule_CheckedChanged(object sender, EventArgs e)
        {
            RecomputeForm(cbSchedule.Checked);
        }

        private void RecomputeForm(bool val)
        {
            plSchedule.Visible = val;
            int hght = this.ClientSize.Height;
            if (val)
            {
                hght += plSchedule.Height;
            }
            else
            {
                hght -= plSchedule.Height;
            }
            this.ClientSize = new Size(this.ClientSize.Width, hght);

        }

        private void cbOperands_SelectedIndexChanged(object sender, EventArgs e)
        {
            OperandHolder oh = (OperandHolder)cbOperands.Items[cbOperands.SelectedIndex];

            switch(oh.Operand)
            {
                case SignalOperands.sopCompareNoData:
                    tbFrom.Enabled = false;
                    btnFrom.Enabled = false;
                    tbTo.Enabled = false;
                    btnTo.Enabled = false;
                    lblDataHint.Text = "Данные для сравнения игнорируются...";
                    break;

                case SignalOperands.sopInterval:
                    tbFrom.Enabled = true;
                    btnFrom.Enabled = true;
                    tbTo.Enabled = true;
                    btnTo.Enabled = true;
                    lblDataHint.Text = "Интервал данных:";
                    break;

                default:
                    tbFrom.Enabled = true;
                    btnFrom.Enabled = true;
                    tbTo.Enabled = false;
                    btnTo.Enabled = false;
                    lblDataHint.Text = "Данные для сравнения:";
                    break;
            }
        }

        private void btnFrom_Click(object sender, EventArgs e)
        {
            DataConverterForm dcf = new DataConverterForm();
            if(dcf.ShowDialog() == DialogResult.OK)
            {
                this.tbFrom.Text = dcf.DataConverted;
            }
        }

        private void btnTo_Click(object sender, EventArgs e)
        {
            DataConverterForm dcf = new DataConverterForm();
            if (dcf.ShowDialog() == DialogResult.OK)
            {
                this.tbTo.Text = dcf.DataConverted;
            }

        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            // сначала - валидация данных
            if(this.cbSchedule.Checked)
            {
                if(this.weekdays.CheckedItems.Count < 1)
                {
                    MessageBox.Show("Пожалуйста, выберите хотя бы один день недели работы сигнала!","Сообщение",MessageBoxButtons.OK,MessageBoxIcon.Information);
                    return;
                }
            }

            //TODO: проверка других вводов, наличия действий, не забыть также про то, что длина всей записи не может превышать 255 байт !!!

            OperandHolder oh = (OperandHolder)cbOperands.Items[cbOperands.SelectedIndex];

            if(oh.Operand != SignalOperands.sopCompareNoData)
            {
                if(this.tbSensorName.Text.Length > 0 && (this.tbFrom.Text.Length < 2 || this.tbFrom.Text.Length % 2 != 0))
                {
                    MessageBox.Show("Пожалуйста, правильно введите данные для сравнения!", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;

                }
            }

            if(oh.Operand == SignalOperands.sopInterval)
            {
                if (this.tbTo.Text.Length < 2 || this.tbTo.Text.Length % 2 != 0 || this.tbFrom.Text.Length != this.tbTo.Text.Length)
                {
                    MessageBox.Show("Пожалуйста, правильно введите данные для сравнения!", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;

                }
            }

            if (oh.Operand == SignalOperands.sopCompareNoData && this.tbSensorName.Text.Trim().Length < 1)
            {
                MessageBox.Show("Для проверки датчика на отсутствие данных надо указать имя датчика!", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;

            }


            // если имя датчика не назначено, нет данных и не включено расписание - мы не можем добавлять такой сигнал!
            if (this.tbSensorName.Text.Length < 1 && this.tbFrom.Text.Length < 2 && !this.cbSchedule.Checked)
            {
                MessageBox.Show("Для работы без данных и имени датчика надо указать расписание!", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;

            }


            this.Signal.SensorName = this.tbSensorName.Text;
            this.Signal.Operand = oh.Operand;

            if (this.cbSchedule.Checked)
            {
                // есть расписание
                byte daymask = 0;
                for(int i=0;i<this.weekdays.CheckedIndices.Count;i++)
                {
                    byte day = (byte) this.weekdays.CheckedIndices[i];
                    day++; // понедельник начинается не с нуля, а с 1
                    byte mask = (byte) (1 << day);
                    daymask |= mask;
                }

                this.Signal.Daymask = daymask;

                DateTime dtFrom = this.dtpFrom.Value;
                DateTime dtTo = this.dtpTo.Value;

                this.Signal.StartHour = (byte)dtFrom.Hour;
                this.Signal.StartMinute = (byte)dtFrom.Minute;

                this.Signal.EndHour = (byte)dtTo.Hour;
                this.Signal.EndMinute = (byte)dtTo.Minute;

                this.Signal.WorkOnTime = true;

            } // расписание
            else
                this.Signal.WorkOnTime = false;

            if (oh.Operand == SignalOperands.sopCompareNoData)
            {
                // не нужно данных для сравнения, т.к. просто проверяем факт того, что с датчика нет данных
                // на
                this.Signal.Data = null;
            }
            else
            {
                // данные для сравнения нужны только тогда, когда есть имя датчика!
                if (this.tbSensorName.Text.Length > 0)
                {
                    // данные для сравнения нужны, получаем их
                    byte dataLen = Convert.ToByte(this.tbFrom.Text.Length / 2);

                    // создаём массив данных
                    this.Signal.Data = new byte[dataLen * 2];

                    byte writePtr = 0;

                    for (int i = 0; i < dataLen; i++)
                    {
                        // собираем данные
                        string sByte = this.tbFrom.Text.Substring(i * 2, 2);
                        byte bByte = byte.Parse(sByte, System.Globalization.NumberStyles.HexNumber);
                        this.Signal.Data[writePtr] = bByte;
                        writePtr++;
                    }

                    if (oh.Operand == SignalOperands.sopInterval)
                    {
                        // для интервала - у нас данные лежат во втором поле
                        for (int i = 0; i < dataLen; i++)
                        {
                            // собираем данные
                            string sByte = this.tbTo.Text.Substring(i * 2, 2);
                            byte bByte = byte.Parse(sByte, System.Globalization.NumberStyles.HexNumber);
                            this.Signal.Data[writePtr] = bByte;
                            writePtr++;
                        }
                    }
                    else // операнды, кроме операнда интервала
                    {
                        // просто дублируем пустыми байтами вторую половину данных
                        for (int i = 0; i < dataLen; i++)
                        {
                            this.Signal.Data[writePtr] = 0;
                            writePtr++;
                        }
                    } // операнды, кроме операнда интервала

                } // has sensor name

            } // операнды, исключая операнд "нет данных с датчика"

            // данные для сравнения собрали, можем работать дальше

            // Тут сохранение действий

            this.Signal.Actions.Clear();

            for(int i=0;i<this.dgvActions.Rows.Count;i++)
            {
                
                if (this.dgvActions.Rows[i].Cells[0].Value != null)
                {
                    if (this.dgvActions.Rows[i].IsNewRow)
                        continue;

                    try
                    {
                        string actionStr = this.dgvActions.Rows[i].Cells[0].Value.ToString();
                        string signalNumberStr = this.dgvActions.Rows[i].Cells[1].Value.ToString();

                        SignalActions act = EnumHelpers.GetValueFromDescription<SignalActions>(actionStr);
                        byte signalNumber = Convert.ToByte(signalNumberStr);

                        SignalOneAction sact = new SignalOneAction();
                        sact.Action = act;
                        sact.ActionData = new byte[1];
                        sact.ActionData[0] = signalNumber;

                        this.Signal.Actions.Add(sact);

                    } catch{ }
                }
            }

            DialogResult = DialogResult.OK;
        }

        private void dgvActions_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            e.Cancel = true;
        }

        private void dgvActions_DefaultValuesNeeded(object sender, DataGridViewRowEventArgs e)
        {
            e.Row.Cells[0].Value = EnumHelpers.GetEnumDescription(SignalActions.saRaiseSignal);
            e.Row.Cells[1].Value = "1";
        }
    }
}
