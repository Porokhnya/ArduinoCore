﻿namespace CoreConfig
{
    partial class DataConverterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnOK = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.cbDataType = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.nudTemperatureEditor = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.nudHumidityEditor = new System.Windows.Forms.NumericUpDown();
            this.nudLuminosityEditor = new System.Windows.Forms.NumericUpDown();
            this.cbDigitalportEditor = new System.Windows.Forms.ComboBox();
            this.nudAnalogEditor = new System.Windows.Forms.NumericUpDown();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudTemperatureEditor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudHumidityEditor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudLuminosityEditor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudAnalogEditor)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnOK);
            this.panel1.Controls.Add(this.btnCancel);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 102);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(303, 56);
            this.panel1.TabIndex = 12;
            // 
            // btnOK
            // 
            this.btnOK.BackColor = System.Drawing.Color.LightGreen;
            this.btnOK.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOK.ForeColor = System.Drawing.Color.Black;
            this.btnOK.Location = new System.Drawing.Point(59, 7);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(112, 37);
            this.btnOK.TabIndex = 6;
            this.btnOK.Text = "ОК";
            this.btnOK.UseVisualStyleBackColor = false;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.LightSalmon;
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.ForeColor = System.Drawing.Color.Black;
            this.btnCancel.Location = new System.Drawing.Point(177, 7);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(112, 37);
            this.btnCancel.TabIndex = 5;
            this.btnCancel.Text = "Отмена";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // cbDataType
            // 
            this.cbDataType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbDataType.FormattingEnabled = true;
            this.cbDataType.Items.AddRange(new object[] {
            "Температура",
            "Влажность",
            "Освещённость",
            "Состояние цифрового порта",
            "Состояние аналогового порта"});
            this.cbDataType.Location = new System.Drawing.Point(16, 27);
            this.cbDataType.Name = "cbDataType";
            this.cbDataType.Size = new System.Drawing.Size(273, 21);
            this.cbDataType.TabIndex = 0;
            this.cbDataType.SelectedIndexChanged += new System.EventHandler(this.cbDataType_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 12);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 13);
            this.label4.TabIndex = 13;
            this.label4.Text = "Тип данных:";
            // 
            // nudTemperatureEditor
            // 
            this.nudTemperatureEditor.DecimalPlaces = 2;
            this.nudTemperatureEditor.Increment = new decimal(new int[] {
            25,
            0,
            0,
            131072});
            this.nudTemperatureEditor.Location = new System.Drawing.Point(169, 63);
            this.nudTemperatureEditor.Maximum = new decimal(new int[] {
            128,
            0,
            0,
            0});
            this.nudTemperatureEditor.Minimum = new decimal(new int[] {
            127,
            0,
            0,
            -2147483648});
            this.nudTemperatureEditor.Name = "nudTemperatureEditor";
            this.nudTemperatureEditor.Size = new System.Drawing.Size(120, 20);
            this.nudTemperatureEditor.TabIndex = 15;
            this.nudTemperatureEditor.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 65);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 13);
            this.label1.TabIndex = 16;
            this.label1.Text = "Выбор данных:";
            // 
            // nudHumidityEditor
            // 
            this.nudHumidityEditor.DecimalPlaces = 2;
            this.nudHumidityEditor.Increment = new decimal(new int[] {
            25,
            0,
            0,
            131072});
            this.nudHumidityEditor.Location = new System.Drawing.Point(169, 63);
            this.nudHumidityEditor.Name = "nudHumidityEditor";
            this.nudHumidityEditor.Size = new System.Drawing.Size(120, 20);
            this.nudHumidityEditor.TabIndex = 17;
            this.nudHumidityEditor.Visible = false;
            // 
            // nudLuminosityEditor
            // 
            this.nudLuminosityEditor.Increment = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nudLuminosityEditor.Location = new System.Drawing.Point(169, 63);
            this.nudLuminosityEditor.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.nudLuminosityEditor.Name = "nudLuminosityEditor";
            this.nudLuminosityEditor.Size = new System.Drawing.Size(120, 20);
            this.nudLuminosityEditor.TabIndex = 18;
            // 
            // cbDigitalportEditor
            // 
            this.cbDigitalportEditor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbDigitalportEditor.FormattingEnabled = true;
            this.cbDigitalportEditor.Items.AddRange(new object[] {
            "Низкий",
            "Высокий"});
            this.cbDigitalportEditor.Location = new System.Drawing.Point(169, 63);
            this.cbDigitalportEditor.Name = "cbDigitalportEditor";
            this.cbDigitalportEditor.Size = new System.Drawing.Size(120, 21);
            this.cbDigitalportEditor.TabIndex = 19;
            // 
            // nudAnalogEditor
            // 
            this.nudAnalogEditor.Location = new System.Drawing.Point(169, 63);
            this.nudAnalogEditor.Maximum = new decimal(new int[] {
            1023,
            0,
            0,
            0});
            this.nudAnalogEditor.Name = "nudAnalogEditor";
            this.nudAnalogEditor.Size = new System.Drawing.Size(120, 20);
            this.nudAnalogEditor.TabIndex = 20;
            // 
            // DataConverterForm
            // 
            this.AcceptButton = this.btnOK;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(303, 158);
            this.Controls.Add(this.nudAnalogEditor);
            this.Controls.Add(this.cbDigitalportEditor);
            this.Controls.Add(this.nudLuminosityEditor);
            this.Controls.Add(this.nudHumidityEditor);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.nudTemperatureEditor);
            this.Controls.Add(this.cbDataType);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "DataConverterForm";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Конвертер данных";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.nudTemperatureEditor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudHumidityEditor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudLuminosityEditor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudAnalogEditor)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.ComboBox cbDataType;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown nudTemperatureEditor;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown nudHumidityEditor;
        private System.Windows.Forms.NumericUpDown nudLuminosityEditor;
        private System.Windows.Forms.ComboBox cbDigitalportEditor;
        private System.Windows.Forms.NumericUpDown nudAnalogEditor;
    }
}