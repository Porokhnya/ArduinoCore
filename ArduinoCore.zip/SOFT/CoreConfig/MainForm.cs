﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;

namespace CoreConfig
{
    public partial class MainForm : Form
    {

        private ToolStripMenuItem lastSelectedPort = null;
        private ITransport currentTransport = null;
        private ConnectForm connForm = null;
        private const char PARAM_DELIMITER = '|';
        private const string GET_PREFIX = "GET=";
        private const string SET_PREFIX = "SET=";

        public MainForm()
        {
            InitializeComponent();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        /// <summary>
        /// закрываем форму ожидания соединения
        /// </summary>
        private void EnsureCloseConnectionForm()
        {
            if (connForm != null)
            {
                connForm.DialogResult = System.Windows.Forms.DialogResult.OK;
            }
            connForm = null;
        }


        /// <summary>
        /// Коннектимся к порту
        /// </summary>
        /// <param name="port">Имя порта</param>
        public void StartConnectToPort(string port)
        {
            System.Diagnostics.Debug.Assert(currentTransport == null);

            // создаём новый транспорт
            currentTransport = new SerialPortTransport(port);
            currentTransport.OnConnect = new ConnectResult(OnCOMConnect);
            currentTransport.OnDataReceived = new TransportDataReceived(OnDataFromCOMPort);

            // коннектимся
            currentTransport.Connect();

        }

        /// <summary>
        /// Обрабатываем строку, пришедшую из транспорта COM-порта
        /// </summary>
        /// <param name="line"></param>
        private void OnDataFromCOMPort(byte[] data)
        {
            if (InvokeRequired)
            {
                Invoke((MethodInvoker)delegate { OnDataFromCOMPort(data); });
                return;
            }
            EnsureCloseConnectionForm(); // закрываем форму коннекта, если она ещё не закрыта


            // обрабатываем данные, полученные из порта
            //ProcessPortAnswer(line.Trim());
            ProcessPortAnswer(data);
        }


        // Буфер под ответ с SD-карты
        private List<byte> SDQueryAnswer = new List<byte>();


        /// <summary>
        /// Буфер под ответ с COM-порта
        /// </summary>
        string COMBuffer = "";

        private void ProcessAnswerLine(string line)
        {
            System.Diagnostics.Debug.WriteLine("<= COM: " + line);

            if (line.StartsWith("Core v.")) // нашли загрузку ядра, следовательно, можно писать данные
            {
                Config.Instance.CoreVersion = line;
                coreBootFound = true;
            }

            bool isKnownAnswer = line.StartsWith("OK=") || line.StartsWith("ER=");

            this.AddToLog(line, isKnownAnswer); // добавляем данные в лог

            if (!isKnownAnswer) // нам тут ловить нечего
            {
                return;
            }
            Answer a = new Answer(line);
            this.currentCommand.ParseFunction(a);
            this.currentCommand.ParseFunction = null; // освобождаем
            this.currentCommand.CommandToSend = "";

        }

        private void ShowFileContent(List<byte> content)
        {
            ASCIIEncoding encoding = new ASCIIEncoding();
            string combindedString = encoding.GetString(content.ToArray());
            this.richTextBoxFileView.Text = combindedString;
        }

        /// <summary>
        /// обрабатываем ответ от контроллера
        /// </summary>
        /// <param name="dt">строка, которая пришла из порта</param>
        //private void ProcessPortAnswer(string dt)
        private void ProcessPortAnswer(byte[] dt)
        {
            EnsureCloseConnectionForm(); // закрываем форму коннекта, если она ещё не закрыта

            switch (answerBehaviour)
            {
                case AnswerBehaviour.Normal:
                    {

                        // нормальный режим работы
                        for (int i = 0; i < dt.Length; i++)
                            COMBuffer += (char)dt[i];

                        while (true)
                        {
                            int idx = COMBuffer.IndexOf('\n');
                            if (idx != -1)
                            {
                                string line = COMBuffer.Substring(0, idx);
                                line = line.Trim();
                                COMBuffer = COMBuffer.Substring(idx + 1);

                                ProcessAnswerLine(line);

                            }
                            else
                                break;
                        }
                    }
                    break;

                case AnswerBehaviour.SDCommandFILE:
                    {
                        // вычитываем файл с SD. Признаком окончания файла служат байты [END]\r\n
                        for (int i = 0; i < dt.Length; i++)
                        {
                            this.SDQueryAnswer.Add(dt[i]);
                         //   System.Diagnostics.Debug.Write((char) dt[i]);
                        }

                        if(SDQueryAnswer.Count > 6)
                        {
                            // уже можно проверять на окончание пакета
                            string endOfFile = "";
                            for(int i= SDQueryAnswer.Count-7;i< SDQueryAnswer.Count;i++)
                            {
                                endOfFile += (char)SDQueryAnswer[i];
                            } // for

                            if(endOfFile == "[END]\r\n")
                            {
                                SDQueryAnswer.RemoveRange(SDQueryAnswer.Count - 7, 7);
                                ShowFileContent(SDQueryAnswer);
                                SDQueryAnswer.Clear();

                                this.answerBehaviour = AnswerBehaviour.Normal;
                                this.currentCommand.ParseFunction = null; // освобождаем
                                this.currentCommand.CommandToSend = "";

                                ShowWaitCursor(false);
                                this.btnListSDFiles.Enabled = true;
                                this.treeViewSD.Enabled = true;

                            }

                        } // if
                    }
                    break;

                case AnswerBehaviour.SDCommandLS:
                    {
                        // опрашиваем SD, команда LS
                        for (int i = 0; i < dt.Length; i++)
                            this.SDQueryAnswer.Add(dt[i]);

                        // тут разбиваем по '\n', т.к. ответ на LS - всегда текстовый

                        while(true)
                        { 
                            int newLineIdx = SDQueryAnswer.FindIndex(x => x == '\n');

                            if (newLineIdx != -1)
                            {
                                // нашли перевод строки
                                string lsLine = "";
                                for (int k = 0; k < newLineIdx; k++)
                                {
                                    lsLine += (char)SDQueryAnswer[k];
                                }

                                SDQueryAnswer.RemoveRange(0, newLineIdx + 1);

                                lsLine = lsLine.Trim();
                                System.Diagnostics.Debug.WriteLine("<= COM: " + lsLine);

                               
                                if (lsLine == "[END]") // закончили список!!!
                                {
                                    this.answerBehaviour = AnswerBehaviour.Normal;
                                    this.currentCommand.ParseFunction = null; // освобождаем
                                    this.currentCommand.CommandToSend = "";

                                    this.btnListSDFiles.Enabled = true;

                                    break;

                                }
                                else
                                {
                                    // продолжаем список
                                    AddToLog(lsLine, false);
                                    AddRecordToSDList(lsLine, currentSDParentNode);
                                }
                            } // if
                            else
                                break;
                        }

                    }
                    break;
            }
            

        }


        private void AddRecordToSDList(string line, TreeNode parent = null)
        {
            TreeNodeCollection nodes = this.treeViewSD.Nodes;
            if (parent != null)
            {
                nodes = parent.Nodes;
                parent.Tag = SDNodeTags.TagFolderNode; // говорим, что мы вычитали это дело
                // и удаляем заглушку...
                for(int i=0;i<parent.Nodes.Count;i++)
                {
                    TreeNode child = parent.Nodes[i];
                    SDNodeTags tg = (SDNodeTags)child.Tag;
                    if(tg == SDNodeTags.TagDummyNode)
                    {
                        child.Remove();
                        break;
                    }
                }
            }
            bool isDir = false;
            int dirIdx = line.IndexOf("<DIR>");
            if(dirIdx != -1)
            {
                isDir = true;
                line = line.Substring(0, dirIdx).Trim();
            }
            TreeNode node = nodes.Add(line);
            if(isDir)
            {
                node.ImageIndex = 0;
                node.SelectedImageIndex = 0;
                TreeNode dummy = node.Nodes.Add("вычитываем....");
                dummy.Tag = SDNodeTags.TagDummyNode; // этот узел потом удалим, при перечитывании
                dummy.ImageIndex = -1;

                node.Tag = SDNodeTags.TagFolderUninitedNode; // говорим, что мы не перечитали содержимое папки ещё
            }
            else
            {
                node.ImageIndex = 2;
                node.SelectedImageIndex = node.ImageIndex;
                node.Tag = SDNodeTags.TagFileNode;
            }
        }

        /// <summary>
        /// Обработчик события "Пришла строка из транспортного уровня"
        /// </summary>
        /// <param name="a"></param>
        public delegate void DataParseFunction(Answer a);
        public delegate void BeforeSendFunction();

        /// <summary>
        /// Структура команды на обработку
        /// </summary>
        private struct QueuedCommand
        {
            public string CommandToSend;
            public DataParseFunction ParseFunction;
            public BeforeSendFunction BeforeSend;
        };


        /// <summary>
        /// Помещаем команду в очередь на обработку
        /// </summary>
        /// <param name="cmd">Текстовая команда для контроллера</param>
        /// <param name="act">К какому действию команда привязана</param>
        /// <param name="func">Указатель на функцию-обработчик ответа от контроллера</param>
        public void PushCommandToQueue(string cmd, DataParseFunction func, BeforeSendFunction before = null)
        {
            QueuedCommand q = new QueuedCommand();
            q.CommandToSend = cmd;
            q.ParseFunction = func;
            q.BeforeSend = before;
            if (!commandsQueue.Contains(q))
                commandsQueue.Enqueue(q);


        }

        /// <summary>
        /// Возвращаем команду из очереди
        /// </summary>
        /// <param name="outCmd">Команда, которая получена из очереди</param>
        /// <returns>Возвращаем false, если команд в очереди нет, иначе - true</returns>
        private bool GetCommandFromQeue(ref QueuedCommand outCmd)
        {
            if (commandsQueue.Count < 1)
                return false;

            outCmd = commandsQueue.Dequeue();
            return true;
        }

        /// <summary>
        /// Очередь команд
        /// </summary>
        private Queue<QueuedCommand> commandsQueue = new Queue<QueuedCommand>();

        /// <summary>
        /// текущая команда на обработку
        /// </summary>
        private QueuedCommand currentCommand = new QueuedCommand();

        private Color currentLogItemColor = SystemColors.ControlLight;

        /// <summary>
        /// добавляем строку в лог
        /// </summary>
        /// <param name="line">строка для добавления в лог</param>
        private void AddToLog(string line, bool shouldAddCommandName)
        {

            line = line.Trim();
            if (line.Length < 1)
                return;

            lvLog.BeginUpdate();

            int cnt = this.lvLog.Items.Count;
            if (cnt > 100)
            {
                this.lvLog.Items.RemoveAt(0);
            }

            ListViewItem li = this.lvLog.Items.Add(shouldAddCommandName ? currentCommand.CommandToSend : "");
            li.ImageIndex = 0;
            if (currentLogItemColor == SystemColors.Window)
                currentLogItemColor = SystemColors.ControlLight;
            else
                currentLogItemColor = SystemColors.Window;

            li.BackColor = currentLogItemColor;
            li.SubItems.Add("=> " + line);
            li.EnsureVisible();

            lvLog.EndUpdate();


        }

        /// <summary>
        /// Обрабатываем результат соединения с портом
        /// </summary>
        /// <param name="succ"></param>
        /// <param name="message"></param>
        private void OnCOMConnect(bool succ, string message)
        {
            if (InvokeRequired)
            {
                Invoke((MethodInvoker)delegate { OnCOMConnect(succ, message); });
                return;
            }

            // обнуляем текущее состояние при переконнекте
            //this.currentCommand.ActionToSet = Actions.None;

            if (succ)
            {
                this.btnConnect.ImageIndex = 1;
                this.btnConnect.Text = "Соединено";
                 InitAfterSuccessfullConnect();

            }
            else
            {
                EnsureCloseConnectionForm();
                this.btnConnect.ImageIndex = 0;
                this.btnConnect.Text = "Соединить";
                MessageBox.Show("Не удалось соединиться с портом!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


            if (succ && connForm != null)
            {
                connForm.lblCurrentAction.Text = "Ждём данные из порта...";
            }
        }

        private bool configLoaded = false;

        /// <summary>
        /// Инициализируем необходимое после успешного коннекта
        /// </summary>
        private void InitAfterSuccessfullConnect()
        {
            Config.Instance.Clear();
            this.featuresSettings.Clear();

            configLoaded = false;

            this.btnConnect.ImageIndex = 1;
            this.btnConnect.Text = "Соединено";

            dateTimeFromControllerReceived = false;

            // очищаем очередь
            commandsQueue.Clear();
            this.currentCommand.ParseFunction = null;
            this.currentCommand.CommandToSend = "";
            this.coreBootFound = false;


            // добавляем нужные команды для обработки сразу после коннекта
            PushCommandToQueue(GET_PREFIX + "DATETIME", ParseAskDatetime);
            PushCommandToQueue(GET_PREFIX + "FEATURES", ParseAskFeatures);
            PushCommandToQueue(GET_PREFIX + "FREERAM", ParseAskFreeram);
            PushCommandToQueue(GET_PREFIX + "CPU", ParseAskCPU);
            PushCommandToQueue(GET_PREFIX + "CONFIG", ParseAskConfig);
            PushCommandToQueue(GET_PREFIX + "SENSORS", ParseAskSensors);
            PushCommandToQueue(GET_PREFIX + "STORAGE", ParseAskStorage);

            //            tmWaitDataTimer.Enabled = true; // ждём данные с порта с таймаутом

            InitTreeView();

            ClearSensorsListAndData();


        }

        private void ClearSensorsListAndData()
        {
            this.lvSensorsData.Items.Clear();
            this.lvSensorsList.Items.Clear();

        }

        private bool dateTimeFromControllerReceived = false;
        private DateTime controllerDateTime = DateTime.MinValue;

        private void ParseAskDatetime(Answer a)
        {
            if (a.IsOkAnswer)
            {
                //TODO: пришло время из контроллера!!!
                this.controllerDateTime = DateTime.ParseExact(a.Params[1], "dd.MM.yyyy HH:mm:ss", null);
                dateTimeFromControllerReceived = true;

            }
            else
            {

            }
        }

        private void ParseAskFeatures(Answer a)
        {
            if (a.IsOkAnswer)
            {
                //TODO: пришёл список поддерживаемых транспортов!!!
                featuresSettings.LoRaAvailable = a.Params.Contains("LORA");
                featuresSettings.RS485Available = a.Params.Contains("RS485");
                featuresSettings.ESPAvailable = a.Params.Contains("ESP");
                featuresSettings.SDAvailable = a.Params.Contains("SD");
                featuresSettings.SignalsAvailable = a.Params.Contains("SIG");

                if (featuresSettings.SDAvailable)
                {
                    PushCommandToQueue(GET_PREFIX + "LS", DummyAnswerReceiver, SetSDReadingFlag);
                }
            }
            else
            {

            }
        }

        private void ParseAskFreeram(Answer a)
        {
            if (a.IsOkAnswer)
            {
                //TODO: пришли данные о свободной памяти!!!
                Config.Instance.FreeRAM = Convert.ToInt32(a.Params[1]);
                //this.propertyGridSettings.Refresh();
            }
            else
            {

            }
        }


        private void ParseAskCPU(Answer a)
        {
            if (a.IsOkAnswer)
            {
                if (a.Params[1] == "MEGA")
                    Config.Instance.Board = Boards.Mega;
                else if (a.Params[1] == "DUE")
                    Config.Instance.Board = Boards.Due;
                else if (a.Params[1] == "ESP")
                    Config.Instance.Board = Boards.ESP;
                else
                    Config.Instance.Board = Boards.Mega;
            }
            else
            {

            }
        }
        

        private FeaturesSettings featuresSettings = new FeaturesSettings();

        private void ParseConfig(List<byte> configData)
        {

            if (configData.Count > 4)
            {

                for (int i = 3; i < configData.Count - 1; i++)
                {
                    byte rawByte = configData[i];
                    CoreConfigRecordType recordType = (CoreConfigRecordType)rawByte;

                    switch (recordType)
                    {
                        case CoreConfigRecordType.DeviceIDRecord:
                            i++;
                            rawByte = configData[i];
                            Config.Instance.DeviceID = rawByte;
                            break;

                        case CoreConfigRecordType.ClusterIDRecord:
                            i++;
                            rawByte = configData[i];
                            Config.Instance.ClusterID = rawByte;
                            break;

                        case CoreConfigRecordType.DummyFirstRecord:
                            break;
                        case CoreConfigRecordType.DummyLastRecord:
                            break;

                        case CoreConfigRecordType.ESPSettingsRecord:

                            i++;

                            // имя точки доступа                            
                            for (int j = i; ; j++)
                            {
                                rawByte = configData[j];
                                if (rawByte != 0)
                                    Config.Instance.ESPSettings.APName += Convert.ToChar(rawByte); 
                                else
                                {
                                    i = j + 1;
                                    break;
                                }

                            }

                            // пароль точки доступа
                            for (int j = i; ; j++)
                            {
                                rawByte = configData[j];
                                if (rawByte != 0)
                                    Config.Instance.ESPSettings.APPassword += Convert.ToChar(rawByte);
                                else
                                {
                                    i = j + 1;
                                    break;
                                }
                            }

                            // флаг - коннектиться ли к роутеру
                            rawByte = configData[i];
                            if (!(rawByte == 0 || rawByte == 1))
                                rawByte = 1;

                            Config.Instance.ESPSettings.ConnectToRouter = rawByte;
                            i++;

                            // SSID роутера
                            for (int j = i; ; j++)
                            {
                                rawByte = configData[j];
                                if (rawByte != 0)
                                    Config.Instance.ESPSettings.RouterID += Convert.ToChar(rawByte);
                                else
                                {
                                    i = j + 1;
                                    break;
                                }
                            }

                            // пароль роутера
                            for (int j = i; ; j++)
                            {
                                rawByte = configData[j];
                                if (rawByte != 0)
                                    Config.Instance.ESPSettings.RouterPassword += Convert.ToChar(rawByte);
                                else
                                {
                                    i = j + 1;
                                    break;
                                }
                            }

                            // скорость работы с ESP
                            rawByte = configData[i];
                            if (!ConsistencyChecker.UARTSpeedValid(rawByte))
                                rawByte = (byte)UARTSpeed.Speed57600;

                            Config.Instance.ESPSettings.UartSpeed = rawByte;
                            i++;

                            // номер Serial
                            rawByte = configData[i];
                            if (rawByte == 0)
                                rawByte = 1;

                            if (rawByte > 3)
                                rawByte = 1;

                            Config.Instance.ESPSettings.SerialNumber = rawByte;
                            i++;

                            // использовать ли пин пересброса питания при зависании ESP
                            rawByte = configData[i];
                            if (!(rawByte == 1 || rawByte == 0))
                                rawByte = 0;

                            Config.Instance.ESPSettings.UseRebootPin = rawByte;
                            i++;

                            // номер пина для пересброса питания ESP
                            rawByte = configData[i];
                            Config.Instance.ESPSettings.RebootPinNumber = rawByte;
                            i++;

                            // кол-во секунд, по истечении которых модем считается зависшим
                            rawByte = configData[i];
                            Config.Instance.ESPSettings.HangTimeout = rawByte;
                            i++;

                            // сколько секунд держать питание выключенным при перезагрузке ESP
                            rawByte = configData[i];
                            Config.Instance.ESPSettings.HangPowerOffTime = rawByte;
                            i++;

                            // сколько секунд ждать загрузки модема при инициализации/переинициализации
                            rawByte = configData[i];
                            Config.Instance.ESPSettings.WaitInitTime = rawByte;
                            i++;

                            // уровень для включения питания (1 - HIGH, 0 - LOW)
                            rawByte = configData[i];
                            if (!(rawByte == 1 || rawByte == 0))
                                rawByte = 1;

                            Config.Instance.ESPSettings.PowerOnLevel = rawByte;

                            break;

                        case CoreConfigRecordType.FractDelimiterRecord:
                            i++;
                            rawByte = configData[i];
                            Config.Instance.FractDelimiter = Convert.ToChar(rawByte);
                            break;

                        case CoreConfigRecordType.WatchdogRecord:
                            i++;
                            rawByte = configData[i];
                            Config.Instance.WatchdogSettings.WatchdogEnabled = rawByte == 1;

                            i++;
                            rawByte = configData[i];
                            Config.Instance.WatchdogSettings.WatchdogPin = rawByte;

                            i++;
                            byte bFirst = configData[i];
                            
                            i++;
                            byte bSecond = configData[i];
                            ushort wdtInterval = bSecond;
                            wdtInterval <<= 8;
                            wdtInterval |= bFirst;

                            Config.Instance.WatchdogSettings.WatchdogInterval = wdtInterval;

                            i++;
                            bFirst = configData[i];                            
                            i++;
                            bSecond = configData[i];

                            ushort wdtDuration = bSecond;
                            wdtDuration <<= 8;
                            wdtDuration |= bFirst;

                            Config.Instance.WatchdogSettings.WatchdogPulseDuration = wdtDuration;


                            break;

                        case CoreConfigRecordType.LoRaSettingsRecord:

                            i++;
                            rawByte = configData[i];

                            if (!ConsistencyChecker.LoRaFrequencyValid(rawByte))
                                rawByte = (byte)LoraFrequency.MHz433;

                            Config.Instance.LoRaSettings.Frequency = (LoraFrequency) rawByte;

                            i++;
                            rawByte = configData[i];
                            Config.Instance.LoRaSettings.SSPin = rawByte;

                            i++;
                            rawByte = configData[i];
                            Config.Instance.LoRaSettings.ResetPin = rawByte;

                            i++;
                            rawByte = configData[i];
                            Config.Instance.LoRaSettings.DIOPin = rawByte;

                            i++;
                            rawByte = configData[i];
                            if (rawByte > 17)
                                rawByte = 17;
                            if (rawByte < 2)
                                rawByte = 2;

                            Config.Instance.LoRaSettings.TXPower = rawByte;

                            i++;
                            rawByte = configData[i];
                            if (!ConsistencyChecker.LoRaBandwidthValid(rawByte))
                                rawByte = (byte) LoraBandwidth.Hz250000;

                                Config.Instance.LoRaSettings.Bandwidth = (LoraBandwidth) rawByte;

                            i++;
                            rawByte = configData[i];
                            if (!(rawByte == 0 || rawByte == 1))
                                rawByte = 0;
                            Config.Instance.LoRaSettings.UseCRC = rawByte;

                            i++;
                            rawByte = configData[i];
                            if (!(rawByte == 0 || rawByte == 1))
                                rawByte = 1;
                            Config.Instance.LoRaSettings.IsMasterMode = rawByte;

                            i++;
                            rawByte = configData[i];
                            Config.Instance.LoRaSettings.RetransmitCount = rawByte;

                            i++;
                            rawByte = configData[i];
                            Config.Instance.LoRaSettings.SendDuration = rawByte;


                            break;
                        /*
                        case CoreConfigRecordType.RS485IncomingPacketRecord:

                            RS485IncomingPacketConfigData packetData = new RS485IncomingPacketConfigData();

                            i++;
                            rawByte = configData[i];

                            packetData.HeaderLength = rawByte;
                            packetData.Header = new byte[packetData.HeaderLength];

                            i++;
                            for (byte k = 0; k < rawByte; k++, i++)
                            {
                                packetData.Header[k] = configData[i];
                            }

                            packetData.PacketLength = configData[i];
                            i++;

                            packetData.PacketID = configData[i];

                            currentConfig.RS485Packets.Add(packetData);


                            break;
                            */

                        case CoreConfigRecordType.RS485SettingsRecord:

                            i++;
                            Config.Instance.RS485Settings.UartSpeed = configData[i];

                            if (!ConsistencyChecker.UARTSpeedValid(Config.Instance.RS485Settings.UartSpeed))
                                Config.Instance.RS485Settings.UartSpeed = (byte)UARTSpeed.Speed57600;

                            i++;
                            if (configData[i] == 0)
                                configData[i] = 1;


                            if (configData[i] > 3)
                                configData[i] = 1;

                            Config.Instance.RS485Settings.SerialNumber = configData[i];

                            i++;
                            Config.Instance.RS485Settings.DEPin = configData[i];

                            i++;
                            if (!(configData[i] == 0 || configData[i] == 1))
                                configData[i] = 1;

                            Config.Instance.RS485Settings.IsMasterMode = configData[i];


                            break;


                        case CoreConfigRecordType.SignalRecord:
                            {
                                // запись по сигналу, разбираем
                                SignalConfigData signal = new SignalConfigData();

                                // пропускаем длину данных
                                i++;

                                // читаем признак - работать ли по времени
                                i++;
                                signal.WorkOnTime = configData[i] == 1;

                                if(signal.WorkOnTime)
                                {
                                    // читаем 5 байт настроек времени
                                    i++;
                                    signal.Daymask = configData[i];

                                    i++;
                                    signal.StartHour = configData[i];

                                    i++;
                                    signal.StartMinute = configData[i];

                                    i++;
                                    signal.EndHour = configData[i];

                                    i++;
                                    signal.EndMinute = configData[i];
                                } // if

                                // читаем операнд
                                i++;
                                if (!ConsistencyChecker.SignalOperandValid(configData[i]))
                                    configData[i] = (byte)SignalOperands.sopCompareNoData;

                                signal.Operand = (SignalOperands) configData[i];

                                // длина данных для сравнения
                                i++;
                                byte compareDataLen = configData[i];

                                signal.Data = new byte[compareDataLen];

                                // читаем данные
                                try
                                {
                                    for (int yy = 0; yy < compareDataLen; yy++)
                                    {
                                        i++;
                                        signal.Data[yy] = configData[i];
                                    }

                                    // читаем кол-во действий
                                    i++;
                                    byte actionsCount = configData[i];

                                    // читаем действия
                                    for (byte rr = 0; rr < actionsCount; rr++)
                                    {
                                        SignalOneAction act = new SignalOneAction();
                                        i++;
                                        if (!ConsistencyChecker.SignalActionValid(configData[i]))
                                            configData[i] = (byte)SignalActions.saRaiseSignal;

                                        act.Action = (SignalActions)configData[i];

                                        i++;
                                        byte actionDataLen = configData[i];
                                        act.ActionData = new byte[actionDataLen];

                                        for (byte uu = 0; uu < actionDataLen; uu++)
                                        {
                                            i++;
                                            act.ActionData[uu] = configData[i];
                                        }

                                        signal.Actions.Add(act);
                                    }

                                    // читаем имя датчика
                                    char ch = '\0';
                                    byte readedNameChars = 0;

                                    do
                                    {
                                        if (readedNameChars > 10)
                                            break;

                                        i++;
                                        readedNameChars++;

                                        ch = (char)configData[i];

                                        if (ch == '\0')
                                            break;

                                        signal.SensorName += ch;

                                    } while (ch != '\0');
                                }
                                catch { }


                                // сигнал прочитан, добавляем в общий список
                                Config.Instance.Signals.Add(signal);

                            }
                            break;

                        case CoreConfigRecordType.SensorRecord:

                            SensorConfigData sensorData = new SensorConfigData();

                            i++;

                            // имя датчика
                            for (int j = i; ; j++)
                            {
                                rawByte = configData[j];

                                if (rawByte != 0)
                                    sensorData.SensorName += Convert.ToChar(rawByte);
                                else
                                {
                                    i = j + 1;
                                    break;
                                }

                            }

                            // тип датчика
                            rawByte = configData[i];
                            if (!ConsistencyChecker.SensorTypeValid(rawByte))
                                rawByte = (byte) CoreSensorType.Unknown;

                            sensorData.SensorType = (CoreSensorType)rawByte;
                            i++;

                            byte dataLen = configData[i];
                            sensorData.DataLength = dataLen;

                            sensorData.Data = new byte[dataLen];


                            for (byte k = 0; k < dataLen; k++)
                            {
                                byte data = configData[i + k + 1];
                                sensorData.Data[k] = data;
                            }
                            i += dataLen;

                            Config.Instance.Sensors.Add(sensorData);
                            break;

                        case CoreConfigRecordType.SensorsUpdateIntervalRecord:
                            
                            i++;
                            rawByte = configData[i];
                            Config.Instance.SensorsUpdateInterval = rawByte;
                            break;

                        case CoreConfigRecordType.TemperatureUnitRecord:
                            
                            i++;
                            rawByte = configData[i];
                            if (!(rawByte == (byte)UnitTemperature.UnitCelsius || rawByte == (byte)UnitTemperature.UnitFahrenheit))
                                rawByte = (byte)UnitTemperature.UnitCelsius;

                            UnitTemperature unit = (UnitTemperature)rawByte;
                            Config.Instance.TemperatureUnit = unit;
                            break;

                    } // switch

                } // for
            } // if

            RecreateTreeView();

        }

        private void RecreateTreeView()
        {


            for (int i=0;i<this.treeView.Nodes[0].Nodes.Count;i++)
            {
                TreeNode n = this.treeView.Nodes[0].Nodes[i];
                if (n.Tag == null)
                    continue;

                TreeNodeType nt = (TreeNodeType)n.Tag;
                if(!(nt  == TreeNodeType.DataNode || nt == TreeNodeType.SensorsNode))
                {
                    n.Remove();
                    if(i>0)
                        --i;
                }
            }

            TreeNode node = this.treeView.Nodes[0].Nodes.Add("Основные настройки");
            node.Tag = TreeNodeType.MainSettingsNode;
            node.ImageIndex = 5;
            node.SelectedImageIndex = node.ImageIndex;


            if (featuresSettings.LoRaAvailable)
            {
                TreeNode n = this.treeView.Nodes[0].Nodes.Add("Настройки LoRa");
                n.Tag = TreeNodeType.LoRaSettingsNode;
                n.ImageIndex = 2;
                n.SelectedImageIndex = n.ImageIndex;
            }

            if(featuresSettings.RS485Available)
            {
                TreeNode n = this.treeView.Nodes[0].Nodes.Add("Настройки RS-485");
                n.Tag = TreeNodeType.RS485SettingsNode;
                n.ImageIndex = 3;
                n.SelectedImageIndex = n.ImageIndex;

            }
            if (featuresSettings.ESPAvailable)
            {
                TreeNode n = this.treeView.Nodes[0].Nodes.Add("Настройки ESP");
                n.Tag = TreeNodeType.ESPSettingsNode;
                n.ImageIndex = 4;
                n.SelectedImageIndex = n.ImageIndex;

            }
            if (featuresSettings.SDAvailable)
            {
                TreeNode n = this.treeView.Nodes[0].Nodes.Add("SD-карта");
                n.Tag = TreeNodeType.SDSettingsNode;
                n.ImageIndex = 8;
                n.SelectedImageIndex = n.ImageIndex;

            }
            if (featuresSettings.SignalsAvailable)
            {
                TreeNode n = this.treeView.Nodes[0].Nodes.Add("Сигналы");
                n.Tag = TreeNodeType.SignalsSettingsNode;
                n.ImageIndex = 9;
                n.SelectedImageIndex = n.ImageIndex;

            }

            ShowData();
        }

        private void ParseAskConfig(Answer a)
        {
            if (a.IsOkAnswer)
            {
                //TODO: пришёл конфиг!!!
                string strConfig = a.Params[1];

                List<byte> configData = new List<byte>();

                for (int i=0;i<strConfig.Length;i+=2)
                {
                    string strByte = strConfig.Substring(i, 2);                    
                    byte byteVal = (byte)int.Parse(strByte, System.Globalization.NumberStyles.HexNumber);
                    configData.Add(byteVal);
                }

                ParseConfig(configData);
                FillSignalsList();
                configLoaded = true;
            }
            else
            {

            }
        }

        private string GetSignalDataAsString(SignalConfigData signal)
        {
            string result = "";

            if (signal.Data == null)
                return result;

            int halfDataCount = signal.Data.Length / 2;
            int readPtr = 0;

            for (int i = 0; i < halfDataCount; i++)
            {
                result += signal.Data[readPtr].ToString("X2");
                readPtr++;
            }

            if(signal.Operand == SignalOperands.sopInterval)
            {
                result += "-";
                for (int i = 0; i < halfDataCount; i++)
                {
                    result += signal.Data[readPtr].ToString("X2");
                    readPtr++;
                }
            }

            return result;
        }

        private void AddSignalToList(SignalConfigData signal)
        {
            ListViewItem li = lvSignals.Items.Add("");
            li.SubItems.Clear();
            li.Text = signal.ToString();

            string opString = EnumHelpers.GetEnumDescription(signal.Operand);
            if (signal.Data == null || signal.Data.Length < 1)
            {
                if(signal.Operand != SignalOperands.sopCompareNoData)
                    opString = "не имеет значения";
            }

            li.SubItems.Add(opString);

            li.SubItems.Add(GetSignalDataAsString(signal));

            if (signal.WorkOnTime)
                li.SubItems.Add("да");
            else
                li.SubItems.Add("нет");


            string daymaskStr = "";

            if (signal.WorkOnTime)
            {
                byte daymask = signal.Daymask;

                string[] days =
                {
                    "",
                    "ПН",
                    "ВТ",
                    "СР",
                    "ЧТ",
                    "ПТ",
                    "СБ",
                    "ВС",
                };

                for(byte i=1;i<=7;i++)
                {
                    if((daymask & (1 << i)) != 0)
                    {
                        if (daymaskStr.Length > 0)
                            daymaskStr += ",";
                        daymaskStr += days[i];
                    }
                }

            } // if(signal.WorkOnTime)
            li.SubItems.Add(daymaskStr);

            li.SubItems.Add(signal.Actions.Count.ToString());

            li.Tag = signal;
            li.ImageIndex = 9;

        }

        private void FillSignalsList()
        {
            this.lvSignals.BeginUpdate();
            this.lvSignals.Items.Clear();

            for(int i=0;i<Config.Instance.Signals.Count;i++)
            {
                SignalConfigData signal = Config.Instance.Signals[i];
                AddSignalToList(signal);
            }

            this.lvSignals.EndUpdate();

        }

        private string ByteAsHexString(byte b)
        {
            return "0x" + b.ToString("X2");
        }

        private List<byte> GetConfigRaw()
        {
            List<byte> result = new List<byte>();

            result.Add(Headers.CORE_HEADER1);
            result.Add(Headers.CORE_HEADER2);
            result.Add(Headers.CORE_HEADER3);

            // запись ID девайса
            result.Add((byte)CoreConfigRecordType.DeviceIDRecord);
            result.Add(Config.Instance.DeviceID);

            // запись ID кластера
            result.Add((byte)CoreConfigRecordType.ClusterIDRecord);
            result.Add(Config.Instance.ClusterID);

            // запись разделителя целой и дробной части числа
            result.Add((byte)CoreConfigRecordType.FractDelimiterRecord);
            result.Add((byte)Config.Instance.FractDelimiter);

            // запись, в чём измеряем температуру
            result.Add((byte)CoreConfigRecordType.TemperatureUnitRecord);
            result.Add((byte)Config.Instance.TemperatureUnit);

            // запись интервала обновления показаний
            result.Add((byte)CoreConfigRecordType.SensorsUpdateIntervalRecord);
            result.Add(Config.Instance.SensorsUpdateInterval);

            // записываем настройки ватчдога
            result.Add((byte)CoreConfigRecordType.WatchdogRecord);
            result.Add(Config.Instance.WatchdogSettings.WatchdogEnabled ? (byte) 1 : (byte) 0);
            result.Add(Config.Instance.WatchdogSettings.WatchdogPin);
            byte[] b = BitConverter.GetBytes(Config.Instance.WatchdogSettings.WatchdogInterval);
            result.Add(b[0]);
            result.Add(b[1]);

            b = BitConverter.GetBytes(Config.Instance.WatchdogSettings.WatchdogPulseDuration);
            result.Add(b[0]);
            result.Add(b[1]);

            // записываем датчики
            for (int i = 0; i < Config.Instance.Sensors.Count; i++)
            {
                SensorConfigData dt = Config.Instance.Sensors[i];
                result.Add((byte)CoreConfigRecordType.SensorRecord);
                for (int k = 0; k < dt.SensorName.Length; k++)
                {
                    result.Add((byte)dt.SensorName[k]);
                }
                result.Add(0);

                result.Add((byte)dt.SensorType);
                result.Add(dt.DataLength);
                for (int k = 0; k < dt.DataLength; k++)
                {
                    result.Add(dt.Data[k]);
                }

            } // for

            // датчики записаны

            if (featuresSettings.ESPAvailable)
            {
                result.Add((byte)CoreConfigRecordType.ESPSettingsRecord);

                for (int k = 0; k < Config.Instance.ESPSettings.APName.Length; k++)
                {
                    result.Add((byte)Config.Instance.ESPSettings.APName[k]);
                }
                result.Add(0);

                for (int k = 0; k < Config.Instance.ESPSettings.APPassword.Length; k++)
                {
                    result.Add((byte)Config.Instance.ESPSettings.APPassword[k]);
                }
                result.Add(0);

                result.Add(Config.Instance.ESPSettings.ConnectToRouter);

                for (int k = 0; k < Config.Instance.ESPSettings.RouterID.Length; k++)
                {
                    result.Add((byte)Config.Instance.ESPSettings.RouterID[k]);
                }
                result.Add(0);

                for (int k = 0; k < Config.Instance.ESPSettings.RouterPassword.Length; k++)
                {
                    result.Add((byte)Config.Instance.ESPSettings.RouterPassword[k]);
                }
                result.Add(0);

                result.Add(Config.Instance.ESPSettings.UartSpeed);
                result.Add(Config.Instance.ESPSettings.SerialNumber);
                result.Add(Config.Instance.ESPSettings.UseRebootPin);
                result.Add(Config.Instance.ESPSettings.RebootPinNumber);
                result.Add(Config.Instance.ESPSettings.HangTimeout);
                result.Add(Config.Instance.ESPSettings.HangPowerOffTime);
                result.Add(Config.Instance.ESPSettings.WaitInitTime);
                result.Add(Config.Instance.ESPSettings.PowerOnLevel);


            }

            if (featuresSettings.RS485Available)
            {
                result.Add((byte)CoreConfigRecordType.RS485SettingsRecord);

                result.Add(Config.Instance.RS485Settings.UartSpeed);
                result.Add(Config.Instance.RS485Settings.SerialNumber);
                result.Add(Config.Instance.RS485Settings.DEPin);
                result.Add(Config.Instance.RS485Settings.IsMasterMode);

            } // if

            if (featuresSettings.LoRaAvailable)
            {
                result.Add((byte)CoreConfigRecordType.LoRaSettingsRecord);

                result.Add((byte)Config.Instance.LoRaSettings.Frequency);
                result.Add(Config.Instance.LoRaSettings.SSPin);
                result.Add(Config.Instance.LoRaSettings.ResetPin);
                result.Add(Config.Instance.LoRaSettings.DIOPin);
                result.Add(Config.Instance.LoRaSettings.TXPower);
                result.Add((byte)Config.Instance.LoRaSettings.Bandwidth);
                result.Add(Config.Instance.LoRaSettings.UseCRC);
                result.Add(Config.Instance.LoRaSettings.IsMasterMode);
                result.Add(Config.Instance.LoRaSettings.RetransmitCount);
                result.Add(Config.Instance.LoRaSettings.SendDuration);

            }

            if(featuresSettings.SignalsAvailable)
            {
                // запоминаем сигналы
                for(int i=0;i<Config.Instance.Signals.Count;i++)
                {
                    SignalConfigData sig = Config.Instance.Signals[i];

                    result.Add((byte)CoreConfigRecordType.SignalRecord);

                    result.Add((byte)sig.RecordLength);

                    if (sig.WorkOnTime)
                    {
                        result.Add(1);
                        result.Add(sig.Daymask);
                        result.Add(sig.StartHour);
                        result.Add(sig.StartMinute);
                        result.Add(sig.EndHour);
                        result.Add(sig.EndMinute);
                    }
                    else
                        result.Add(0);

                    result.Add((byte)sig.Operand);

                    if (sig.Data != null)
                    {
                        result.Add((byte)sig.Data.Length);

                        for (int kk = 0; kk < sig.Data.Length; kk++)
                            result.Add(sig.Data[kk]);
                    }
                    else
                        result.Add(0);

                    result.Add((byte)sig.Actions.Count);

                    for(int kk=0;kk<sig.Actions.Count;kk++)
                    {
                        SignalOneAction act = sig.Actions[kk];

                        result.Add((byte)act.Action);

                        if (act.ActionData != null)
                        {
                            result.Add((byte)act.ActionData.Length);

                            for (int zz = 0; zz < act.ActionData.Length; zz++)
                                result.Add(act.ActionData[zz]);
                        }
                        else
                            result.Add(0);
                    }

                    for (int pp = 0; pp < sig.SensorName.Length; pp++)
                        result.Add((byte)sig.SensorName[pp]);

                    result.Add(0);

                } // for
            }


            result.Add(Headers.CORE_HEADER1);

            return result;
        }

        public string GetConfigAsString()
        {
            string result = "const byte coreConfig[] PROGMEM = {\r\n\tCORE_HEADER1,\r\n\tCORE_HEADER2,\r\n\tCORE_HEADER3,\r\n";

            // проходим по конфигу, и смотрим, что там?
            result += "\tDeviceIDRecord,\r\n\t" + ByteAsHexString(Config.Instance.DeviceID) + ",\r\n";
            result += "\tClusterIDRecord,\r\n\t" + ByteAsHexString(Config.Instance.ClusterID) + ",\r\n";

            result += "\tFractDelimiterRecord,\r\n\t'" + Config.Instance.FractDelimiter + "',\r\n";
            result += "\tTemperatureUnitRecord,\r\n\t" + Config.Instance.TemperatureUnit.ToString() + ",\r\n";
            result += "\tSensorsUpdateIntervalRecord,\r\n\t" + ByteAsHexString(Config.Instance.SensorsUpdateInterval) + ",\r\n";

            // настройки ватчдога
            result += "\tWatchdogRecord,\r\n\t" + ByteAsHexString(Config.Instance.WatchdogSettings.WatchdogEnabled ? (byte) 1 : (byte)0) + ",\r\n";
            result += "\t" + ByteAsHexString(Config.Instance.WatchdogSettings.WatchdogPin) + ",\r\n";
            byte[] b = BitConverter.GetBytes(Config.Instance.WatchdogSettings.WatchdogInterval);
            result += "\t" + ByteAsHexString(b[0]) + ",\r\n";
            result += "\t" + ByteAsHexString(b[1]) + ",\r\n";
            b = BitConverter.GetBytes(Config.Instance.WatchdogSettings.WatchdogPulseDuration);
            result += "\t" + ByteAsHexString(b[0]) + ",\r\n";
            result += "\t" + ByteAsHexString(b[1]) + ",\r\n";


            for (int i=0;i< Config.Instance.Sensors.Count;i++)
            {
                SensorConfigData dt = Config.Instance.Sensors[i];
                result += "\tSensorRecord,\r\n\t";
                for (int k = 0; k < dt.SensorName.Length; k++)
                    result += "'" + dt.SensorName[k] + "',";

                result += "'\\0',\r\n\t";

                result += dt.SensorType.ToString() + ",\r\n\t";
                result += ByteAsHexString(dt.DataLength) + ",\r\n";

                for(int k=0;k<dt.DataLength;k++)
                {
                    result += "\t" + ByteAsHexString(dt.Data[k]) + ",\r\n";
                }
            }
            
            if(featuresSettings.ESPAvailable)
            {
                result += "\tESPSettingsRecord,\r\n\t";

                for (int k = 0; k < Config.Instance.ESPSettings.APName.Length; k++)
                    result += "'" + Config.Instance.ESPSettings.APName[k] + "',";

                result += "'\\0',\r\n\t";

                for (int k = 0; k < Config.Instance.ESPSettings.APPassword.Length; k++)
                    result += "'" + Config.Instance.ESPSettings.APPassword[k] + "',";

                result += "'\\0',\r\n\t";

                result += ByteAsHexString(Config.Instance.ESPSettings.ConnectToRouter) + ",\r\n\t";

                for (int k = 0; k < Config.Instance.ESPSettings.RouterID.Length; k++)
                    result += "'" + Config.Instance.ESPSettings.RouterID[k] + "',";

                result += "'\\0',\r\n\t";

                for (int k = 0; k < Config.Instance.ESPSettings.RouterPassword.Length; k++)
                    result += "'" + Config.Instance.ESPSettings.RouterPassword[k] + "',";

                result += "'\\0',\r\n\t";

                result += ByteAsHexString(Config.Instance.ESPSettings.UartSpeed) + ",\r\n\t";
                result += ByteAsHexString(Config.Instance.ESPSettings.SerialNumber) + ",\r\n\t";
                result += ByteAsHexString(Config.Instance.ESPSettings.UseRebootPin) + ",\r\n\t";
                result += ByteAsHexString(Config.Instance.ESPSettings.RebootPinNumber) + ",\r\n\t";
                result += ByteAsHexString(Config.Instance.ESPSettings.HangTimeout) + ",\r\n\t";
                result += ByteAsHexString(Config.Instance.ESPSettings.HangPowerOffTime) + ",\r\n\t";
                result += ByteAsHexString(Config.Instance.ESPSettings.WaitInitTime) + ",\r\n\t";
                result += ByteAsHexString(Config.Instance.ESPSettings.PowerOnLevel) + ",\r\n";


            }

            if (featuresSettings.RS485Available)
            {
                result += "\tRS485SettingsRecord,\r\n\t";
                result += ByteAsHexString(Config.Instance.RS485Settings.UartSpeed) + ",\r\n\t";
                result += ByteAsHexString(Config.Instance.RS485Settings.SerialNumber) + ",\r\n\t";
                result += ByteAsHexString(Config.Instance.RS485Settings.DEPin) + ",\r\n\t";
                result += ByteAsHexString(Config.Instance.RS485Settings.IsMasterMode) + ",\r\n";


            } // if

            if(featuresSettings.LoRaAvailable)
            {
                result += "\tLoRaSettingsRecord,\r\n";
                result += "\t" + ByteAsHexString((byte)Config.Instance.LoRaSettings.Frequency) + ",\r\n";
                result += "\t" + ByteAsHexString(Config.Instance.LoRaSettings.SSPin) + ",\r\n";
                result += "\t" + ByteAsHexString(Config.Instance.LoRaSettings.ResetPin) + ",\r\n";
                result += "\t" + ByteAsHexString(Config.Instance.LoRaSettings.DIOPin) + ",\r\n";
                result += "\t" + ByteAsHexString(Config.Instance.LoRaSettings.TXPower) + ",\r\n";
                result += "\t" + ByteAsHexString((byte)Config.Instance.LoRaSettings.Bandwidth) + ",\r\n";
                result += "\t" + ByteAsHexString(Config.Instance.LoRaSettings.UseCRC) + ",\r\n";
                result += "\t" + ByteAsHexString(Config.Instance.LoRaSettings.IsMasterMode) + ",\r\n";
                result += "\t" + ByteAsHexString(Config.Instance.LoRaSettings.RetransmitCount) + ",\r\n";
                result += "\t" + ByteAsHexString(Config.Instance.LoRaSettings.SendDuration) + ",\r\n";
            }

            if(featuresSettings.SignalsAvailable)
            {
                // тут проходим по сигналам
                for(int ss=0;ss<Config.Instance.Signals.Count;ss++)
                {
                    result += "\tSignalRecord,\r\n";
                    SignalConfigData dt = Config.Instance.Signals[ss];

                    byte dataLen = (byte)dt.RecordLength;

                    result += "\t" + ByteAsHexString(dataLen) + ",\r\n";

                    byte wot = 0;
                    if (dt.WorkOnTime)
                        wot = 1;

                    result += "\t" + ByteAsHexString(wot) + ",\r\n";

                    if (dt.WorkOnTime)
                    {
                        result += "\t" + ByteAsHexString(dt.Daymask) + ",\r\n";
                        result += "\t" + ByteAsHexString(dt.StartHour) + ",\r\n";
                        result += "\t" + ByteAsHexString(dt.StartMinute) + ",\r\n";
                        result += "\t" + ByteAsHexString(dt.EndHour) + ",\r\n";
                        result += "\t" + ByteAsHexString(dt.EndMinute) + ",\r\n";
                    }

                    result += "\t" + ByteAsHexString((byte)dt.Operand) + ",\r\n";

                    byte compareDataLen = 0;

                    if (dt.Data != null && dt.Data.Length > 0)
                        compareDataLen = (byte) dt.Data.Length;

                    result += "\t" + ByteAsHexString(compareDataLen) + ",\r\n";

                    if(dt.Data != null && dt.Data.Length > 0)
                    {
                        result += "\t";
                        for(int rr=0;rr<dt.Data.Length;rr++)
                        {
                            result += ByteAsHexString(dt.Data[rr]) + ",";

                        }

                        result += "\r\n";
                    }

                    result += "\t" + ByteAsHexString((byte)dt.Actions.Count) + ",\r\n";

                    for(int pp=0;pp<dt.Actions.Count;pp++)
                    {
                        SignalOneAction act = dt.Actions[pp];

                        result += "\t" + ByteAsHexString((byte)act.Action) + ",\r\n";

                        byte actionDataLen = 0;
                        if (act.ActionData != null && act.ActionData.Length > 0)
                            actionDataLen = (byte)act.ActionData.Length;

                        result += "\t" + ByteAsHexString(actionDataLen) + ",\r\n";

                        if(act.ActionData != null && act.ActionData.Length > 0)
                        {
                            result += "\t";
                            for(int ee=0;ee<act.ActionData.Length;ee++)
                            {
                                result += ByteAsHexString(act.ActionData[ee]) + ",";

                            }
                            result += "\r\n";
                        }


                    }
                    result += "\t";
                    for(int qq=0;qq<dt.SensorName.Length;qq++)
                    {
                        result += "'" + dt.SensorName[qq] + "',";
                    }
                    result += "'\\0',\r\n";


                } // for signals
            }

            result += "\tCORE_HEADER1\r\n};";

            return result;
        }

        private void ParseAskSensors(Answer a)
        {
            Config.Instance.SupportedSensors.Clear();
            if (a.IsOkAnswer)
            {
                //                AddToLog("Получен список поддерживаемых датчиков.", false);
                //TODO: Тут разбор текущих датчиков, поддерживаемых прошивкой!!!

                if (a.Params.Contains("BH1750"))
                    Config.Instance.SupportedSensors.Add(CoreSensorType.BH1750);

                if (a.Params.Contains("SI7021"))
                    Config.Instance.SupportedSensors.Add(CoreSensorType.Si7021);

                if (a.Params.Contains("DS3231"))
                {
                    Config.Instance.SupportedSensors.Add(CoreSensorType.DS3231);
                    Config.Instance.SupportedSensors.Add(CoreSensorType.DS3231Temperature);
                }

                if (a.Params.Contains("DHT"))
                    Config.Instance.SupportedSensors.Add(CoreSensorType.DHT);

                if (a.Params.Contains("DS18B20"))
                    Config.Instance.SupportedSensors.Add(CoreSensorType.DS18B20);

                if (a.Params.Contains("DPORT"))
                    Config.Instance.SupportedSensors.Add(CoreSensorType.DigitalPortState);

                if (a.Params.Contains("APORT"))
                    Config.Instance.SupportedSensors.Add(CoreSensorType.AnalogPortState);

                if (a.Params.Contains("USENSOR"))
                    Config.Instance.SupportedSensors.Add(CoreSensorType.UserDataSensor);


            }
            else
            {

            }
        }

        private int GetImageFromDataType(CoreDataType dt)
        {
            switch(dt)
            {
                case CoreDataType.AnalogPort: // yes
                    return 0;
                case CoreDataType.DateTime: // yes
                    return 1;
                case CoreDataType.DigitalPort:
                    return 2;
                case CoreDataType.Humidity: // yes
                    return 3;
                case CoreDataType.Luminosity: // yes
                    return 4;
                case CoreDataType.Temperature:
                    return 5;
                case CoreDataType.UserData: // yes
                    return 6;

                    //TODO: Тут остальные типы данных!
            }

            return -1;
        }

        private void ParseAskStorage(Answer a)
        {
            if (a.IsOkAnswer)
            {
                //TODO: Тут разбор показаний датчиков!!!

                string line = a.Params[1];
                // тут разбираем данные, они идут сплошным потоком

                int currentSensorNumber = 0;

                while(line.Length > 0)
                {
                    if (line.Length % 2 > 0)
                        break;

                    try
                    {
                        // сперва идёт имя датчика, заканчивается нулевым байтом
                        string sensorName = "";
                        string strByte;
                        while (true)
                        {
                            strByte = line.Substring(0, 2);
                            line = line.Substring(2);
                            byte byteVal = (byte)int.Parse(strByte, System.Globalization.NumberStyles.HexNumber);
                            if (byteVal == 0)
                                break;
                            else
                                sensorName += Convert.ToChar(byteVal);

                        }

                        // затем идёт тип датчика
                        strByte = line.Substring(0, 2);
                        line = line.Substring(2);
                        CoreSensorType sensorType = (CoreSensorType)int.Parse(strByte, System.Globalization.NumberStyles.HexNumber);

                        // затем идёт тип показаний с датчика
                        strByte = line.Substring(0, 2);
                        line = line.Substring(2);
                        CoreDataType dataType = (CoreDataType)int.Parse(strByte, System.Globalization.NumberStyles.HexNumber);

                        // затем идёт длина данных с датчика
                        strByte = line.Substring(0, 2);
                        line = line.Substring(2);
                        byte dataLen = (byte)int.Parse(strByte, System.Globalization.NumberStyles.HexNumber);

                        string sensorData = "-";

                        if (dataLen > 0)
                        {
                            List<byte> dataBytes = new List<byte>();

                            for (int k = 0; k < dataLen; k++)
                            {
                                strByte = line.Substring(0, 2);
                                line = line.Substring(2);
                                byte dataByte = (byte)int.Parse(strByte, System.Globalization.NumberStyles.HexNumber);
                                dataBytes.Add(dataByte);
                            }

                            sensorData = ConvertDataToString(dataBytes, dataType);
                        }

                        // тут добавляем в список

                        while (this.lvSensorsData.Items.Count <= currentSensorNumber)
                            this.lvSensorsData.Items.Add("");

                        ListViewItem lvi = this.lvSensorsData.Items[currentSensorNumber];
                        SensorData sdStruct = (SensorData)lvi.Tag;
                        if (sdStruct == null)
                        {
                            sdStruct = new SensorData();
                            lvi.Tag = sdStruct;
                        }

                        sdStruct.Data = sensorData;
                        sdStruct.DataType = dataType;
                        sdStruct.Name = sensorName;
                        sdStruct.SensorType = sensorType;

                        lvi.Text = sensorName;
                        lvi.ImageIndex = GetImageFromDataType(dataType);

                        while (lvi.SubItems.Count < 4)
                            lvi.SubItems.Add("");

                        lvi.SubItems[1].Text = SensorConfigData.GetTypeString(sensorType);
                        lvi.SubItems[2].Text = SensorConfigData.GetDataTypeString(dataType);
                        lvi.SubItems[3].Text = sensorData;

                        currentSensorNumber++;

                    }
                    catch { }

                } // while


            }
            else
            {

            }
        }

        

        private string ConvertDataToString(List<byte> dataBytes, CoreDataType dataType)
        {
            string result = "";

            switch(dataType)
            {
                case CoreDataType.AnalogPort:
                    int analog = dataBytes[2] << 8 | dataBytes[1];
                    float volts = 5.0f;
                    if(Config.Instance.Board == Boards.Due)
                    {
                        volts = 3.3f;
                    }
                    else
                    {
                        volts = 5.0f;
                    }
                    float currentVolts = (volts * analog) / 1024;

                    result = SensorConfigData.GetPinString(dataBytes[0]) + ":" + Convert.ToString(analog) + " (" + currentVolts.ToString("n2") + " V)";
                    break;

                case CoreDataType.DateTime:
                    {
                        result = string.Format("{0,0:D2}.{1,0:D2}.{2,0:D4} {3,0:D2}:{4,0:D2}:{5,0:D2}",

                            dataBytes[0], // day
                            dataBytes[1], // month
                            (dataBytes[3] << 8) | dataBytes[2], // year
                            dataBytes[4], // hour
                            dataBytes[5], // minute
                            dataBytes[6] // second
                            );

                    }
                    break;

                case CoreDataType.DigitalPort:
                    result = Convert.ToString(dataBytes[0]) + ":" +(dataBytes[1] == 1 ? "HIGH" : "LOW");
                    break;

                case CoreDataType.Humidity:
                    result = Convert.ToString((System.SByte)dataBytes[0]) + "," + string.Format("{0,0:D2}", dataBytes[1]) + "°/" + Convert.ToString(dataBytes[2]) + "," + string.Format("{0,0:D2}", dataBytes[3]) + "%";
                    break;

                case CoreDataType.Luminosity:
                    int lum = dataBytes[1] << 8 | dataBytes[0];
                    result = Convert.ToString(lum) + " lux";
                    break;

                case CoreDataType.Temperature:
                    result = Convert.ToString((System.SByte)dataBytes[0]) + "," + string.Format("{0,0:D2}", dataBytes[1]) + "°";
                    break;

                case CoreDataType.UnknownType:
                    break;

                case CoreDataType.UserData:
                    {
                        for(int p=0;p<dataBytes.Count;p++)
                        {
                            if (result.Length > 0)
                                result += " ";
                            result += dataBytes[p].ToString("X2");
                        }
                    }
                    break;
            }

            return result;
        }

        private void ResizeLogColumns()
        {
            this.logColumn1.Width = this.lvLog.ClientRectangle.Width / 2 - SystemInformation.VerticalScrollBarWidth / 2 - 2;
            this.logColumn2.Width = this.logColumn1.Width;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            EnumSerialPorts();

            ResizeLogColumns();

            this.toolStrip.ImageList = toolbarImages;
            this.btnConnect.ImageIndex = 0;
            this.btnExportConfig.ImageIndex = 2;
            this.btnSetDateTime.ImageIndex = 3;
            this.btnSaveConfig.ImageIndex = 4;
            this.btnAbout.ImageIndex = 5;

            plStorage.Dock = DockStyle.Fill;
            plMainSettings.Dock = DockStyle.Fill;
            this.plLoRaSettings.Dock = DockStyle.Fill;
            this.plRS485Settings.Dock = DockStyle.Fill;
            this.plESPSettings.Dock = DockStyle.Fill;
            this.plSensors.Dock = DockStyle.Fill;
            this.plSDSettings.Dock = DockStyle.Fill;
            this.plSignalsSettings.Dock = DockStyle.Fill;
            //TODO: тут остальные панели !!!

            InitTreeView();

            Application.Idle += new EventHandler(Application_Idle);
        }

        private void InitTreeView()
        {
            this.treeView.Nodes[0].Nodes.Clear();

            TreeNode node = this.treeView.Nodes[0].Nodes.Add("Данные");
            node.Tag = TreeNodeType.DataNode;
            node.ImageIndex = 6;
            node.SelectedImageIndex = node.ImageIndex;

            node = this.treeView.Nodes[0].Nodes.Add("Датчики конфига");
            node.Tag = TreeNodeType.SensorsNode;
            node.ImageIndex = 7;
            node.SelectedImageIndex = node.ImageIndex;


            //TODO: тут остальные узлы дерева, доступные по умолчанию !!!

            this.treeView.Nodes[0].ExpandAll();

            ShowData();

        }

        private void ShowData()
        {
            this.treeView.SelectedNode = this.treeView.Nodes[0];
            this.plStorage.BringToFront();
            this.lblCurrentSection.Text = "Данные";

        }

        /// <summary>
        /// Обработчик простоя
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void Application_Idle(object sender, EventArgs e)
        {

            bool bConnected = IsConnected();

            btnSetDateTime.Enabled = bConnected;
            btnAddSensor.Enabled = bConnected && Config.Instance.SupportedSensors.Count > 0;
            btnSaveConfig.Enabled = bConnected && !inSaveConfigToController && configLoaded;
            miSaveConfig.Enabled = btnSaveConfig.Enabled;

            if (!bConnected) // порт закрыт
            {
                dateTimeFromControllerReceived = false;

                if (this.lastSelectedPort != null)
                {
                    this.lastSelectedPort.Checked = false;
                }

                if (this.btnConnect.ImageIndex != 0)
                    this.btnConnect.Text = "Соединить";

                this.btnConnect.ImageIndex = 0; // коннект оборвался


//                tbSetWorkMode.Enabled = false;
//                tbWindowPosition.Enabled = false;

//                HideTabPages();


            }
            else
            {

                if (lastSelectedPort != null)
                    if (!lastSelectedPort.Checked)
                        lastSelectedPort.Checked = true;

            }
        }

        /// <summary>
        /// Перечисляем COM-порты
        /// </summary>
        private void EnumSerialPorts()
        {
            btnConnect.DropDownItems.Clear();

            string[] ports = SerialPort.GetPortNames();
            foreach (string port in ports)
            {

                ToolStripMenuItem ti = new ToolStripMenuItem(port);

                ti.MergeIndex = 1;
                ti.AutoSize = true;
                ti.ImageScaling = ToolStripItemImageScaling.None;
                ti.Tag = port;
                ti.Click += ConnectToSelectedComPort;
                ti.CheckOnClick = false;



                btnConnect.DropDownItems.Add(ti);


            }
        }


        private void ConnectToSelectedComPort(object sender, EventArgs e)
        {

            ToolStripMenuItem mi = (ToolStripMenuItem)sender;

            if (mi.Checked)
                return;


            Disconnect();
            if (this.lastSelectedPort != null)
            {

                this.lastSelectedPort.Checked = false;
            }

            this.lastSelectedPort = mi;
            mi.Checked = true;

            DoConnect((string)mi.Tag);

        }

        /// <summary>
        /// Начинаем коннектиться к порту
        /// </summary>
        /// <param name="port">имя порта</param>
        private void DoConnect(string port)
        {
            dateTimeFromControllerReceived = false; // не получили ещё текущее время с контроллера
            controllerDateTime = DateTime.MinValue; // устанавливаем минимальное значение даты

            connForm = new ConnectForm();
            connForm.SetMainFormAndPort(this, port);
            connForm.ShowDialog();
        }

        /// <summary>
        /// Отсоединяемся
        /// </summary>
        private void Disconnect() // отсоединяемся от порта
        {
            if (currentTransport != null)
                currentTransport.Disconnect();

            currentTransport = null;



        }

        /// <summary>
        /// Проверяем, соединены ли мы с контроллером
        /// </summary>
        /// <returns></returns>
        public bool IsConnected()
        {
            if (currentTransport != null)
                return currentTransport.Connected();

            return false;
        }



        /// <summary>
        /// Класс ответа от контроллера
        /// </summary>
        public class Answer
        {
            /// <summary>
            /// флаг, что ответ положительный
            /// </summary>
            public bool IsOkAnswer;
            /// <summary>
            /// список параметров
            /// </summary>
            public string[] Params;
            /// <summary>
            /// сырые данные, полученные от контроллера
            /// </summary>
            public string RawData;

            /// <summary>
            /// очищает все переменные
            /// </summary>
            private void Clear()
            {
                IsOkAnswer = false;
                Params = null;
                RawData = "";
            }

            /// <summary>
            /// конструирует параметры из строки
            /// </summary>
            /// <param name="dt"></param>
            public void Parse(string dt)
            {
                Clear();
                RawData = dt;

                int idx = dt.IndexOf("OK=");
                if (idx != -1)
                {
                    this.IsOkAnswer = true;
                    dt = dt.Substring(3).Trim();
                    this.Params = dt.Split(PARAM_DELIMITER);
                }
                idx = dt.IndexOf("ER=");
                if (idx != -1)
                {
                    this.IsOkAnswer = false;
                    dt = dt.Substring(3).Trim();
                    this.Params = dt.Split(PARAM_DELIMITER);
                }

            }
            /// <summary>
            /// кол-во параметров
            /// </summary>
            public int ParamsCount
            {
                get { return this.Params == null ? 0 : this.Params.Length; }
            }
            /// <summary>
            /// конструктор
            /// </summary>
            /// <param name="dt">строка для разбора</param>
            public Answer(string dt)
            {
                this.Clear();
                this.Parse(dt);

            }
        }

        private void tmProcessCommandsTimer_Tick(object sender, EventArgs e)
        {
            ProcessNextCommand();
        }

        private AnswerBehaviour answerBehaviour = AnswerBehaviour.Normal;

        private void ProcessNextCommand()
        {
            if (!GrantToProcess())
                return;

            if (!this.GetCommandFromQeue(ref this.currentCommand))
                return;

            System.Diagnostics.Debug.Assert(this.currentTransport != null);

            this.answerBehaviour = AnswerBehaviour.Normal;

            //if (currentCommand.BeforeSend != null)
                currentCommand.BeforeSend?.Invoke();

            this.currentTransport.WriteLine(currentCommand.CommandToSend);

        }

        private bool coreBootFound = false;


        /// <summary>
        /// Проверяем, можем ли мы работать
        /// </summary>
        /// <returns>возвращаем true, если работать можем</returns>
        private bool GrantToProcess()
        {

            if (!coreBootFound)
                return false;

            if (!this.IsConnected()) // нет коннекта
            {

                return false;
            }


            if (this.currentCommand.ParseFunction != null) // чем-то заняты
                return false;


            return true;
        }

        private void tmGetSensorsData_Tick(object sender, EventArgs e)
        {
            if (!GrantToProcess())
                return;

            PushCommandToQueue(GET_PREFIX + "STORAGE", ParseAskStorage);
            PushCommandToQueue(GET_PREFIX + "FREERAM", ParseAskFreeram);

        }

        private void convertConfigToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string res = GetConfigAsString();
            ConfigExportForm ce = new ConfigExportForm();
            ce.richTextBox1.Text = "";
            ce.richTextBox1.AppendText(res);
            ce.ShowDialog();

        }

        private void ShowGeneralSettings()
        {
            ConfigGeneralSettings gs = new ConfigGeneralSettings();
            this.propertyGridSettings.SelectedObject = gs;

        }

        private void ShowLoRaSettings()
        {
            ConfigLoRaSettings gs = new ConfigLoRaSettings();
            this.propertyGridLoRaSettings.SelectedObject = gs;
        }

        private void ShowRS485Settings()
        {
            ConfigRS485Settings gs = new ConfigRS485Settings();
            this.propertyGridRS485Settings.SelectedObject = gs;

        }

        private void ShowESPSettings()
        {
            ConfigESPSettings gs = new ConfigESPSettings();
            this.propertyGridESPSettings.SelectedObject = gs;

        }

        private void treeView_AfterSelect(object sender, TreeViewEventArgs e)
        {
            TreeNode selectedNode = e.Node;
            if (selectedNode == null || selectedNode.Tag == null)
            {
                this.plStorage.BringToFront();
                this.lblCurrentSection.Text = "Данные";
                return;
            }

            TreeNodeType tp = (TreeNodeType)selectedNode.Tag;
            switch(tp)
            {
                case TreeNodeType.DataNode:
                    this.plStorage.BringToFront();
                    this.lblCurrentSection.Text = "Данные";
                    break;

                case TreeNodeType.MainSettingsNode:
                    this.plMainSettings.BringToFront();
                    this.lblCurrentSection.Text = "Основные настройки";
                    ShowGeneralSettings();
                    break;

                //TODO: Тут другие панели!!!

                case TreeNodeType.LoRaSettingsNode:
                    this.plLoRaSettings.BringToFront();
                    this.lblCurrentSection.Text = "Настройки LoRa";
                    ShowLoRaSettings();
                    break;

                case TreeNodeType.RS485SettingsNode:
                    this.plRS485Settings.BringToFront();
                    this.lblCurrentSection.Text = "Настройки RS-485";
                    ShowRS485Settings();

                    break;

                case TreeNodeType.ESPSettingsNode:
                    this.plESPSettings.BringToFront();
                    this.lblCurrentSection.Text = "Настройки ESP";
                    ShowESPSettings();

                    break;

                case TreeNodeType.SDSettingsNode:
                    this.plSDSettings.BringToFront();
                    this.lblCurrentSection.Text = "SD-карта";

                    break;

                case TreeNodeType.SignalsSettingsNode:
                    this.plSignalsSettings.BringToFront();
                    this.lblCurrentSection.Text = "Сигналы";

                    break;

                case TreeNodeType.SensorsNode:
                    this.plSensors.BringToFront();
                    this.lblCurrentSection.Text = "Список датчиков конфига";
                    ShowSensorsList();

                    break;

            }
        }

        private void ShowSensorsList()
        {
            this.lvSensorsList.BeginUpdate();
            this.lvSensorsList.Items.Clear();

            foreach(SensorConfigData sensor in Config.Instance.Sensors)
            {
                ListViewItem li = this.lvSensorsList.Items.Add(sensor.ToString());
                li.Tag = sensor;
                li.ImageIndex = 0;
                li.SubItems.Add(SensorConfigData.GetTypeString(sensor.SensorType));

                li.SubItems.Add(sensor.GetAdditionalInfo());

                //TODO: тут
            }

            this.lvSensorsList.EndUpdate();
        }

        private void propertyGridSettings_PropertyValueChanged(object s, PropertyValueChangedEventArgs e)
        {
            /*
            ConfigGeneralSettings gs = this.propertyGridSettings.SelectedObject as ConfigGeneralSettings;
            if (gs == null || currentConfig == null)
                return;

            currentConfig.ClusterID = gs.ClusterID;
            currentConfig.DeviceID = gs.DeviceID;
            currentConfig.FractDelimiter = gs.FractDelimiter;
            currentConfig.SensorsUpdateInterval = gs.SensorsUpdateInterval;
            currentConfig.TemperatureUnit = gs.TemperatureUnit;
            */

        }

        private void tmDateTime_Tick(object sender, EventArgs e)
        {
            if (!dateTimeFromControllerReceived)
            {
                Config.Instance.ControllerDateTime = "-";
                return;
            }

            this.controllerDateTime = this.controllerDateTime.AddMilliseconds(tmDateTime.Interval);
            string dateTimeString = this.controllerDateTime.ToString("dd.MM.yyyy HH:mm:ss");

            Config.Instance.ControllerDateTime = dateTimeString;
            //this.propertyGridSettings.Refresh();


        }

        private DateTime dateTimeToSet = DateTime.MinValue;

        private void btnSetDateTime_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Установить время контроллера в локальное время компьютера?", "Подтверждение", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (dr != System.Windows.Forms.DialogResult.OK)
                return;


            dateTimeToSet = DateTime.Now;

            String s = string.Format("{0,0:D2}.{1,0:D2}.{2} {3,0:D2}:{4,0:D2}:{5,0:D2}", dateTimeToSet.Day, dateTimeToSet.Month, dateTimeToSet.Year, dateTimeToSet.Hour, dateTimeToSet.Minute, dateTimeToSet.Second);
            PushCommandToQueue(SET_PREFIX + "DATETIME" + PARAM_DELIMITER + s, ParseSetDatetime);


        }

        private void ParseSetDatetime(Answer a)
        {
            if (a.IsOkAnswer)
            {
                this.dateTimeFromControllerReceived = true;
                this.controllerDateTime = dateTimeToSet;

                MessageBox.Show("Время контроллера обновлено.", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Ошибка установки времени на контроллере!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MainForm_Resize(object sender, EventArgs e)
        {
            ResizeLogColumns();
        }

        private void treeView_BeforeCollapse(object sender, TreeViewCancelEventArgs e)
        {
            e.Cancel = true;
        }

        private void lvSensorsList_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnDeleteSensor.Enabled = lvSensorsList.SelectedItems.Count > 0;
        }

        private void btnDeleteSensor_Click(object sender, EventArgs e)
        {
            if (lvSensorsList.SelectedItems.Count < 1)
                return;

            if (MessageBox.Show("Вы уверены, что хотите удалить датчик?", "Подтверждение", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            ListViewItem li = lvSensorsList.SelectedItems[0];

            SensorConfigData sensor = (SensorConfigData)li.Tag;

            Config.Instance.Sensors.Remove(sensor);
            li.Remove();


        }

        private void btnAddSensor_Click(object sender, EventArgs e)
        {
            AddSensorForm addForm = new AddSensorForm();
            if(addForm.ShowDialog() == DialogResult.OK)
            {
                ShowSensorsList();
            }
        }

        private bool inSaveConfigToController = false;

        private void ShowWaitCursor(bool show)
        {
            Cursor.Current = show ? Cursors.WaitCursor : Cursors.Default;
            Application.UseWaitCursor = show;
            Application.DoEvents();

        }

        private void btnSaveConfig_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Вы уверены, что хотите сохранить конфиг в контроллер?", "Подтверждение", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            inSaveConfigToController = true;
            ShowWaitCursor(true);

            PushCommandToQueue(SET_PREFIX + "CONFIG_START", ParseConfigStart);

        }
        private void SendRestartCoreCommand()
        {
            PushCommandToQueue(SET_PREFIX + "RESTART", ParseCoreRestart);
        }

        private void ParseCoreRestart(Answer a)
        {
            inSaveConfigToController = false;
            ShowWaitCursor(false);

            if (a.IsOkAnswer)
            {
                this.lvSensorsData.Items.Clear();
                ShowSaveConfigMessage(true);
            }
            else
            {
                ShowSaveConfigMessage(false);
            }
        }

        private List<byte> rawConfig = new List<byte>();
        private void SendConfigToController()
        {
            if(rawConfig.Count < 1) // закончили посылать команды
            {
                SendRestartCoreCommand();  

                return;
            }

            int toSend = Math.Min(50, rawConfig.Count);

            string command = "";

            for(int i=0;i<toSend;i++)
            {
                byte b = rawConfig[i];
                command += b.ToString("X2");
            }

            rawConfig.RemoveRange(0, toSend);

            PushCommandToQueue(SET_PREFIX + "CONFIG_PART" + PARAM_DELIMITER + command, ParseSetConfigPart);
        }

        private void ShowSaveConfigMessage(bool succ)
        {
            if (succ)
            {
                // вне очереди получаем данные с хранилища
                PushCommandToQueue(GET_PREFIX + "STORAGE", ParseAskStorage);
                // перезагружаем дату/время из контроллера
                PushCommandToQueue(GET_PREFIX + "DATETIME", ParseAskDatetime);

                MessageBox.Show("Конфиг загружен в контроллер.", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
                MessageBox.Show("Ошибка загрузки конфига в контроллер!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void ParseSetConfigPart(Answer a)
        {
            if(a.IsOkAnswer)
            {
                SendConfigToController();
            }
            else
            {
                inSaveConfigToController = false;
                ShowWaitCursor(false);
                ShowSaveConfigMessage(false);
            }
        }

        private void ParseConfigStart(Answer a)
        {
            if(a.IsOkAnswer)
            {
                // получаем конфиг в виде набора байт
                rawConfig = this.GetConfigRaw();

                // и работаем с кусками
                SendConfigToController();
            }
            else
            {
                inSaveConfigToController = false;
                ShowWaitCursor(false);
                ShowSaveConfigMessage(false);
            }
        }

        private void btnAbout_Click(object sender, EventArgs e)
        {
            AboutForm ab = new AboutForm();
            ab.ShowDialog();
        }

        private TreeNode currentSDParentNode = null;
        private void btnListSDFiles_Click(object sender, EventArgs e)
        {
            btnListSDFiles.Enabled = false;
            PushCommandToQueue(GET_PREFIX + "LS", DummyAnswerReceiver, SetSDReadingFlag);

        }

        private void DummyAnswerReceiver(Answer a)
        {

        }
        private void SetSDReadingFlag()
        {
            this.answerBehaviour = AnswerBehaviour.SDCommandLS;
            this.currentSDParentNode = null;
            this.SDQueryAnswer.Clear();
            this.treeViewSD.Nodes.Clear();
        }

        private void SetSDFolderReadingFlag()
        {
            this.answerBehaviour = AnswerBehaviour.SDCommandLS;
            this.currentSDParentNode = tempSDParentNode;
            this.SDQueryAnswer.Clear();

        }
        TreeNode tempSDParentNode = null;
        private void treeViewSD_BeforeExpand(object sender, TreeViewCancelEventArgs e)
        {
            TreeNode wantedExpand = e.Node;
            SDNodeTags tg = (SDNodeTags)wantedExpand.Tag;

            if (tg != SDNodeTags.TagFolderUninitedNode) // уже проинициализировали
                return;

            string folderName = wantedExpand.Text;

            TreeNode parent = wantedExpand.Parent;
            while (parent != null)
            {
                folderName = parent.Text + PARAM_DELIMITER + folderName;
                parent = parent.Parent;
            }
            tempSDParentNode = wantedExpand;
            PushCommandToQueue(GET_PREFIX + "LS" + PARAM_DELIMITER + folderName, DummyAnswerReceiver, SetSDFolderReadingFlag);
        }

        private void SetSDFileReadingFlag()
        {
            this.answerBehaviour = AnswerBehaviour.SDCommandFILE;
            this.SDQueryAnswer.Clear();
            ShowWaitCursor(true);
        }

        private void treeViewSD_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            TreeNode selectedNode = treeViewSD.SelectedNode;
            if (selectedNode == null)
                return;

            if (selectedNode.Tag == null)
                return;

            SDNodeTags tg = (SDNodeTags)selectedNode.Tag;
            if (tg != SDNodeTags.TagFileNode)
                return;

            string fullPathName = selectedNode.Text;

            TreeNode parent = selectedNode.Parent;
            while(parent != null)
            {
                fullPathName = parent.Text + PARAM_DELIMITER + fullPathName;
                parent = parent.Parent;
            }

            PushCommandToQueue(GET_PREFIX + "FILE" + PARAM_DELIMITER + fullPathName, DummyAnswerReceiver, SetSDFileReadingFlag);
            this.btnListSDFiles.Enabled = false;
            this.treeViewSD.Enabled = false;

        }

        private void lvSignals_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnDeleteSignal.Enabled = lvSignals.SelectedItems.Count > 0;
        }

        private void btnDeleteSignal_Click(object sender, EventArgs e)
        {
            if (lvSignals.SelectedItems.Count < 1)
                return;

            if (MessageBox.Show("Вы уверены, что хотите удалить сигнал?", "Подтверждение", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            ListViewItem li = lvSignals.SelectedItems[0];

            SignalConfigData signal = (SignalConfigData)li.Tag;
            li.Remove();

            Config.Instance.Signals.Remove(signal);
        }

        private void btnAddSignal_Click(object sender, EventArgs e)
        {
            SignalEditForm fm = new SignalEditForm();
            if(fm.ShowDialog() == DialogResult.OK)
            {
                Config.Instance.Signals.Add(fm.Signal);
                this.AddSignalToList(fm.Signal);
            }
        }

        private SignalsMapForm signalsMapForm = null;
        private void btnSignalsMap_Click(object sender, EventArgs e)
        {
            if (signalsMapForm == null)
                signalsMapForm = new SignalsMapForm(this);

            signalsMapForm.Show();
            StartQuerySignals();
        }

        public void StopQuerySignals()
        {
            tmSignals.Enabled = false;
        }

        public void StartQuerySignals()
        {
            tmSignals.Enabled = true;
            tmSignals_Tick(tmSignals, new EventArgs());
        }

        private void tmSignals_Tick(object sender, EventArgs e)
        {
            if (!this.IsConnected())
                return;

            PushCommandToQueue(GET_PREFIX + "SIG", ParseGetSignals);
        }

        private void ParseGetSignals(Answer a)
        {
            if (signalsMapForm != null)
                signalsMapForm.ParseSignals(a.Params[1]);
        }

        private void tmEnumComPorts_Tick(object sender, EventArgs e)
        {

            string[] ports = SerialPort.GetPortNames();

            // сначала удаляем те порты, которых нет в списке текущих
            List<ToolStripMenuItem> toRemove = new List<ToolStripMenuItem>();

            foreach (ToolStripMenuItem existing in btnConnect.DropDownItems)
            {
                bool found = false;
                foreach (string port in ports)
                {
                    if(port == existing.Text)
                    {
                        found = true;
                        break;
                    }
                }

                if(!found)
                {
                    toRemove.Add(existing);
                }
            }

            // теперь чистим
            for(int i=0;i< toRemove.Count;i++)
            {
                btnConnect.DropDownItems.Remove(toRemove[i]);
            }

            foreach (string port in ports)
            {
                // ищем - есть ли такой порт уже?
                bool found = false;
                foreach(ToolStripMenuItem existing in btnConnect.DropDownItems)
                {
                    if(existing.Text == port)
                    {
                        found = true;
                        break;
                    }
                }

                if (found)
                    continue;

                ToolStripMenuItem ti = new ToolStripMenuItem(port);

                ti.MergeIndex = 1;
                ti.AutoSize = true;
                ti.ImageScaling = ToolStripItemImageScaling.None;
                ti.Tag = port;
                ti.Click += ConnectToSelectedComPort;
                ti.CheckOnClick = false;



                btnConnect.DropDownItems.Add(ti);


            }
        }
    }

}
