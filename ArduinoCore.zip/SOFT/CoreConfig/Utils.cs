﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Globalization;
using System.Reflection;
using System.Drawing.Design;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.Design;

namespace CoreConfig
{
    public enum TreeNodeType
    {
        DataNode,
        MainSettingsNode,
        LoRaSettingsNode,
        RS485SettingsNode,
        ESPSettingsNode,
        SensorsNode,
        SDSettingsNode,
        SignalsSettingsNode
    }

    public enum AnswerBehaviour
    {
        Normal,
        SDCommandLS,
        SDCommandFILE,
    }

    public enum SDNodeTags
    {
        TagDummyNode = 100,
        TagFolderUninitedNode,
        TagFolderNode,
        TagFileNode
    }

    public enum CoreSensorType // тип датчика
    {
        Unknown, // неизвестный датчик
        [Description("Датчик температуры DS18B20")]
        DS18B20, // температурный датчик DS18B20
        [Description("Датчик температуры и влажности DHT")]
        DHT, // датчик влажности DHT
        [Description("Датчик температуры и влажности Si7021")]
        Si7021,  // датчик влажности Si7021
        [Description("Датчик освещённости BH1750")]
        BH1750, // датчик освещённости BH1750
        [Description("Часы реального времени DS3231")]
        DS3231, // датчик часов реального времени
        [Description("Температура часов реального времени DS3231")]
        DS3231Temperature, // температура с датчика часов реального времени
        [Description("Состояние цифрового порта")]
        DigitalPortState, // состояние цифрового порта
        [Description("Состояние аналогового порта")]
        AnalogPortState, // значение с аналогового порта
        [Description("Динамические данные")]
        UserDataSensor, // датчик "пользовательские данные"
        //TODO: Тут добавлять другие типы!!!

    }

    public class CoreSensorTypeHelper
    {
        public CoreSensorTypeHelper(CoreSensorType t)
        {
            this.sensorType = t;
        }

        private CoreSensorType sensorType = CoreSensorType.Unknown;
        public CoreSensorType SensorType
        {
            get
            {
                return this.sensorType;
            }
            set
            {
                this.sensorType = value;
            }
        }

        public override string ToString()
        {
            return EnumHelpers.GetEnumDescription(this.sensorType);
        }
    }

    public enum CoreDataType
    {
        UnknownType,
        Temperature, // температура
        Luminosity, // освещённость
        Humidity, // температура и влажность
        DateTime, // дата и время
        DigitalPort, // состояние порта
        AnalogPort, // показания аналогового порта
        UserData, // пользовательские данные
        //TODO: Тут добавлять другие типы!!!


    }

    public enum Boards
    {
        [Description("Due (SAM3X8E)")]
        Due,
        [Description("ATmega2560")]
        Mega,
        [Description("ESP8266")]
        ESP
    }

    public class SensorData
    {

        private CoreDataType dataType = CoreDataType.UnknownType;
        public CoreDataType DataType { get { return dataType; } set { dataType = value; } }

        private CoreSensorType sensorType = CoreSensorType.Unknown;
        public CoreSensorType SensorType { get { return sensorType; } set { sensorType = value; } }

        private string name = "";
        public string Name { get { return name; } set { name = value; } }

        private string data = "";
        public string Data { get { return data; } set { data = value; } }
    }


    public enum CoreConfigRecordType
    {
        DummyFirstRecord = 1, // первая запись, для проверки вхождения в диапазон

        SensorRecord = 2, // данные о датчике
        FractDelimiterRecord = 3, // данные о разделителе целой и дробной частей
        TemperatureUnitRecord = 4, // тип измерений температуры (цельсии или фаренгейты)
        ESPSettingsRecord = 5, // данные о настройках ESP
        SensorsUpdateIntervalRecord = 6, // интервал опроса датчиков
        RS485SettingsRecord = 7, // данные о настройках RS-485
      //  RS485IncomingPacketRecord = 8, // данные об известном пакете RS-485
        LoRaSettingsRecord = 8, // данные по настройкам LoRa
        DeviceIDRecord = 9, // данные по ID устройства
        ClusterIDRecord = 10, // данные о ID кластера, к которому принадлежит группа устройств
        SignalRecord = 11, // запись о сигнале
        WatchdogRecord = 12, // запись настроек ватчдога

        DummyLastRecord = 13 // последняя запись, для проверки вхождения в диапазон

    }

    public enum UnitTemperature
    {
        [Description("Цельсии")]
        UnitCelsius,
        [Description("Фаренгейты")]
        UnitFahrenheit

    }

    public enum LoraFrequency
    {
        [Description("433 MHz")]
        MHz433 = 1,
        [Description("866 MHz")]
        MHz866,
        [Description("915 MHz")]
        MHz915
    }

    public enum LoraBandwidth
    {
        [Description("7,8 KHz")]
        Hz7800 = 1,
        [Description("10,4 KHz")]
        Hz10400,
        [Description("15,6 KHz")]
        Hz15600,
        [Description("20,8 KHz")]
        Hz20800,
        [Description("31,25 KHz")]
        Hz31250,
        [Description("41,7 KHz")]
        Hz41700,
        [Description("62,5 KHz")]
        Hz62500,
        [Description("125 KHz")]
        Hz125000,
        [Description("250 KHz")]
        Hz250000
    }

    public static class Headers
    {

        public const byte CORE_HEADER1 = 0xE1;
        public const byte CORE_HEADER2 = 0xED;
        public const byte CORE_HEADER3 = 0x9F;
    }

    public enum DHTType
    {
        DHT_11,
        DHT_2x
    }

    public enum SignalEditMode
    {
        AddNew,
        EditExisting
    }

    public enum SignalOperands // операнды для работы с сигналом
    {
        [Description("Нет данных с датчика")]
        sopCompareNoData = 1,   // сравнить с показаниями "нет данных"
        [Description("Интервал")]
        sopInterval,        // A between B and C
        [Description("Равно")]
        sopEqual,           // ==
        [Description("Меньше")]
        sopLess,            // <
        [Description("Меньше либо равно")]
        sopLessOrEqual,     // <=
        [Description("Больше")]
        sopGreater,         // >
        [Description("Больше либо равно")]
        sopGreaterOrEqual,  // >=
        [Description("Не равно")]
        sopNotEqual,        // != 

    }

    public enum SignalActions // возможные действия в записи сигнала в конфиге
    {
        [Description("Взвести сигнал")]
        saRaiseSignal, // взвести сигнал
        [Description("Сбросить сигнал")]
        saResetSignal // сбросить сигнал

    }

    public class SignalOneAction
    {
        private SignalActions action = SignalActions.saRaiseSignal;
        public SignalActions Action
        {
            get { return action; }
            set { action = value; }
        }

        private byte[] actionData = null;
        public byte[] ActionData
        {
            get { return actionData; }
            set { actionData = value; }
        }
    }



    public class SignalConfigData
    {
        public override string ToString()
        {
            string result = "";
            if (this.sensorName.Length > 0)
                result += this.sensorName;
            else
                result += "не назначено";

            return result;
        }

        public int RecordLength
        {
            get { return getRecordLength(); }
        }

        private int getRecordLength()
        {
            int result = 1; // work on time byte

            if (this.workOnTime)
                result += 5; // time bytes

            result++; // operand byte
            result++; // compare data length byte

            // data length
            if(this.data != null)
                result += this.data.Length;

            // actions count byte
            result++;

            // actions bytes
            for(int i=0;i<this.actions.Count;i++)
            {
                result += 2;
                if (this.actions[i].ActionData != null)
                    result += this.actions[i].ActionData.Length;
            }

            result += sensorName.Length + 1;

            return result;
        }

        private string sensorName = "";
        public string SensorName
        {
            get { return sensorName; }
            set { sensorName = value; }
        }

        private bool workOnTime = false;
        public bool WorkOnTime
        {
            get { return workOnTime; }
            set { workOnTime = value; }
        }

        private byte daymask = 0;
        public byte Daymask
        {
            get { return daymask; }
            set { daymask = value; }
        }

        private byte startHour = 0;
        public byte StartHour
        {
            get { return startHour; }
            set { startHour = value; }
        }

        private byte startMinute = 0;
        public byte StartMinute
        {
            get { return startMinute; }
            set { startMinute = value; }
        }

        private byte endHour = 0;
        public byte EndHour
        {
            get { return endHour; }
            set { endHour = value; }
        }

        private byte endMinute = 0;
        public byte EndMinute
        {
            get { return endMinute; }
            set { endMinute = value; }
        }

        private SignalOperands op = SignalOperands.sopCompareNoData;
        public SignalOperands Operand
        {
            get { return op; }
            set { op = value; }
        }

        private byte[] data = null;
        public byte[] Data
        {
            get { return data; }
            set { data = value; }
        }

        private List<SignalOneAction> actions = new List<SignalOneAction>();
        public List<SignalOneAction> Actions
        {
            get { return actions; }
            set { actions = value; }
        }

    }

    public class SensorConfigData
    {
        private string sensorName = "";
        public string SensorName { get { return sensorName; } set { sensorName = value; } }

        private CoreSensorType sensorType = CoreSensorType.Unknown;
        public CoreSensorType SensorType { get { return sensorType; } set { sensorType = value; } }

        private byte dataLength = 0;
        public byte DataLength { get { return dataLength; } set { dataLength = value; } }

        private byte[] data = null;
        public byte[] Data { get { return data; } set { data = value; } }

        public override string ToString()
        {
            return SensorName;
        }

        public string GetAdditionalInfo()
        {
            string result = "";
            switch(SensorType)
            {
                case CoreSensorType.AnalogPortState:
                    result = "пин: " + GetPinString(Data[0]);
                    break;

                case CoreSensorType.BH1750:
                    result = "I2C: ";
                    if (Data[0] == 0)
                        result += "Wire; ";
                    else
                        result += "Wire1; ";
                    result += "адрес: 0x" + Data[1].ToString("X2");
                    break;

                case CoreSensorType.DHT:
                    result = "тип: ";
                    if (DHTType.DHT_11 == (DHTType)Data[0])
                        result += "DHT1x; ";
                    else
                        result += "DHT2x; ";

                    result += "пин: ";
                    result += GetPinString(Data[1]);
                    break;

                case CoreSensorType.DigitalPortState:
                    result = "пин: " + GetPinString(Data[0]);
                    break;

                case CoreSensorType.DS18B20:
                    result = "пин: " + GetPinString(Data[0]);
                    break;

                case CoreSensorType.DS3231:
                case CoreSensorType.DS3231Temperature:
                case CoreSensorType.Si7021:
                    result = "I2C: ";
                    if (Data[0] == 0)
                        result += "Wire";
                    else
                        result += "Wire1";
                    break;


                case CoreSensorType.Unknown:
                    break;

                case CoreSensorType.UserDataSensor:
                    result = "длина данных, байт: ";
                    result += Data[0].ToString();
                    break;
            }

            return result;
        }

        public static string GetPinString(byte pin)
        {
            string result = "";
            switch(Config.Instance.Board)
            {
                case Boards.Mega:
                case Boards.Due:
                    {
                        if (pin >= 54 && pin <= 69)
                            result = "A" + (pin - 54).ToString();
                        else
                            result = pin.ToString();
                    }
                    break;

                case Boards.ESP:
                default:
                    {
                        result = pin.ToString();
                    }
                    break;
            }
            return result;
        }

        public static string GetDataTypeString(CoreDataType type)
        {
            switch (type)
            {
                case CoreDataType.AnalogPort:
                    return "напряжение";

                case CoreDataType.DateTime:
                    return "дата/время";

                case CoreDataType.DigitalPort:
                    return "состояние порта";

                case CoreDataType.Humidity:
                    return "влажность";

                case CoreDataType.Luminosity:
                    return "освещённость";

                case CoreDataType.Temperature:
                    return "температура";

                case CoreDataType.UserData:
                    return "пользовательский";

                case CoreDataType.UnknownType:
                    return "-";
            }

            return "-";
        }

        public static string GetTypeString(CoreSensorType type)
        {
            switch (type)
            {
                case CoreSensorType.AnalogPortState:
                    return "аналоговый порт";

                case CoreSensorType.DigitalPortState:
                    return "цифровой порт";

                case CoreSensorType.DS3231:
                    return "часы";

                case CoreSensorType.DS3231Temperature:
                    return "температура часов";

                case CoreSensorType.UserDataSensor:
                    return "динамический";

                case CoreSensorType.Unknown:
                    return "-";

                default:
                    return type.ToString();


            }

            //return "-";

        }
    }

    public class ESPSettingsConfigData
    {
        private string apName = "";
        public string APName { get { return apName; } set { apName = value; } }

        private string apPass = "";
        public string APPassword { get { return apPass; } set { apPass = value; } }

        private byte connectToRouter = 1;
        public byte ConnectToRouter { get { return connectToRouter; } set { connectToRouter = value; } }

        private string routerId = "";
        public string RouterID { get { return routerId; } set { routerId = value; } }

        private string routerPass = "";
        public string RouterPassword { get { return routerPass; } set { routerPass = value; } }

        private byte uartSpeed = 12;
        public byte UartSpeed { get { return uartSpeed; } set { uartSpeed = value; } }

        private byte serialNumber = 1;
        public byte SerialNumber { get { return serialNumber; } set { serialNumber = value; } }

        private byte useRebootPin = 0;
        public byte UseRebootPin { get { return useRebootPin; } set { useRebootPin = value; } }

        private byte rebootPin = 0;
        public byte RebootPinNumber { get { return rebootPin; } set { rebootPin = value; } }

        private byte hangTimeout = 30;
        public byte HangTimeout { get { return hangTimeout; } set { hangTimeout = value; } }

        private byte hangPowerOffTime = 2;
        public byte HangPowerOffTime { get { return hangPowerOffTime; } set { hangPowerOffTime = value; } }

        private byte waitInitTime = 2;
        public byte WaitInitTime { get { return waitInitTime; } set { waitInitTime = value; } }

        private byte powerOnLevel = 1;
        public byte PowerOnLevel { get { return powerOnLevel; } set { powerOnLevel = value; } }
    }

    public class RS485SettingsConfigData
    {
        private byte uartSpeed = 6;
        public byte UartSpeed { get { return uartSpeed; } set { uartSpeed = value; } }

        private byte serialNumber = 2;
        public byte SerialNumber { get { return serialNumber; } set { serialNumber = value; } }

        private byte dePin = 4;
        public byte DEPin { get { return dePin; } set { dePin = value; } }

        private byte isMaster = 1;
        public byte IsMasterMode { get { return isMaster; } set { isMaster = value; } }
    }

    /*
    public class RS485IncomingPacketConfigData
    {
        public byte HeaderLength { get; set; }
        public byte[] Header { get; set; }
        public byte PacketLength { get; set; }
        public byte PacketID { get; set; }
    }
    */

    public class WatchdogSettingsData
    {
        private bool watchdogEnabled = false;
        public bool WatchdogEnabled
        {
            get { return watchdogEnabled; }
            set { watchdogEnabled = value; }
        }

        private byte watchdogPin = 0;
        public byte WatchdogPin
        {
            get { return watchdogPin; }
            set { watchdogPin = value; }
        }

        private ushort watchdogInterval = 0;
        public ushort WatchdogInterval
        {
            get { return watchdogInterval; }
            set { watchdogInterval = value; }
        }

        private ushort watchdogPulseDuration = 0;
        public ushort WatchdogPulseDuration
        {
            get { return watchdogPulseDuration; }
            set { watchdogPulseDuration = value; }
        }

    }

    public class LoRaSettingsConfigData
    {
        private LoraFrequency freq = LoraFrequency.MHz433;
        public LoraFrequency Frequency
        {
            get { return freq; }
            set { freq = value; }
       }
        private byte ssPin = 5;
        public byte SSPin { get { return ssPin; } set { ssPin = value; } }

        private byte resetPin = 0xFF;
        public byte ResetPin { get { return resetPin; } set { resetPin = value; } }

        private byte dioPin = 2;
        public byte DIOPin { get { return dioPin; } set { dioPin = value; } }

        private byte txPower = 17;
        public byte TXPower { get { return txPower; } set { txPower = value; } }

        private LoraBandwidth bw = LoraBandwidth.Hz125000;
        public LoraBandwidth Bandwidth
        {
            get { return bw; }
            set { bw = value; }
        }
        private byte useCrc = 0;
        public byte UseCRC { get { return useCrc; } set { useCrc = value; } }

        private byte isMaster = 0;
        public byte IsMasterMode { get { return isMaster; } set { isMaster = value; } }

        private byte retransmitCount = 5;
        public byte RetransmitCount
        {
            get { return retransmitCount; }
            set { retransmitCount = value; }
        }

        private byte sendDuration = 20;
        public byte SendDuration
        {
            get { return sendDuration; }
            set { sendDuration = value; }
        }
    }

    public class MyEnumConverter : EnumConverter
    {
        private Type type;

        public MyEnumConverter(Type type)
            : base(type)
        {
            this.type = type;
        }


        public override object ConvertTo(ITypeDescriptorContext context,
            CultureInfo culture, object value, Type destType)
        {
            try
            {
                FieldInfo fi = type.GetField(Enum.GetName(type, value));
                DescriptionAttribute descAttr =
                  (DescriptionAttribute)Attribute.GetCustomAttribute(
                    fi, typeof(DescriptionAttribute));

                if (descAttr != null)
                    return descAttr.Description;
                else
                    return value.ToString();
            }
            catch
            {
                return Enum.GetValues(type).GetValue(0);
            }
        }

        public override object ConvertFrom(ITypeDescriptorContext context,
            CultureInfo culture, object value)
        {
            foreach (FieldInfo fi in type.GetFields())
            {
                DescriptionAttribute descAttr =
                  (DescriptionAttribute)Attribute.GetCustomAttribute(
                    fi, typeof(DescriptionAttribute));

                if ((descAttr != null) && ((string)value == descAttr.Description))
                    return Enum.Parse(type, fi.Name);
            }
            return Enum.Parse(type, (string)value);
        }
    }

    public class EnumHelpers
    {
        public static string GetEnumDescription(Enum value)
        {
            FieldInfo fi = value.GetType().GetField(value.ToString());

            DescriptionAttribute[] attributes =
                (DescriptionAttribute[])fi.GetCustomAttributes(
                typeof(DescriptionAttribute),
                false);

            if (attributes != null &&
                attributes.Length > 0)
                return attributes[0].Description;
            else
                return value.ToString();
        }

        public static T GetValueFromDescription<T>(string description)
        {
            var type = typeof(T);
            if (!type.IsEnum) throw new InvalidOperationException();
            foreach (var field in type.GetFields())
            {
                var attribute = Attribute.GetCustomAttribute(field,
                    typeof(DescriptionAttribute)) as DescriptionAttribute;
                if (attribute != null)
                {
                    if (attribute.Description == description)
                        return (T)field.GetValue(null);
                }
                else
                {
                    if (field.Name == description)
                        return (T)field.GetValue(null);
                }
            }
            throw new ArgumentException("Not found.", "description");
            // or return default(T);
        }
    }

    class YesNoConverter : BooleanConverter
    {
        public override object ConvertTo(ITypeDescriptorContext context, System.Globalization.CultureInfo culture, object value, Type destinationType)
        {
            if (value is bool && destinationType == typeof(string))
            {
                return values[(bool)value ? 1 : 0];
            }
            return base.ConvertTo(context, culture, value, destinationType);
        }

        public override object ConvertFrom(ITypeDescriptorContext context, System.Globalization.CultureInfo culture, object value)
        {
            string txt = value as string;
            if (values[0] == txt) return false;
            if (values[1] == txt) return true;
            return base.ConvertFrom(context, culture, value);
        }

        private string[] values = new string[] { "Нет", "Да" };
    }

    /// <summary>
    /// Range modification for direct edit override
    /// </summary>
    public class NumericUpDownTypeConverter : TypeConverter
    {
        public override bool CanConvertFrom(ITypeDescriptorContext context, Type sourceType)
        {
            // Attempt to do them all
            return true;
        }


        public override object ConvertFrom(ITypeDescriptorContext context, CultureInfo culture, object value)
        {
            try
            {
                string Value;
                if (!(value is string))
                {
                    Value = Convert.ChangeType(value, context.PropertyDescriptor.PropertyType).ToString();
                }
                else
                    Value = value as string;
                decimal decVal;
                if (!decimal.TryParse(Value, out decVal))
                    decVal = decimal.One;
                MinMaxAttribute attr = (MinMaxAttribute)context.PropertyDescriptor.Attributes[typeof(MinMaxAttribute)];
                if (attr != null)
                {
                    decVal = attr.PutInRange(decVal);
                }
                return Convert.ChangeType(decVal, context.PropertyDescriptor.PropertyType);
            }
            catch
            {
                return base.ConvertFrom(context, culture, value);
            }
        }

        public override object ConvertTo(ITypeDescriptorContext context, CultureInfo culture, object value, Type destinationType)
        {
            try
            {
                return destinationType == typeof(string)
                   ? Convert.ChangeType(value, context.PropertyDescriptor.PropertyType).ToString()
                   : Convert.ChangeType(value, destinationType);
            }
            catch { }
            return base.ConvertTo(context, culture, value, destinationType);
        }
    }

    // ReSharper disable MemberCanBePrivate.Global
    /// <summary>
    /// Attribute to allow ranges to be added to the numeric updowner
    /// </summary>
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false)]
    public class MinMaxAttribute : Attribute
    {
        public decimal Min { get; private set; }
        public decimal Max { get; private set; }
        public decimal Increment { get; private set; }
        public int DecimalPlaces { get; private set; }

        /// <summary>
        /// Use to make a simple UInt16 max. Starts at 0, increment = 1
        /// </summary>
        /// <param name="max"></param>
        public MinMaxAttribute(UInt16 max)
           : this((decimal)UInt16.MinValue, max)
        {
        }

        /// <summary>
        /// Use to make a simple integer (or default conversion) based range.
        /// default inclrement is 1
        /// </summary>
        /// <param name="min"></param>
        /// <param name="max"></param>
        /// <param name="increment"></param>
        public MinMaxAttribute(int min, int max, int increment = 1)
           : this((decimal)min, max, increment)
        {
        }

        /// <summary>
        /// Set the Min, Max, increment, and decimal places to be used.
        /// </summary>
        /// <param name="min"></param>
        /// <param name="max"></param>
        /// <param name="increment"></param>
        /// <param name="decimalPlaces"></param>
        public MinMaxAttribute(decimal min, decimal max, decimal increment = decimal.One, int decimalPlaces = 0)
        {
            Min = min;
            Max = max;
            Increment = increment;
            DecimalPlaces = decimalPlaces;
        }

        /// <summary>
        /// Validation function to check if the value is withtin the range (inclusive)
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public bool IsInRange(object value)
        {
            decimal checkedValue = (decimal)Convert.ChangeType(value, typeof(decimal));
            return ((checkedValue <= Max)
               && (checkedValue >= Min)
               );
        }

        /// <summary>
        /// Takes the value and adjusts if it is out of bounds.
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public decimal PutInRange(object value)
        {
            decimal checkedValue = (decimal)Convert.ChangeType(value, typeof(decimal));
            if (checkedValue > Max)
                checkedValue = Max;
            else if (checkedValue < Min)
                checkedValue = Min;
            return checkedValue;
        }
    }
    // ReSharper restore MemberCanBePrivate.Global


    public class NumericUpDownTypeEditor : UITypeEditor
    {
        public override UITypeEditorEditStyle GetEditStyle(ITypeDescriptorContext context)
        {
            if (context == null || context.Instance == null)
                return base.GetEditStyle(context);
            return context.PropertyDescriptor.IsReadOnly ? UITypeEditorEditStyle.None : UITypeEditorEditStyle.DropDown;
        }

        public override object EditValue(ITypeDescriptorContext context, IServiceProvider provider, object value)
        {
            try
            {
                if (context == null || context.Instance == null || provider == null)
                    return value;

                //use IWindowsFormsEditorService object to display a control in the dropdown area  
                IWindowsFormsEditorService frmsvr = (IWindowsFormsEditorService)provider.GetService(typeof(IWindowsFormsEditorService));
                if (frmsvr == null)
                    return value;

                MinMaxAttribute attr = (MinMaxAttribute)context.PropertyDescriptor.Attributes[typeof(MinMaxAttribute)];
                if (attr != null)
                {
                    NumericUpDown nmr = new NumericUpDown
                    {
                        Size = new Size(60, 120),
                        Minimum = attr.Min,
                        Maximum = attr.Max,
                        Increment = attr.Increment,
                        DecimalPlaces = attr.DecimalPlaces,
                        Value = attr.PutInRange(value)
                    };
                    frmsvr.DropDownControl(nmr);
                    context.OnComponentChanged();
                    return Convert.ChangeType(nmr.Value, context.PropertyDescriptor.PropertyType);
                }
            }
            catch { }
            return value;
        }
    }

    public enum UARTSpeed
    {
        [Description("9600")]
        Speed9600 = 1,

        [Description("19200")]
        Speed1920 = 2,

        [Description("38400")]
        Speed38400 = 4,

        [Description("57600")]
        Speed57600 = 6,

        [Description("115200")]
        Speed115200 = 12
    }

    public class ConsistencyChecker
    {
        public static bool UARTSpeedValid(byte b)
        {
            return b == (byte)UARTSpeed.Speed115200 || b == (byte)UARTSpeed.Speed1920 || b == (byte)UARTSpeed.Speed38400 
                || b == (byte)UARTSpeed.Speed57600 || b == (byte) UARTSpeed.Speed9600;
        }

        public static bool LoRaFrequencyValid(byte b)
        {
            return b == (byte)LoraFrequency.MHz433 || b == (byte)LoraFrequency.MHz866 || b == (byte)LoraFrequency.MHz915;
        }

        public static bool LoRaBandwidthValid(byte b)
        {
            byte beg = (byte)LoraBandwidth.Hz7800;
            byte end = (byte)LoraBandwidth.Hz250000;

            return (b >= beg && b <= end);
        }

        public static bool SignalOperandValid(byte b)
        {
            byte beg = (byte)SignalOperands.sopCompareNoData;
            byte end = (byte)SignalOperands.sopNotEqual;

            return (b >= beg && b <= end);

        }

        public static bool SignalActionValid(byte b)
        {
            return b == (byte)SignalActions.saRaiseSignal || b == (byte)SignalActions.saResetSignal;
        }

        public static bool SensorTypeValid(byte b)
        {
            byte beg = (byte)CoreSensorType.Unknown;
            byte end = (byte)CoreSensorType.UserDataSensor;

            return (b >= beg && b <= end);
        }
    }

    public enum UARTNumber
    {
        /*
        [Description("Serial")]
        Serial,
        */

        [Description("Serial1")]
        Serial1 = 1,

        [Description("Serial2")]
        Serial2,

        [Description("Serial3")]
        Serial3,

    }

    public enum TransportWorkMode
    {
        [Description("Режим слейва")]
        SlaveMode,
        [Description("Режим мастера")]
        MasterMode
    }

    public enum PowerLevel
    {
        [Description("Низкий")]
        Low,
        [Description("Высокий")]
        High

    }

    public abstract class SensorEditor
    {

        protected CoreSensorType sensorType = CoreSensorType.Unknown;
        [Browsable(false)]
        public CoreSensorType SensorType
        {
            get { return this.sensorType; }
            set { this.sensorType = value; }
        }

        protected byte dataLength = 0;
        [Browsable(false)]
        public byte DataLength
        {
            get { return this.dataLength; }
            set { this.dataLength = value; }
        }

        protected byte[] data = null;
        [Browsable(false)]
        public byte[] Data
        {
            get { return this.data; }
            set { this.data = value; }
        }

        protected string sensorName = "";
        [Browsable(true)]
        [Category("Идентификация")]
        [Description("Уникальное имя датчика в кластере (максимум 9 символов).")]
        [DisplayName("Имя датчика")]
        public string SensorName { get { return this.sensorName; } set { this.sensorName = value; } }
        public bool ShouldSerializeSensorName() { return false; }

        public SensorEditor(byte dl, CoreSensorType st)
        {
            this.dataLength = dl;
            this.data = new byte[dl];
            this.sensorType = st;
        }

        public abstract void FillData();
    }

    public class PinNumberEditor : SensorEditor
    {
        public PinNumberEditor(CoreSensorType st) : base(1,st)
        {
        }

        public override void FillData()
        {
            this.data[0] = this.pinNumber;
        }

        private byte pinNumber = 0;
        [Browsable(true)]
        [Category("Настройки")]
        [Description("Номер пина, к которому прикреплён датчик.")]
        [DisplayName("Номер пина")]
        [TypeConverter(typeof(NumericUpDownTypeConverter))]
        [Editor(typeof(NumericUpDownTypeEditor), typeof(UITypeEditor)), MinMaxAttribute(0, 255)]
        public byte PinNumber { get { return this.pinNumber; } set { this.pinNumber = value; } }
        public bool ShouldSerializePinNumber() { return false; }
    }

    public enum I2CTypes
    {
        Wire,
        Wire1
    }

    public enum BH1750Addresses
    {
        [Description("Первый адрес на шине")]
        FirstAddress = 0x23,
        [Description("Второй адрес на шине")]
        SecondAddress = 0x5C
    }

    public class BH1750Editor : SensorEditor
    {
        public BH1750Editor(CoreSensorType st) : base(2, st)
        {
        }
        public override void FillData()
        {
            this.data[0] = (byte) this.i2CNumber;
            this.data[1] = (byte) this.address;
        }
        private I2CTypes i2CNumber = I2CTypes.Wire;
        [Browsable(true)]
        [Category("Настройки")]
        [Description("Номер I2C, к которому прикреплён датчик.")]
        [DisplayName("Номер I2C")]
        [TypeConverter(typeof(MyEnumConverter))]
        public I2CTypes I2CNumber { get { return this.i2CNumber; } set { this.i2CNumber = value; } }
        public bool ShouldSerializeI2CNumber() { return false; }

        private BH1750Addresses address = BH1750Addresses.FirstAddress;
        [Browsable(true)]
        [Category("Настройки")]
        [Description("Адрес датчика на шине I2C.")]
        [DisplayName("Адрес на шине")]
        [TypeConverter(typeof(MyEnumConverter))]
        public BH1750Addresses Address { get { return this.address; } set { this.address = value; } }
        public bool ShouldSerializeAddress() { return false; }
    }

    public class I2CEditor : SensorEditor
    {
        public I2CEditor(CoreSensorType st) : base(1, st)
        {
        }
        public override void FillData()
        {
            this.data[0] = (byte)this.i2CNumber;
        }
        private I2CTypes i2CNumber = I2CTypes.Wire;
        [Browsable(true)]
        [Category("Настройки")]
        [Description("Номер I2C, к которому прикреплён датчик.")]
        [DisplayName("Номер I2C")]
        [TypeConverter(typeof(MyEnumConverter))]
        public I2CTypes I2CNumber { get { return this.i2CNumber; } set { this.i2CNumber = value; } }
        public bool ShouldSerializeI2CNumber() { return false; }

    }

    public class DHTEditor : SensorEditor
    {
        public DHTEditor(CoreSensorType st) : base(2, st)
        {
        }
        public override void FillData()
        {
            this.data[0] = (byte)this.dhtType;
            this.data[1] = this.pinNumber;
        }
        private DHTType dhtType = DHTType.DHT_2x;
        [Browsable(true)]
        [Category("Настройки")]
        [Description("Тип датчика DHT.")]
        [DisplayName("Тип датчика")]
        [TypeConverter(typeof(MyEnumConverter))]
        public DHTType DHTType { get { return this.dhtType; } set { this.dhtType = value; } }
        public bool ShouldSerializeDHTType() { return false; }

        private byte pinNumber = 0;
        [Browsable(true)]
        [Category("Настройки")]
        [Description("Номер пина, к которому прикреплён датчик.")]
        [DisplayName("Номер пина")]
        [TypeConverter(typeof(NumericUpDownTypeConverter))]
        [Editor(typeof(NumericUpDownTypeEditor), typeof(UITypeEditor)), MinMaxAttribute(0, 255)]
        public byte PinNumber { get { return this.pinNumber; } set { this.pinNumber = value; } }
        public bool ShouldSerializePinNumber() { return false; }
    }

    public class UserdataSensorEditor : SensorEditor
    {
        public UserdataSensorEditor(CoreSensorType st) : base(1, st)
        {
        }
        public override void FillData()
        {
            this.data[0] = this.userdataLength;
        }

        private byte userdataLength = 1;
        [Browsable(true)]
        [Category("Настройки")]
        [Description("Длина данных, хранимых датчиком.")]
        [DisplayName("Длина данных")]
        [TypeConverter(typeof(NumericUpDownTypeConverter))]
        [Editor(typeof(NumericUpDownTypeEditor), typeof(UITypeEditor)), MinMaxAttribute(1, 255)]
        public byte UserdataLength { get { return this.userdataLength; } set { this.userdataLength = value; } }
        public bool ShouldSerializeUserdataLength() { return false; }
    }

    public class ConfigESPSettings
    {
        [Browsable(true)]
        [Category("1. Основные настройки")]
        [Description("Скорость работы UART, бод.")]
        [DisplayName("Скорость UART")]
        [TypeConverter(typeof(MyEnumConverter))]
        public UARTSpeed UARTSpeed { get { return (UARTSpeed)Config.Instance.ESPSettings.UartSpeed; } set { Config.Instance.ESPSettings.UartSpeed = (byte)value; } }
        public bool ShouldSerializeUARTSpeed() { return false; }

        [Browsable(true)]
        [Category("1. Основные настройки")]
        [Description("Номер используемого UART.")]
        [DisplayName("Номер UART")]
        [TypeConverter(typeof(MyEnumConverter))]
        public UARTNumber UARTNum { get { return (UARTNumber)Config.Instance.ESPSettings.SerialNumber; } set { Config.Instance.ESPSettings.SerialNumber = (byte)value; } }
        public bool ShouldSerializeUARTNum() { return false; }

        [Browsable(true)]
        [Category("1. Основные настройки")]
        [Description("Соединение с роутером при старте?")]
        [DisplayName("Соединение с роутером")]
        [TypeConverter(typeof(YesNoConverter))]
        public bool ConnectToRouter { get { return Config.Instance.ESPSettings.ConnectToRouter == 1 ? true : false; } set { if (value) Config.Instance.ESPSettings.ConnectToRouter = 1; else Config.Instance.ESPSettings.ConnectToRouter = 0; } }
        public bool ShouldSerializeConnectToRouter() { return false; }

        [Browsable(true)]
        [Category("2. Точка доступа")]
        [Description("Имя точки доступа.")]
        [DisplayName("Имя точки доступа")]
        public string APName { get { return Config.Instance.ESPSettings.APName; } set { Config.Instance.ESPSettings.APName = value; } }
        public bool ShouldSerializeAPName() { return false; }

        [Browsable(true)]
        [Category("2. Точка доступа")]
        [Description("Пароль точки доступа (минимум 8 символов!).")]
        [DisplayName("Пароль точки доступа")]
        [PasswordPropertyText(true)]
        public string APPassword { get { return Config.Instance.ESPSettings.APPassword; } set { Config.Instance.ESPSettings.APPassword = value; } }
        public bool ShouldSerializeAPPassword() { return false; }

        [Browsable(true)]
        [Category("3. Роутер")]
        [Description("SSID роутера.")]
        [DisplayName("SSID роутера")]
        public string RouterID { get { return Config.Instance.ESPSettings.RouterID; } set { Config.Instance.ESPSettings.RouterID = value; } }
        public bool ShouldSerializeRouterID() { return false; }

        [Browsable(true)]
        [Category("3. Роутер")]
        [Description("Пароль роутера.")]
        [DisplayName("Пароль роутера")]
        [PasswordPropertyText(true)]
        public string RouterPassword { get { return Config.Instance.ESPSettings.RouterPassword; } set { Config.Instance.ESPSettings.RouterPassword = value; } }
        public bool ShouldSerializeRouterPassword() { return false; }

        [Browsable(true)]
        [Category("4. Дополнительно")]
        [Description("Использовать ли пин пересброса питания при зависании ESP?")]
        [DisplayName("Управление питанием")]
        [TypeConverter(typeof(YesNoConverter))]
        public bool UseRebootPin { get { return Config.Instance.ESPSettings.UseRebootPin == 1 ? true : false; } set { if (value) Config.Instance.ESPSettings.UseRebootPin = 1; else Config.Instance.ESPSettings.UseRebootPin = 0; } }
        public bool ShouldSerializeUseRebootPin() { return false; }


        [Browsable(true)]
        [Category("4. Дополнительно")]
        [Description("Номер пина для пересброса питания ESP.")]
        [DisplayName("Пин питания")]
        [TypeConverter(typeof(NumericUpDownTypeConverter))]
        [Editor(typeof(NumericUpDownTypeEditor), typeof(UITypeEditor)), MinMaxAttribute(0, 255)]
        public byte RebootPinNumber { get { return Config.Instance.ESPSettings.RebootPinNumber; } set { Config.Instance.ESPSettings.RebootPinNumber = value; } }
        public bool ShouldSerializeRebootPinNumber() { return false; }

        [Browsable(true)]
        [Category("4. Дополнительно")]
        [Description("Кол-во секунд, по истечении которых ESP считается зависшим.")]
        [DisplayName("Таймаут ожидания ответа, с")]
        [TypeConverter(typeof(NumericUpDownTypeConverter))]
        [Editor(typeof(NumericUpDownTypeEditor), typeof(UITypeEditor)), MinMaxAttribute(0, 255)]
        public byte HangTimeout { get { return Config.Instance.ESPSettings.HangTimeout; } set { Config.Instance.ESPSettings.HangTimeout = value; } }
        public bool ShouldSerializeHangTimeout() { return false; }

        [Browsable(true)]
        [Category("4. Дополнительно")]
        [Description("Cколько секунд держать питание выключенным при перезагрузке ESP.")]
        [DisplayName("Длительность пересброса, с")]
        [TypeConverter(typeof(NumericUpDownTypeConverter))]
        [Editor(typeof(NumericUpDownTypeEditor), typeof(UITypeEditor)), MinMaxAttribute(0, 255)]
        public byte HangPowerOffTime { get { return Config.Instance.ESPSettings.HangPowerOffTime; } set { Config.Instance.ESPSettings.HangPowerOffTime = value; } }
        public bool ShouldSerializeHangPowerOffTime() { return false; }

        [Browsable(true)]
        [Category("4. Дополнительно")]
        [Description("Cколько секунд ждать загрузки ESP при инициализации/переинициализации.")]
        [DisplayName("Ожидание инициализации, с")]
        [TypeConverter(typeof(NumericUpDownTypeConverter))]
        [Editor(typeof(NumericUpDownTypeEditor), typeof(UITypeEditor)), MinMaxAttribute(0, 255)]
        public byte WaitInitTime { get { return Config.Instance.ESPSettings.WaitInitTime; } set { Config.Instance.ESPSettings.WaitInitTime = value; } }
        public bool ShouldSerializeWaitInitTime() { return false; }

        [Browsable(true)]
        [Category("4. Дополнительно")]
        [Description("Уровень для включения питания ESP.")]
        [DisplayName("Уровень включения")]
        [TypeConverter(typeof(MyEnumConverter))]
        public PowerLevel PowerLevel { get { return (PowerLevel) Config.Instance.ESPSettings.PowerOnLevel; } set { Config.Instance.ESPSettings.PowerOnLevel = (byte)value; } }
        public bool ShouldSerializePowerLevel() { return false; }

    }

    public class ConfigRS485Settings
    {
        [Browsable(true)]
        [Category("1. Основные настройки")]
        [Description("Скорость работы UART, бод.")]
        [DisplayName("Скорость UART")]
        [TypeConverter(typeof(MyEnumConverter))]
        public UARTSpeed UARTSpeed { get { return (UARTSpeed) Config.Instance.RS485Settings.UartSpeed; } set { Config.Instance.RS485Settings.UartSpeed = (byte)value; } }
        public bool ShouldSerializeUARTSpeed() { return false; }

        [Browsable(true)]
        [Category("1. Основные настройки")]
        [Description("Номер используемого UART.")]
        [DisplayName("Номер UART")]
        [TypeConverter(typeof(MyEnumConverter))]
        public UARTNumber UARTNum { get { return (UARTNumber) Config.Instance.RS485Settings.SerialNumber; } set { Config.Instance.RS485Settings.SerialNumber = (byte)value; } }
        public bool ShouldSerializeUARTNum() { return false; }

        [Browsable(true)]
        [Category("1. Основные настройки")]
        [Description("Номер пина управления приёмом/передачей RS-485.")]
        [DisplayName("Пин направления")]
        [TypeConverter(typeof(NumericUpDownTypeConverter))]
        [Editor(typeof(NumericUpDownTypeEditor), typeof(UITypeEditor)), MinMaxAttribute(0, 255)]
        public byte DEPin { get { return Config.Instance.RS485Settings.DEPin; } set { Config.Instance.RS485Settings.DEPin = value; } }
        public bool ShouldSerializeDEPin() { return false; }

        [Browsable(true)]
        [Category("1. Основные настройки")]
        [Description("Режим работы RS-485.")]
        [DisplayName("Режим работы")]
        [TypeConverter(typeof(MyEnumConverter))]
        public TransportWorkMode WorkMode { get { return (TransportWorkMode)Config.Instance.RS485Settings.IsMasterMode; } set { Config.Instance.RS485Settings.IsMasterMode = (byte)value; } }
        public bool ShouldSerializeWorkMode() { return false; }


    }

    public class ConfigLoRaSettings
    {
        [Browsable(true)]
        [Category("1. Основные настройки")]
        [Description("Ширина полосы пропускания сигнала.")]
        [DisplayName("Полоса пропускания")]
        [TypeConverter(typeof(MyEnumConverter))]
        public LoraBandwidth Bandwidth { get { return Config.Instance.LoRaSettings.Bandwidth; } set { Config.Instance.LoRaSettings.Bandwidth = value; } }
        public bool ShouldSerializeBandwidth() { return false; }

        [Browsable(true)]
        [Category("1. Основные настройки")]
        [Description("Рабочая частота.")]
        [DisplayName("Рабочая частота")]
        [TypeConverter(typeof(MyEnumConverter))]
        public LoraFrequency Frequency { get { return Config.Instance.LoRaSettings.Frequency; } set { Config.Instance.LoRaSettings.Frequency = value; } }
        public bool ShouldSerializeFrequency() { return false; }

        [Browsable(true)]
        [Category("1. Основные настройки")]
        [Description("Использовать CRC?")]
        [DisplayName("Контрольная сумма")]
        [TypeConverter(typeof(YesNoConverter))]
        public bool UseCRC { get { return Config.Instance.LoRaSettings.UseCRC == 1 ? true : false; } set { if (value) Config.Instance.LoRaSettings.UseCRC = 1; else Config.Instance.LoRaSettings.UseCRC = 0; } }
        public bool ShouldSerializeUseCRC() { return false; }

        [Browsable(true)]
        [Category("1. Основные настройки")]
        [Description("Режим работы LoRa.")]
        [DisplayName("Режим работы")]
        [TypeConverter(typeof(MyEnumConverter))]
        public TransportWorkMode WorkMode { get { return (TransportWorkMode)Config.Instance.LoRaSettings.IsMasterMode; } set { Config.Instance.LoRaSettings.IsMasterMode = (byte)value; } }
        public bool ShouldSerializeWorkMode() { return false; }


        [Browsable(true)]
        [Category("1. Основные настройки")]
        [Description("Мощность передатчика.")]
        [DisplayName("Мощность передатчика")]
        [TypeConverter(typeof(NumericUpDownTypeConverter))]
        [Editor(typeof(NumericUpDownTypeEditor), typeof(UITypeEditor)), MinMaxAttribute(2, 17)]
        public byte TXPower { get { return Config.Instance.LoRaSettings.TXPower; } set { Config.Instance.LoRaSettings.TXPower = value; } }
        public bool ShouldSerializeTXPower() { return false; }

        [Browsable(true)]
        [Category("1. Основные настройки")]
        [Description("Кол-во повторов отсылки пакета.")]
        [DisplayName("Повторы посылки")]
        [TypeConverter(typeof(NumericUpDownTypeConverter))]
        [Editor(typeof(NumericUpDownTypeEditor), typeof(UITypeEditor)), MinMaxAttribute(1, 20)]
        public byte RetransmitCount { get { return Config.Instance.LoRaSettings.RetransmitCount; } set { Config.Instance.LoRaSettings.RetransmitCount = value; } }
        public bool ShouldSerializeRetransmitCount() { return false; }

        [Browsable(true)]
        [Category("1. Основные настройки")]
        [Description("Интервал отсыла информации с датчиков, с.")]
        [DisplayName("Интервал отсыла")]
        [TypeConverter(typeof(NumericUpDownTypeConverter))]
        [Editor(typeof(NumericUpDownTypeEditor), typeof(UITypeEditor)), MinMaxAttribute(5, 255)]
        public byte SendDuration { get { return Config.Instance.LoRaSettings.SendDuration; } set { Config.Instance.LoRaSettings.SendDuration = value; } }
        public bool ShouldSerializeSendDuration() { return false; }

        [Browsable(true)]
        [Category("2. Соединение")]
        [Description("Номер пина SS.")]
        [DisplayName("Пин SS")]
        [TypeConverter(typeof(NumericUpDownTypeConverter))]
        [Editor(typeof(NumericUpDownTypeEditor), typeof(UITypeEditor)), MinMaxAttribute(0, 255)]
        public byte SSPin { get { return Config.Instance.LoRaSettings.SSPin; } set { Config.Instance.LoRaSettings.SSPin = value; } }
        public bool ShouldSerializeSSPin() { return false; }

        [Browsable(true)]
        [Category("2. Соединение")]
        [Description("Номер пина RESET (255 - не назначен).")]
        [DisplayName("Пин RESET")]
        [TypeConverter(typeof(NumericUpDownTypeConverter))]
        [Editor(typeof(NumericUpDownTypeEditor), typeof(UITypeEditor)), MinMaxAttribute(0, 255)]
        public byte ResetPin { get { return Config.Instance.LoRaSettings.ResetPin; } set { Config.Instance.LoRaSettings.ResetPin = value; } }
        public bool ShouldSerializeResetPin() { return false; }

        [Browsable(true)]
        [Category("2. Соединение")]
        [Description("Номер пина DIO0.")]
        [DisplayName("Пин DIO0")]
        [TypeConverter(typeof(NumericUpDownTypeConverter))]
        [Editor(typeof(NumericUpDownTypeEditor), typeof(UITypeEditor)), MinMaxAttribute(0, 255)]
        public byte DIOPin { get { return Config.Instance.LoRaSettings.DIOPin; } set { Config.Instance.LoRaSettings.DIOPin = value; } }
        public bool ShouldSerializeDIOPin() { return false; }

    }

    public class ConfigGeneralSettings
    {

        [Browsable(true)]
        [Category("3. Температура")]
        [Description("Единицы измеряемой температуры.")]
        [DisplayName("Единицы измеряемой температуры")]
        [TypeConverter(typeof(MyEnumConverter))]
        public UnitTemperature TemperatureUnit { get { return Config.Instance.TemperatureUnit; } set { Config.Instance.TemperatureUnit = value;  } }
        public bool ShouldSerializeTemperatureUnit() { return false; }

        [Browsable(true)]
        [Category("4. Дополнительно")]
        [Description("Разделитель целой и дробной частей числа.")]
        [DisplayName("Разделитель целой и дробной частей")]
        //[ReadOnly(true)]
        public char FractDelimiter { get { return Config.Instance.FractDelimiter; } set { Config.Instance.FractDelimiter = value; } }
        public bool ShouldSerializeFractDelimiter() { return false; }

        [Browsable(true)]
        [Category("4. Дополнительно")]
        [Description("Интервал обновления датчиков, с.")]
        [DisplayName("Интервал обновления датчиков, с")]
        [TypeConverter(typeof(NumericUpDownTypeConverter))]
        [Editor(typeof(NumericUpDownTypeEditor), typeof(UITypeEditor)), MinMaxAttribute(0, 255)]
        public byte SensorsUpdateInterval { get { return Config.Instance.SensorsUpdateInterval; } set { Config.Instance.SensorsUpdateInterval = value; } }
        public bool ShouldSerializeSensorsUpdateInterval() { return false; }

        [Browsable(true)]
        [Category("1. Основные настройки")]
        [Description("Уникальный ID устройства в кластере.")]
        [DisplayName("ID устройства")]
        [TypeConverter(typeof(NumericUpDownTypeConverter))]
        [Editor(typeof(NumericUpDownTypeEditor), typeof(UITypeEditor)), MinMaxAttribute(0, 255)]
        public byte DeviceID { get { return Config.Instance.DeviceID; } set { Config.Instance.DeviceID = value; } }
        public bool ShouldSerializeDeviceID() { return false; }

        [Browsable(true)]
        [Category("1. Основные настройки")]
        [Description("ID кластера, к которому принадлежит устройство.")]
        [DisplayName("ID кластера")]
        [TypeConverter(typeof(NumericUpDownTypeConverter))]
        [Editor(typeof(NumericUpDownTypeEditor), typeof(UITypeEditor)), MinMaxAttribute(0, 255)]
        public byte ClusterID { get { return Config.Instance.ClusterID; } set { Config.Instance.ClusterID = value; } }
        public bool ShouldSerializeClusterID() { return false; }

        [Browsable(true)]
        [Category("5. Информация")]
        [Description("Количество свободной памяти, байт.")]
        [DisplayName("Память")]
        [ReadOnly(true)]
        public int FreeRAM { get { return Config.Instance.FreeRAM; }  }
        public bool ShouldSerializeFreeRAM() { return false; }

        [Browsable(true)]
        [Category("5. Информация")]
        [Description("Тип микроконтроллера, на который загружено ядро.")]
        [DisplayName("Микроконтроллер")]
        [ReadOnly(true)]
        public string Board { get { return EnumHelpers.GetEnumDescription(Config.Instance.Board); } }
        public bool ShouldSerializeBoard() { return false; }

        [Browsable(true)]
        [Category("5. Информация")]
        [Description("Версия ядра, используемого прошивкой.")]
        [DisplayName("Версия ядра")]
        [ReadOnly(true)]
        public string CoreVersion { get { return Config.Instance.CoreVersion; } }
        public bool ShouldSerializeCoreVersion() { return false; }

        [Browsable(true)]
        [Category("5. Информация")]
        [Description("Время, установленное на контроллере.")]
        [DisplayName("Время")]
        [ReadOnly(true)]
        public string ControllerDateTime
        {
            get
            {
                if (Config.Instance.ControllerDateTime.Length < 1)
                    return "-";

                return Config.Instance.ControllerDateTime;
            }

        }
        public bool ShouldSerializeControllerDateTime() { return false; }

        [Browsable(true)]
        [Category("2. Внешний ватчдог")]
        [Description("Использовать ли внешний ватчдог.")]
        [DisplayName("Ватчдог включен?")]
        [TypeConverter(typeof(YesNoConverter))]
        public bool WatchdogEnabled { get { return Config.Instance.WatchdogSettings.WatchdogEnabled; } set { Config.Instance.WatchdogSettings.WatchdogEnabled = value; } }
        public bool ShouldSerializeWatchdogEnabled() { return false; }

        [Browsable(true)]
        [Category("2. Внешний ватчдог")]
        [Description("Номер пина для внешнего ватчдога.")]
        [DisplayName("Пин ватчдога")]
        [TypeConverter(typeof(NumericUpDownTypeConverter))]
        [Editor(typeof(NumericUpDownTypeEditor), typeof(UITypeEditor)), MinMaxAttribute(0, 100)]
        public byte WatchdogPin { get { return Config.Instance.WatchdogSettings.WatchdogPin; } set { Config.Instance.WatchdogSettings.WatchdogPin = value; } }
        public bool ShouldSerializeWatchdogPin() { return false; }

        [Browsable(true)]
        [Category("2. Внешний ватчдог")]
        [Description("Интервал обновления ватчдога, миллисекунд.")]
        [DisplayName("Интервал обновления")]
        [TypeConverter(typeof(NumericUpDownTypeConverter))]
        [Editor(typeof(NumericUpDownTypeEditor), typeof(UITypeEditor)), MinMaxAttribute(0, 60000)]
        public ushort WatchdogInterval { get { return Config.Instance.WatchdogSettings.WatchdogInterval; } set { Config.Instance.WatchdogSettings.WatchdogInterval = value; } }
        public bool ShouldSerializeWatchdogInterval() { return false; }

        [Browsable(true)]
        [Category("2. Внешний ватчдог")]
        [Description("Время удержания сигнала высокого уровня, миллисекунд.")]
        [DisplayName("Длительность сигнала")]
        [TypeConverter(typeof(NumericUpDownTypeConverter))]
        [Editor(typeof(NumericUpDownTypeEditor), typeof(UITypeEditor)), MinMaxAttribute(0, 60000)]
        public ushort WatchdogPulseDuration { get { return Config.Instance.WatchdogSettings.WatchdogPulseDuration; } set { Config.Instance.WatchdogSettings.WatchdogPulseDuration = value; } }
        public bool ShouldSerializeWatchdogPulseDuration() { return false; }


    }

    public class FeaturesSettings
    {
        private bool espAvailable = false;
        public bool ESPAvailable { get { return espAvailable; } set { espAvailable = value; } }

        private bool signalsAvailable = false;
        public bool SignalsAvailable { get { return signalsAvailable; } set { signalsAvailable = value; } }

        private bool rs485Available = false;
        public bool RS485Available { get { return rs485Available; } set { rs485Available = value; } }

        private bool loraAvailable = false;
        public bool LoRaAvailable { get { return loraAvailable; } set { loraAvailable = value; } }

        private bool sdAvailable = false;
        public bool SDAvailable { get { return sdAvailable; } set { sdAvailable = value; } }

        public void Clear()
        {
            ESPAvailable = false;
            RS485Available = false;
            LoRaAvailable = false;
            SDAvailable = false;
            SignalsAvailable = false;
        }

    }

    public class Config
    {


        private static object lockFlag = new object();
        private static Config instance;

        public static Config Instance
        {
            get
            {
                lock (lockFlag)
                {
                    if (instance == null)
                    {
                       
                        instance = new Config();                     

                    } // if instance == null
                } // lock
                return instance;
            } // get

        }

        private Config()
        {
            FractDelimiter = ',';
            SensorsUpdateInterval = 5;
            TemperatureUnit = UnitTemperature.UnitCelsius;
        }

        public void Clear()
        {
            TemperatureUnit = UnitTemperature.UnitCelsius;
            FractDelimiter = ',';
            SensorsUpdateInterval = 5;
            DeviceID = 0;
            ClusterID = 0;
            Board = Boards.Mega;

            //rs485Packets.Clear();
            sensors.Clear();
            supportedSensors.Clear();
            signals.Clear();
        }

        private string coreVersion = "";
        public string CoreVersion { get { return coreVersion; } set { coreVersion = value; } }


        private UnitTemperature unitTemp = UnitTemperature.UnitCelsius;
        public UnitTemperature TemperatureUnit { get { return unitTemp; } set { unitTemp = value; } }

        private char fractDelim = ',';
        public char FractDelimiter { get { return fractDelim; } set { fractDelim = value; } }

        private byte updInterval = 5;
        public byte SensorsUpdateInterval { get { return updInterval; } set { updInterval = value; } }

        private byte deviceID = 0;
        public byte DeviceID { get { return deviceID; } set { deviceID = value; } }

        private byte clusterID = 0;
        public byte ClusterID { get { return clusterID; } set { clusterID = value; } }

        private Boards board = Boards.Mega;
        public Boards Board { get { return board; } set { board = value; } }

        private int freeram = 0;
        public int FreeRAM { get { return freeram; } set { freeram = value; } }

        private string controllerTime = "";
        public string ControllerDateTime { get { return controllerTime; } set { controllerTime = value; } }

        private ESPSettingsConfigData espSettings = new ESPSettingsConfigData();
        public ESPSettingsConfigData ESPSettings
        {
            get { return espSettings; }
            set { espSettings = value; }
        }

        private RS485SettingsConfigData rs485Settings = new RS485SettingsConfigData();
        public RS485SettingsConfigData RS485Settings
        {
            get { return rs485Settings; }
            set { rs485Settings = value; }
        }

        private WatchdogSettingsData watchdogSettings = new WatchdogSettingsData();
        public WatchdogSettingsData WatchdogSettings
        {
            get { return watchdogSettings; }
            set { watchdogSettings = value; }
        }

        /*
        private List<RS485IncomingPacketConfigData> rs485Packets = new List<RS485IncomingPacketConfigData>();
        public List<RS485IncomingPacketConfigData> RS485Packets
        {
            get { return rs485Packets; }
            set { rs485Packets = value; }
        }
        */

        private LoRaSettingsConfigData loraSettings = new LoRaSettingsConfigData();
        public LoRaSettingsConfigData LoRaSettings
        {
            get { return loraSettings; }
            set { loraSettings = value; }
        }

        private List<SensorConfigData> sensors = new List<SensorConfigData>();
        public List<SensorConfigData> Sensors
        {
            get { return sensors; }
            set { sensors = value; }
        }

        private List<CoreSensorType> supportedSensors = new List<CoreSensorType>();
        public List<CoreSensorType> SupportedSensors
        {
            get { return supportedSensors; }
            set { supportedSensors = value; }
        }

        private List<SignalConfigData> signals = new List<SignalConfigData>();
        public List<SignalConfigData> Signals
        {
            get { return signals; }
            set { signals = value; }
        }
    }

}
