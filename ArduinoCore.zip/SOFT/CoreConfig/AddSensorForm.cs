﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace CoreConfig
{
    public partial class AddSensorForm : Form
    {
        public AddSensorForm()
        {
            InitializeComponent();
        }

        public bool isAlphaNumeric(string strToCheck)
        {
            Regex rg = new Regex(@"^[a-zA-Z0-9\s,]*$");
            return rg.IsMatch(strToCheck);
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            SensorEditor ed = (SensorEditor)this.propertyGridSettings.SelectedObject;
            if (ed == null)
                return;

            ed.FillData();

            string sensorName = ed.SensorName.Trim();
            if(sensorName.Length < 1 || sensorName.Length > 9)
            {
                MessageBox.Show("Имя датчика должно быть от 1 до 9 символов длиной!", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if(!isAlphaNumeric(sensorName))
            {
                MessageBox.Show("Имя датчика должно содержать только латинские символы!", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;

            }

            SensorConfigData scd = new SensorConfigData();
            scd.SensorName = sensorName;
            scd.DataLength = ed.DataLength;
            scd.Data = ed.Data;
            scd.SensorType = ed.SensorType;

            Config.Instance.Sensors.Add(scd);


            // тут добавляем...

            DialogResult = DialogResult.OK;
        }

        private void AddSensorForm_Load(object sender, EventArgs e)
        {
            FillSensorsList();
        }

        private void FillSensorsList()
        {
            this.cbSensorsType.Items.Clear();
            foreach(CoreSensorType sensorType in Config.Instance.SupportedSensors)
            {
                this.cbSensorsType.Items.Add(new CoreSensorTypeHelper(sensorType));
            }

            if (this.cbSensorsType.Items.Count > 0)
                this.cbSensorsType.SelectedIndex = 0;
        }

        private void cbSensorsType_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.propertyGridSettings.SelectedObject = null;

            if (this.cbSensorsType.Items.Count < 1)
                return;

            CoreSensorTypeHelper helper = (CoreSensorTypeHelper)this.cbSensorsType.Items[this.cbSensorsType.SelectedIndex];

            switch(helper.SensorType)
            {
                case CoreSensorType.AnalogPortState:
                case CoreSensorType.DigitalPortState:
                case CoreSensorType.DS18B20:
                    {
                        PinNumberEditor ed = new PinNumberEditor(helper.SensorType);
                        this.propertyGridSettings.SelectedObject = ed;
                    }
                    break;

                case CoreSensorType.BH1750:
                    {
                        BH1750Editor ed = new BH1750Editor(helper.SensorType);
                        this.propertyGridSettings.SelectedObject = ed;
                    }
                    break;

                case CoreSensorType.DHT:
                    {
                       DHTEditor ed = new DHTEditor(helper.SensorType);
                        this.propertyGridSettings.SelectedObject = ed;

                    }
                    break;

                case CoreSensorType.DS3231:
                case CoreSensorType.DS3231Temperature:
                case CoreSensorType.Si7021:
                    {
                        I2CEditor ed = new I2CEditor(helper.SensorType);
                        this.propertyGridSettings.SelectedObject = ed;

                    }
                    break;

                case CoreSensorType.UserDataSensor:
                    {
                        UserdataSensorEditor ed = new UserdataSensorEditor(helper.SensorType);
                        this.propertyGridSettings.SelectedObject = ed;

                    }
                    break;
            }
        }
    }
}
