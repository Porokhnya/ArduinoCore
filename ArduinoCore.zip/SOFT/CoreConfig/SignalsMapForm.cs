﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CoreConfig
{
    public partial class SignalsMapForm : Form
    {
        private MainForm mainForm = null;
        public SignalsMapForm(MainForm fm)
        {
            InitializeComponent();

            mainForm = fm;

            int curNumber = 1;

            for(int i=0;i<8;i++)
            {
                dataGrid.Rows.Add();

                for(int k=0;k<dataGrid.Columns.Count;k++)
                {
                    dataGrid.Rows[i].Cells[k].Value = curNumber.ToString();
                    curNumber++;
                }
            }
        }

        private void SignalsMapForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            Hide();

            mainForm.StopQuerySignals();
        }

        public void ParseSignals(string sig)
        {
            
            int currentByteNum = 0;
            for(int i=0;i<sig.Length;i+=2, currentByteNum++)
            {
                string strByte = sig.Substring(i, 2);
                byte bByte = byte.Parse(strByte, System.Globalization.NumberStyles.HexNumber);

                // получили байт, смотрим его побитово
                for(byte k=0;k<8;k++)
                {
                    int signalNumber = currentByteNum * 8 + k;

                    int row = signalNumber / 10;
                    int col = signalNumber % 10;


                    if ((bByte & (1 << k))!= 0)
                    {
                        // signalNumber - взведён
                        this.dataGrid.Rows[row].Cells[col].Style.BackColor = Color.LightGreen;
                    }
                    else
                    {
                        // signalNumber - не взведён
                        this.dataGrid.Rows[row].Cells[col].Style.BackColor = Color.WhiteSmoke;
                    }
                }
            }

            this.dataGrid.Show();
        }

        private void dataGrid_SelectionChanged(object sender, EventArgs e)
        {
            dataGrid.ClearSelection();
        }
    }
}
