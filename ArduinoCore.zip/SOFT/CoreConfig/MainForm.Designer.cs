﻿namespace CoreConfig
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("Контроллер");
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.convertConfigToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.miSaveConfig = new System.Windows.Forms.ToolStripMenuItem();
            this.miHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.miAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip = new System.Windows.Forms.ToolStrip();
            this.btnConnect = new System.Windows.Forms.ToolStripDropDownButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolbarImages = new System.Windows.Forms.ImageList(this.components);
            this.tmProcessCommandsTimer = new System.Windows.Forms.Timer(this.components);
            this.tmGetSensorsData = new System.Windows.Forms.Timer(this.components);
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.treeView = new System.Windows.Forms.TreeView();
            this.smallImages = new System.Windows.Forms.ImageList(this.components);
            this.plSection = new System.Windows.Forms.Panel();
            this.plSDSettings = new System.Windows.Forms.Panel();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.treeViewSD = new System.Windows.Forms.TreeView();
            this.sdImagesNormal = new System.Windows.Forms.ImageList(this.components);
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnListSDFiles = new System.Windows.Forms.Button();
            this.richTextBoxFileView = new System.Windows.Forms.RichTextBox();
            this.plSensors = new System.Windows.Forms.Panel();
            this.lvSensorsList = new System.Windows.Forms.ListView();
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.sensorImages = new System.Windows.Forms.ImageList(this.components);
            this.plSensorsActions = new System.Windows.Forms.Panel();
            this.btnAddSensor = new System.Windows.Forms.Button();
            this.btnDeleteSensor = new System.Windows.Forms.Button();
            this.plESPSettings = new System.Windows.Forms.Panel();
            this.propertyGridESPSettings = new System.Windows.Forms.PropertyGrid();
            this.plRS485Settings = new System.Windows.Forms.Panel();
            this.propertyGridRS485Settings = new System.Windows.Forms.PropertyGrid();
            this.plLoRaSettings = new System.Windows.Forms.Panel();
            this.propertyGridLoRaSettings = new System.Windows.Forms.PropertyGrid();
            this.plStorage = new System.Windows.Forms.Panel();
            this.lvSensorsData = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.dataImages = new System.Windows.Forms.ImageList(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblCurrentSection = new System.Windows.Forms.Label();
            this.lvLog = new System.Windows.Forms.ListView();
            this.logColumn1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.logColumn2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tmDateTime = new System.Windows.Forms.Timer(this.components);
            this.plSignalsSettings = new System.Windows.Forms.Panel();
            this.lvSignals = new System.Windows.Forms.ListView();
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnDeleteSignal = new System.Windows.Forms.Button();
            this.btnAddSignal = new System.Windows.Forms.Button();
            this.plMainSettings = new System.Windows.Forms.Panel();
            this.propertyGridSettings = new System.Windows.Forms.PropertyGrid();
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnSignalsMap = new System.Windows.Forms.Button();
            this.btnExportConfig = new System.Windows.Forms.ToolStripButton();
            this.btnSetDateTime = new System.Windows.Forms.ToolStripButton();
            this.btnSaveConfig = new System.Windows.Forms.ToolStripButton();
            this.btnAbout = new System.Windows.Forms.ToolStripButton();
            this.tmSignals = new System.Windows.Forms.Timer(this.components);
            this.tmEnumComPorts = new System.Windows.Forms.Timer(this.components);
            this.menuStrip.SuspendLayout();
            this.toolStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.plSection.SuspendLayout();
            this.plSDSettings.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.plSensors.SuspendLayout();
            this.plSensorsActions.SuspendLayout();
            this.plESPSettings.SuspendLayout();
            this.plRS485Settings.SuspendLayout();
            this.plLoRaSettings.SuspendLayout();
            this.plStorage.SuspendLayout();
            this.panel1.SuspendLayout();
            this.plSignalsSettings.SuspendLayout();
            this.panel4.SuspendLayout();
            this.plMainSettings.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip
            // 
            this.statusStrip.Location = new System.Drawing.Point(0, 627);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(978, 22);
            this.statusStrip.TabIndex = 0;
            this.statusStrip.Text = "statusStrip1";
            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem,
            this.miHelp});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(978, 24);
            this.menuStrip.TabIndex = 1;
            this.menuStrip.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.fileToolStripMenuItem.Text = "Файл";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(108, 22);
            this.exitToolStripMenuItem.Text = "Выход";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.convertConfigToolStripMenuItem,
            this.miSaveConfig});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(70, 20);
            this.editToolStripMenuItem.Text = "Действия";
            // 
            // convertConfigToolStripMenuItem
            // 
            this.convertConfigToolStripMenuItem.Name = "convertConfigToolStripMenuItem";
            this.convertConfigToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.convertConfigToolStripMenuItem.Text = "Экспорт настроек";
            this.convertConfigToolStripMenuItem.Click += new System.EventHandler(this.convertConfigToolStripMenuItem_Click);
            // 
            // miSaveConfig
            // 
            this.miSaveConfig.Enabled = false;
            this.miSaveConfig.Name = "miSaveConfig";
            this.miSaveConfig.Size = new System.Drawing.Size(176, 22);
            this.miSaveConfig.Text = "Сохранить конфиг";
            this.miSaveConfig.Click += new System.EventHandler(this.btnSaveConfig_Click);
            // 
            // miHelp
            // 
            this.miHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miAbout});
            this.miHelp.Name = "miHelp";
            this.miHelp.Size = new System.Drawing.Size(68, 20);
            this.miHelp.Text = "Помощь";
            // 
            // miAbout
            // 
            this.miAbout.Name = "miAbout";
            this.miAbout.Size = new System.Drawing.Size(158, 22);
            this.miAbout.Text = "О программе...";
            this.miAbout.Click += new System.EventHandler(this.btnAbout_Click);
            // 
            // toolStrip
            // 
            this.toolStrip.ImageScalingSize = new System.Drawing.Size(48, 48);
            this.toolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnConnect,
            this.toolStripSeparator2,
            this.btnExportConfig,
            this.btnSetDateTime,
            this.btnSaveConfig,
            this.toolStripSeparator1,
            this.btnAbout});
            this.toolStrip.Location = new System.Drawing.Point(0, 24);
            this.toolStrip.Name = "toolStrip";
            this.toolStrip.Size = new System.Drawing.Size(978, 70);
            this.toolStrip.TabIndex = 2;
            // 
            // btnConnect
            // 
            this.btnConnect.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(79, 67);
            this.btnConnect.Text = "Соединить";
            this.btnConnect.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 70);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 70);
            // 
            // toolbarImages
            // 
            this.toolbarImages.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("toolbarImages.ImageStream")));
            this.toolbarImages.TransparentColor = System.Drawing.Color.Transparent;
            this.toolbarImages.Images.SetKeyName(0, "connect_no.png");
            this.toolbarImages.Images.SetKeyName(1, "connect_established.png");
            this.toolbarImages.Images.SetKeyName(2, "document_export.png");
            this.toolbarImages.Images.SetKeyName(3, "clock.png");
            this.toolbarImages.Images.SetKeyName(4, "save_config.png");
            this.toolbarImages.Images.SetKeyName(5, "messagebox_info.png");
            // 
            // tmProcessCommandsTimer
            // 
            this.tmProcessCommandsTimer.Enabled = true;
            this.tmProcessCommandsTimer.Tick += new System.EventHandler(this.tmProcessCommandsTimer_Tick);
            // 
            // tmGetSensorsData
            // 
            this.tmGetSensorsData.Enabled = true;
            this.tmGetSensorsData.Interval = 5000;
            this.tmGetSensorsData.Tick += new System.EventHandler(this.tmGetSensorsData_Tick);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 94);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.splitContainer2);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.lvLog);
            this.splitContainer1.Size = new System.Drawing.Size(978, 533);
            this.splitContainer1.SplitterDistance = 434;
            this.splitContainer1.TabIndex = 5;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.treeView);
            this.splitContainer2.Panel1MinSize = 150;
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.plSection);
            this.splitContainer2.Panel2.Controls.Add(this.panel1);
            this.splitContainer2.Panel2MinSize = 400;
            this.splitContainer2.Size = new System.Drawing.Size(978, 434);
            this.splitContainer2.SplitterDistance = 250;
            this.splitContainer2.TabIndex = 7;
            // 
            // treeView
            // 
            this.treeView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeView.ImageIndex = 0;
            this.treeView.ImageList = this.smallImages;
            this.treeView.Location = new System.Drawing.Point(0, 0);
            this.treeView.Name = "treeView";
            treeNode2.ImageIndex = 1;
            treeNode2.Name = "rootNode";
            treeNode2.Text = "Контроллер";
            this.treeView.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode2});
            this.treeView.SelectedImageIndex = 1;
            this.treeView.ShowPlusMinus = false;
            this.treeView.ShowRootLines = false;
            this.treeView.Size = new System.Drawing.Size(250, 434);
            this.treeView.TabIndex = 0;
            this.treeView.BeforeCollapse += new System.Windows.Forms.TreeViewCancelEventHandler(this.treeView_BeforeCollapse);
            this.treeView.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView_AfterSelect);
            // 
            // smallImages
            // 
            this.smallImages.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("smallImages.ImageStream")));
            this.smallImages.TransparentColor = System.Drawing.Color.Transparent;
            this.smallImages.Images.SetKeyName(0, "log.png");
            this.smallImages.Images.SetKeyName(1, "root.png");
            this.smallImages.Images.SetKeyName(2, "lora.png");
            this.smallImages.Images.SetKeyName(3, "rs485.png");
            this.smallImages.Images.SetKeyName(4, "esp.png");
            this.smallImages.Images.SetKeyName(5, "settings.png");
            this.smallImages.Images.SetKeyName(6, "data.png");
            this.smallImages.Images.SetKeyName(7, "sensors.png");
            this.smallImages.Images.SetKeyName(8, "sd.png");
            this.smallImages.Images.SetKeyName(9, "signal.png");
            // 
            // plSection
            // 
            this.plSection.Controls.Add(this.plSensors);
            this.plSection.Controls.Add(this.plSignalsSettings);
            this.plSection.Controls.Add(this.plMainSettings);
            this.plSection.Controls.Add(this.plLoRaSettings);
            this.plSection.Controls.Add(this.plStorage);
            this.plSection.Controls.Add(this.plSDSettings);
            this.plSection.Controls.Add(this.plESPSettings);
            this.plSection.Controls.Add(this.plRS485Settings);
            this.plSection.Dock = System.Windows.Forms.DockStyle.Fill;
            this.plSection.Location = new System.Drawing.Point(0, 40);
            this.plSection.Name = "plSection";
            this.plSection.Size = new System.Drawing.Size(724, 394);
            this.plSection.TabIndex = 1;
            // 
            // plSDSettings
            // 
            this.plSDSettings.Controls.Add(this.splitContainer3);
            this.plSDSettings.Location = new System.Drawing.Point(16, 18);
            this.plSDSettings.Name = "plSDSettings";
            this.plSDSettings.Size = new System.Drawing.Size(573, 364);
            this.plSDSettings.TabIndex = 6;
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Name = "splitContainer3";
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.treeViewSD);
            this.splitContainer3.Panel1.Controls.Add(this.panel2);
            this.splitContainer3.Panel1MinSize = 200;
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.richTextBoxFileView);
            this.splitContainer3.Panel2MinSize = 100;
            this.splitContainer3.Size = new System.Drawing.Size(573, 364);
            this.splitContainer3.SplitterDistance = 200;
            this.splitContainer3.TabIndex = 3;
            // 
            // treeViewSD
            // 
            this.treeViewSD.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeViewSD.HideSelection = false;
            this.treeViewSD.ImageIndex = 2;
            this.treeViewSD.ImageList = this.sdImagesNormal;
            this.treeViewSD.Location = new System.Drawing.Point(0, 0);
            this.treeViewSD.Name = "treeViewSD";
            this.treeViewSD.SelectedImageIndex = 0;
            this.treeViewSD.Size = new System.Drawing.Size(200, 317);
            this.treeViewSD.TabIndex = 1;
            this.treeViewSD.BeforeExpand += new System.Windows.Forms.TreeViewCancelEventHandler(this.treeViewSD_BeforeExpand);
            this.treeViewSD.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.treeViewSD_MouseDoubleClick);
            // 
            // sdImagesNormal
            // 
            this.sdImagesNormal.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("sdImagesNormal.ImageStream")));
            this.sdImagesNormal.TransparentColor = System.Drawing.Color.Transparent;
            this.sdImagesNormal.Images.SetKeyName(0, "folder-blue.png");
            this.sdImagesNormal.Images.SetKeyName(1, "document-open-folder.png");
            this.sdImagesNormal.Images.SetKeyName(2, "list.png");
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnListSDFiles);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 317);
            this.panel2.Name = "panel2";
            this.panel2.Padding = new System.Windows.Forms.Padding(0, 4, 0, 4);
            this.panel2.Size = new System.Drawing.Size(200, 47);
            this.panel2.TabIndex = 0;
            // 
            // btnListSDFiles
            // 
            this.btnListSDFiles.BackColor = System.Drawing.Color.LightGreen;
            this.btnListSDFiles.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnListSDFiles.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnListSDFiles.ForeColor = System.Drawing.Color.Black;
            this.btnListSDFiles.Location = new System.Drawing.Point(0, 4);
            this.btnListSDFiles.Name = "btnListSDFiles";
            this.btnListSDFiles.Size = new System.Drawing.Size(200, 39);
            this.btnListSDFiles.TabIndex = 3;
            this.btnListSDFiles.Text = "Перечитать SD";
            this.btnListSDFiles.UseVisualStyleBackColor = false;
            this.btnListSDFiles.Click += new System.EventHandler(this.btnListSDFiles_Click);
            // 
            // richTextBoxFileView
            // 
            this.richTextBoxFileView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBoxFileView.Location = new System.Drawing.Point(0, 0);
            this.richTextBoxFileView.Name = "richTextBoxFileView";
            this.richTextBoxFileView.Size = new System.Drawing.Size(369, 364);
            this.richTextBoxFileView.TabIndex = 0;
            this.richTextBoxFileView.Text = "";
            // 
            // plSensors
            // 
            this.plSensors.Controls.Add(this.lvSensorsList);
            this.plSensors.Controls.Add(this.plSensorsActions);
            this.plSensors.Location = new System.Drawing.Point(233, 6);
            this.plSensors.Name = "plSensors";
            this.plSensors.Size = new System.Drawing.Size(327, 275);
            this.plSensors.TabIndex = 5;
            // 
            // lvSensorsList
            // 
            this.lvSensorsList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7});
            this.lvSensorsList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvSensorsList.FullRowSelect = true;
            this.lvSensorsList.GridLines = true;
            this.lvSensorsList.HideSelection = false;
            this.lvSensorsList.Location = new System.Drawing.Point(0, 0);
            this.lvSensorsList.Name = "lvSensorsList";
            this.lvSensorsList.Size = new System.Drawing.Size(327, 228);
            this.lvSensorsList.SmallImageList = this.sensorImages;
            this.lvSensorsList.TabIndex = 1;
            this.lvSensorsList.UseCompatibleStateImageBehavior = false;
            this.lvSensorsList.View = System.Windows.Forms.View.Details;
            this.lvSensorsList.SelectedIndexChanged += new System.EventHandler(this.lvSensorsList_SelectedIndexChanged);
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Имя датчика";
            this.columnHeader5.Width = 150;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Тип датчика";
            this.columnHeader6.Width = 200;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Дополнительно";
            this.columnHeader7.Width = 330;
            // 
            // sensorImages
            // 
            this.sensorImages.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("sensorImages.ImageStream")));
            this.sensorImages.TransparentColor = System.Drawing.Color.Transparent;
            this.sensorImages.Images.SetKeyName(0, "any.png");
            // 
            // plSensorsActions
            // 
            this.plSensorsActions.Controls.Add(this.btnAddSensor);
            this.plSensorsActions.Controls.Add(this.btnDeleteSensor);
            this.plSensorsActions.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.plSensorsActions.Location = new System.Drawing.Point(0, 228);
            this.plSensorsActions.Name = "plSensorsActions";
            this.plSensorsActions.Padding = new System.Windows.Forms.Padding(0, 4, 4, 4);
            this.plSensorsActions.Size = new System.Drawing.Size(327, 47);
            this.plSensorsActions.TabIndex = 0;
            // 
            // btnAddSensor
            // 
            this.btnAddSensor.BackColor = System.Drawing.Color.LightGreen;
            this.btnAddSensor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddSensor.ForeColor = System.Drawing.Color.Black;
            this.btnAddSensor.Location = new System.Drawing.Point(159, 4);
            this.btnAddSensor.Name = "btnAddSensor";
            this.btnAddSensor.Size = new System.Drawing.Size(153, 37);
            this.btnAddSensor.TabIndex = 1;
            this.btnAddSensor.Text = "Добавить датчик";
            this.btnAddSensor.UseVisualStyleBackColor = false;
            this.btnAddSensor.Click += new System.EventHandler(this.btnAddSensor_Click);
            // 
            // btnDeleteSensor
            // 
            this.btnDeleteSensor.BackColor = System.Drawing.Color.LightSalmon;
            this.btnDeleteSensor.Enabled = false;
            this.btnDeleteSensor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDeleteSensor.ForeColor = System.Drawing.Color.Black;
            this.btnDeleteSensor.Location = new System.Drawing.Point(0, 4);
            this.btnDeleteSensor.Name = "btnDeleteSensor";
            this.btnDeleteSensor.Size = new System.Drawing.Size(153, 37);
            this.btnDeleteSensor.TabIndex = 0;
            this.btnDeleteSensor.Text = "Удалить датчик";
            this.btnDeleteSensor.UseVisualStyleBackColor = false;
            this.btnDeleteSensor.Click += new System.EventHandler(this.btnDeleteSensor_Click);
            // 
            // plESPSettings
            // 
            this.plESPSettings.Controls.Add(this.propertyGridESPSettings);
            this.plESPSettings.Location = new System.Drawing.Point(45, 145);
            this.plESPSettings.Name = "plESPSettings";
            this.plESPSettings.Size = new System.Drawing.Size(307, 198);
            this.plESPSettings.TabIndex = 4;
            // 
            // propertyGridESPSettings
            // 
            this.propertyGridESPSettings.CommandsVisibleIfAvailable = false;
            this.propertyGridESPSettings.Dock = System.Windows.Forms.DockStyle.Fill;
            this.propertyGridESPSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.propertyGridESPSettings.HelpBackColor = System.Drawing.Color.Cornsilk;
            this.propertyGridESPSettings.HelpForeColor = System.Drawing.Color.SteelBlue;
            this.propertyGridESPSettings.Location = new System.Drawing.Point(0, 0);
            this.propertyGridESPSettings.Name = "propertyGridESPSettings";
            this.propertyGridESPSettings.Size = new System.Drawing.Size(307, 198);
            this.propertyGridESPSettings.TabIndex = 1;
            // 
            // plRS485Settings
            // 
            this.plRS485Settings.Controls.Add(this.propertyGridRS485Settings);
            this.plRS485Settings.Location = new System.Drawing.Point(209, 98);
            this.plRS485Settings.Name = "plRS485Settings";
            this.plRS485Settings.Size = new System.Drawing.Size(307, 198);
            this.plRS485Settings.TabIndex = 3;
            // 
            // propertyGridRS485Settings
            // 
            this.propertyGridRS485Settings.CommandsVisibleIfAvailable = false;
            this.propertyGridRS485Settings.Dock = System.Windows.Forms.DockStyle.Fill;
            this.propertyGridRS485Settings.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.propertyGridRS485Settings.HelpBackColor = System.Drawing.Color.Cornsilk;
            this.propertyGridRS485Settings.HelpForeColor = System.Drawing.Color.SteelBlue;
            this.propertyGridRS485Settings.Location = new System.Drawing.Point(0, 0);
            this.propertyGridRS485Settings.Name = "propertyGridRS485Settings";
            this.propertyGridRS485Settings.Size = new System.Drawing.Size(307, 198);
            this.propertyGridRS485Settings.TabIndex = 1;
            // 
            // plLoRaSettings
            // 
            this.plLoRaSettings.Controls.Add(this.propertyGridLoRaSettings);
            this.plLoRaSettings.Location = new System.Drawing.Point(129, 206);
            this.plLoRaSettings.Name = "plLoRaSettings";
            this.plLoRaSettings.Size = new System.Drawing.Size(307, 198);
            this.plLoRaSettings.TabIndex = 2;
            // 
            // propertyGridLoRaSettings
            // 
            this.propertyGridLoRaSettings.CommandsVisibleIfAvailable = false;
            this.propertyGridLoRaSettings.Dock = System.Windows.Forms.DockStyle.Fill;
            this.propertyGridLoRaSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.propertyGridLoRaSettings.HelpBackColor = System.Drawing.Color.Cornsilk;
            this.propertyGridLoRaSettings.HelpForeColor = System.Drawing.Color.SteelBlue;
            this.propertyGridLoRaSettings.Location = new System.Drawing.Point(0, 0);
            this.propertyGridLoRaSettings.Name = "propertyGridLoRaSettings";
            this.propertyGridLoRaSettings.Size = new System.Drawing.Size(307, 198);
            this.propertyGridLoRaSettings.TabIndex = 1;
            // 
            // plStorage
            // 
            this.plStorage.Controls.Add(this.lvSensorsData);
            this.plStorage.Location = new System.Drawing.Point(442, 109);
            this.plStorage.Name = "plStorage";
            this.plStorage.Size = new System.Drawing.Size(255, 162);
            this.plStorage.TabIndex = 0;
            // 
            // lvSensorsData
            // 
            this.lvSensorsData.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4});
            this.lvSensorsData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvSensorsData.FullRowSelect = true;
            this.lvSensorsData.GridLines = true;
            this.lvSensorsData.HideSelection = false;
            this.lvSensorsData.Location = new System.Drawing.Point(0, 0);
            this.lvSensorsData.MultiSelect = false;
            this.lvSensorsData.Name = "lvSensorsData";
            this.lvSensorsData.Size = new System.Drawing.Size(255, 162);
            this.lvSensorsData.SmallImageList = this.dataImages;
            this.lvSensorsData.TabIndex = 7;
            this.lvSensorsData.UseCompatibleStateImageBehavior = false;
            this.lvSensorsData.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "#";
            this.columnHeader1.Width = 100;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Тип датчика";
            this.columnHeader2.Width = 180;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Тип показаний";
            this.columnHeader3.Width = 180;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Показания";
            this.columnHeader4.Width = 200;
            // 
            // dataImages
            // 
            this.dataImages.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("dataImages.ImageStream")));
            this.dataImages.TransparentColor = System.Drawing.Color.Transparent;
            this.dataImages.Images.SetKeyName(0, "analogport.png");
            this.dataImages.Images.SetKeyName(1, "datetime.png");
            this.dataImages.Images.SetKeyName(2, "digitalport.png");
            this.dataImages.Images.SetKeyName(3, "humidity.png");
            this.dataImages.Images.SetKeyName(4, "luminosity.png");
            this.dataImages.Images.SetKeyName(5, "temperature.png");
            this.dataImages.Images.SetKeyName(6, "userdata.png");
            // 
            // panel1
            // 
            this.panel1.AutoSize = true;
            this.panel1.BackColor = System.Drawing.Color.SteelBlue;
            this.panel1.Controls.Add(this.lblCurrentSection);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(724, 40);
            this.panel1.TabIndex = 0;
            // 
            // lblCurrentSection
            // 
            this.lblCurrentSection.AutoSize = true;
            this.lblCurrentSection.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblCurrentSection.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCurrentSection.ForeColor = System.Drawing.Color.White;
            this.lblCurrentSection.Location = new System.Drawing.Point(0, 0);
            this.lblCurrentSection.Margin = new System.Windows.Forms.Padding(0);
            this.lblCurrentSection.Name = "lblCurrentSection";
            this.lblCurrentSection.Padding = new System.Windows.Forms.Padding(10);
            this.lblCurrentSection.Size = new System.Drawing.Size(94, 40);
            this.lblCurrentSection.TabIndex = 0;
            this.lblCurrentSection.Text = "Данные";
            // 
            // lvLog
            // 
            this.lvLog.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.logColumn1,
            this.logColumn2});
            this.lvLog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvLog.FullRowSelect = true;
            this.lvLog.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None;
            this.lvLog.Location = new System.Drawing.Point(0, 0);
            this.lvLog.Name = "lvLog";
            this.lvLog.ShowGroups = false;
            this.lvLog.Size = new System.Drawing.Size(978, 95);
            this.lvLog.SmallImageList = this.smallImages;
            this.lvLog.TabIndex = 0;
            this.lvLog.UseCompatibleStateImageBehavior = false;
            this.lvLog.View = System.Windows.Forms.View.Details;
            // 
            // logColumn1
            // 
            this.logColumn1.Width = 200;
            // 
            // tmDateTime
            // 
            this.tmDateTime.Enabled = true;
            this.tmDateTime.Interval = 1000;
            this.tmDateTime.Tick += new System.EventHandler(this.tmDateTime_Tick);
            // 
            // plSignalsSettings
            // 
            this.plSignalsSettings.Controls.Add(this.lvSignals);
            this.plSignalsSettings.Controls.Add(this.panel4);
            this.plSignalsSettings.Location = new System.Drawing.Point(46, 93);
            this.plSignalsSettings.Name = "plSignalsSettings";
            this.plSignalsSettings.Size = new System.Drawing.Size(632, 209);
            this.plSignalsSettings.TabIndex = 8;
            // 
            // lvSignals
            // 
            this.lvSignals.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader8,
            this.columnHeader9,
            this.columnHeader11,
            this.columnHeader10,
            this.columnHeader12,
            this.columnHeader13});
            this.lvSignals.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvSignals.FullRowSelect = true;
            this.lvSignals.GridLines = true;
            this.lvSignals.HideSelection = false;
            this.lvSignals.LabelWrap = false;
            this.lvSignals.Location = new System.Drawing.Point(0, 0);
            this.lvSignals.MultiSelect = false;
            this.lvSignals.Name = "lvSignals";
            this.lvSignals.ShowItemToolTips = true;
            this.lvSignals.Size = new System.Drawing.Size(632, 162);
            this.lvSignals.SmallImageList = this.smallImages;
            this.lvSignals.TabIndex = 8;
            this.lvSignals.UseCompatibleStateImageBehavior = false;
            this.lvSignals.View = System.Windows.Forms.View.Details;
            this.lvSignals.SelectedIndexChanged += new System.EventHandler(this.lvSignals_SelectedIndexChanged);
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Имя датчика";
            this.columnHeader8.Width = 100;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "Оператор";
            this.columnHeader9.Width = 130;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.panel3);
            this.panel4.Controls.Add(this.btnDeleteSignal);
            this.panel4.Controls.Add(this.btnAddSignal);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(0, 162);
            this.panel4.Name = "panel4";
            this.panel4.Padding = new System.Windows.Forms.Padding(0, 4, 0, 4);
            this.panel4.Size = new System.Drawing.Size(632, 47);
            this.panel4.TabIndex = 1;
            // 
            // btnDeleteSignal
            // 
            this.btnDeleteSignal.BackColor = System.Drawing.Color.LightSalmon;
            this.btnDeleteSignal.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnDeleteSignal.Enabled = false;
            this.btnDeleteSignal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDeleteSignal.ForeColor = System.Drawing.Color.Black;
            this.btnDeleteSignal.Location = new System.Drawing.Point(0, 4);
            this.btnDeleteSignal.Name = "btnDeleteSignal";
            this.btnDeleteSignal.Size = new System.Drawing.Size(153, 37);
            this.btnDeleteSignal.TabIndex = 4;
            this.btnDeleteSignal.Text = "Удалить сигнал";
            this.btnDeleteSignal.UseVisualStyleBackColor = false;
            this.btnDeleteSignal.Click += new System.EventHandler(this.btnDeleteSignal_Click);
            // 
            // btnAddSignal
            // 
            this.btnAddSignal.BackColor = System.Drawing.Color.LightGreen;
            this.btnAddSignal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddSignal.ForeColor = System.Drawing.Color.Black;
            this.btnAddSignal.Location = new System.Drawing.Point(159, 4);
            this.btnAddSignal.Name = "btnAddSignal";
            this.btnAddSignal.Size = new System.Drawing.Size(153, 37);
            this.btnAddSignal.TabIndex = 3;
            this.btnAddSignal.Text = "Добавить сигнал";
            this.btnAddSignal.UseVisualStyleBackColor = false;
            this.btnAddSignal.Click += new System.EventHandler(this.btnAddSignal_Click);
            // 
            // plMainSettings
            // 
            this.plMainSettings.Controls.Add(this.propertyGridSettings);
            this.plMainSettings.Location = new System.Drawing.Point(205, 131);
            this.plMainSettings.Name = "plMainSettings";
            this.plMainSettings.Size = new System.Drawing.Size(314, 133);
            this.plMainSettings.TabIndex = 9;
            // 
            // propertyGridSettings
            // 
            this.propertyGridSettings.CommandsVisibleIfAvailable = false;
            this.propertyGridSettings.Dock = System.Windows.Forms.DockStyle.Fill;
            this.propertyGridSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.propertyGridSettings.HelpBackColor = System.Drawing.Color.Cornsilk;
            this.propertyGridSettings.HelpForeColor = System.Drawing.Color.SteelBlue;
            this.propertyGridSettings.Location = new System.Drawing.Point(0, 0);
            this.propertyGridSettings.Name = "propertyGridSettings";
            this.propertyGridSettings.Size = new System.Drawing.Size(314, 133);
            this.propertyGridSettings.TabIndex = 0;
            this.propertyGridSettings.PropertyValueChanged += new System.Windows.Forms.PropertyValueChangedEventHandler(this.propertyGridSettings_PropertyValueChanged);
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Расписание?";
            this.columnHeader10.Width = 90;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "Данные";
            this.columnHeader11.Width = 150;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "Дни";
            this.columnHeader12.Width = 100;
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "Действий";
            this.columnHeader13.Width = 80;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btnSignalsMap);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel3.Location = new System.Drawing.Point(449, 4);
            this.panel3.Margin = new System.Windows.Forms.Padding(0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(183, 39);
            this.panel3.TabIndex = 5;
            // 
            // btnSignalsMap
            // 
            this.btnSignalsMap.BackColor = System.Drawing.Color.SteelBlue;
            this.btnSignalsMap.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSignalsMap.ForeColor = System.Drawing.Color.White;
            this.btnSignalsMap.Location = new System.Drawing.Point(27, 0);
            this.btnSignalsMap.Name = "btnSignalsMap";
            this.btnSignalsMap.Size = new System.Drawing.Size(152, 37);
            this.btnSignalsMap.TabIndex = 4;
            this.btnSignalsMap.Text = "Карта сигналов";
            this.btnSignalsMap.UseVisualStyleBackColor = false;
            this.btnSignalsMap.Click += new System.EventHandler(this.btnSignalsMap_Click);
            // 
            // btnExportConfig
            // 
            this.btnExportConfig.Image = ((System.Drawing.Image)(resources.GetObject("btnExportConfig.Image")));
            this.btnExportConfig.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnExportConfig.Name = "btnExportConfig";
            this.btnExportConfig.Size = new System.Drawing.Size(109, 67);
            this.btnExportConfig.Text = "Экспорт настроек";
            this.btnExportConfig.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnExportConfig.ToolTipText = "Экспорт конфига в текст";
            this.btnExportConfig.Click += new System.EventHandler(this.convertConfigToolStripMenuItem_Click);
            // 
            // btnSetDateTime
            // 
            this.btnSetDateTime.Image = ((System.Drawing.Image)(resources.GetObject("btnSetDateTime.Image")));
            this.btnSetDateTime.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSetDateTime.Name = "btnSetDateTime";
            this.btnSetDateTime.Size = new System.Drawing.Size(75, 67);
            this.btnSetDateTime.Text = "Дата/время";
            this.btnSetDateTime.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnSetDateTime.ToolTipText = "Установить дату/время на контроллере";
            this.btnSetDateTime.Click += new System.EventHandler(this.btnSetDateTime_Click);
            // 
            // btnSaveConfig
            // 
            this.btnSaveConfig.Enabled = false;
            this.btnSaveConfig.Image = ((System.Drawing.Image)(resources.GetObject("btnSaveConfig.Image")));
            this.btnSaveConfig.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSaveConfig.Name = "btnSaveConfig";
            this.btnSaveConfig.Size = new System.Drawing.Size(113, 67);
            this.btnSaveConfig.Text = "Сохранить конфиг";
            this.btnSaveConfig.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnSaveConfig.ToolTipText = "Сохранить конфиг в контроллер";
            this.btnSaveConfig.Click += new System.EventHandler(this.btnSaveConfig_Click);
            // 
            // btnAbout
            // 
            this.btnAbout.Image = ((System.Drawing.Image)(resources.GetObject("btnAbout.Image")));
            this.btnAbout.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAbout.Name = "btnAbout";
            this.btnAbout.Size = new System.Drawing.Size(86, 67);
            this.btnAbout.Text = "О программе";
            this.btnAbout.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnAbout.Click += new System.EventHandler(this.btnAbout_Click);
            // 
            // tmSignals
            // 
            this.tmSignals.Interval = 1000;
            this.tmSignals.Tick += new System.EventHandler(this.tmSignals_Tick);
            // 
            // tmEnumComPorts
            // 
            this.tmEnumComPorts.Enabled = true;
            this.tmEnumComPorts.Interval = 2000;
            this.tmEnumComPorts.Tick += new System.EventHandler(this.tmEnumComPorts_Tick);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(978, 649);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.toolStrip);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.menuStrip);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip;
            this.MinimumSize = new System.Drawing.Size(800, 600);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Конфигуратор ArduinoCore";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.Resize += new System.EventHandler(this.MainForm_Resize);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.toolStrip.ResumeLayout(false);
            this.toolStrip.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.plSection.ResumeLayout(false);
            this.plSDSettings.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.plSensors.ResumeLayout(false);
            this.plSensorsActions.ResumeLayout(false);
            this.plESPSettings.ResumeLayout(false);
            this.plRS485Settings.ResumeLayout(false);
            this.plLoRaSettings.ResumeLayout(false);
            this.plStorage.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.plSignalsSettings.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.plMainSettings.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStrip toolStrip;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripDropDownButton btnConnect;
        private System.Windows.Forms.ImageList toolbarImages;
        private System.Windows.Forms.Timer tmProcessCommandsTimer;
        private System.Windows.Forms.Timer tmGetSensorsData;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem convertConfigToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton btnExportConfig;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.Panel plSection;
        private System.Windows.Forms.Panel plStorage;
        private System.Windows.Forms.ListView lvSensorsData;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblCurrentSection;
        private System.Windows.Forms.TreeView treeView;
        private System.Windows.Forms.Panel plLoRaSettings;
        private System.Windows.Forms.Timer tmDateTime;
        private System.Windows.Forms.ToolStripButton btnSetDateTime;
        private System.Windows.Forms.ListView lvLog;
        private System.Windows.Forms.ColumnHeader logColumn1;
        private System.Windows.Forms.ColumnHeader logColumn2;
        private System.Windows.Forms.ImageList smallImages;
        private System.Windows.Forms.PropertyGrid propertyGridLoRaSettings;
        private System.Windows.Forms.Panel plRS485Settings;
        private System.Windows.Forms.PropertyGrid propertyGridRS485Settings;
        private System.Windows.Forms.Panel plESPSettings;
        private System.Windows.Forms.PropertyGrid propertyGridESPSettings;
        private System.Windows.Forms.Panel plSensors;
        private System.Windows.Forms.Panel plSensorsActions;
        private System.Windows.Forms.ListView lvSensorsList;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.Button btnDeleteSensor;
        private System.Windows.Forms.Button btnAddSensor;
        private System.Windows.Forms.ToolStripButton btnSaveConfig;
        private System.Windows.Forms.ImageList dataImages;
        private System.Windows.Forms.ToolStripMenuItem miSaveConfig;
        private System.Windows.Forms.ImageList sensorImages;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton btnAbout;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem miHelp;
        private System.Windows.Forms.ToolStripMenuItem miAbout;
        private System.Windows.Forms.Panel plSDSettings;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.TreeView treeViewSD;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnListSDFiles;
        private System.Windows.Forms.ImageList sdImagesNormal;
        private System.Windows.Forms.RichTextBox richTextBoxFileView;
        private System.Windows.Forms.Panel plSignalsSettings;
        private System.Windows.Forms.ListView lvSignals;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnDeleteSignal;
        private System.Windows.Forms.Button btnAddSignal;
        private System.Windows.Forms.Panel plMainSettings;
        private System.Windows.Forms.PropertyGrid propertyGridSettings;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnSignalsMap;
        private System.Windows.Forms.Timer tmSignals;
        private System.Windows.Forms.Timer tmEnumComPorts;
    }
}

