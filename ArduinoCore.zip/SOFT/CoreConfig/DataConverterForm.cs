﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CoreConfig
{
    public partial class DataConverterForm : Form
    {
        public DataConverterForm()
        {
            InitializeComponent();
            cbDataType.SelectedIndex = 0;
            cbDigitalportEditor.SelectedIndex = 0;

            ChangeEditors();
        }

        public string DataConverted = "";

        private void HideAllEditors()
        {
            nudTemperatureEditor.Visible = false;
            nudHumidityEditor.Visible = false;
            nudLuminosityEditor.Visible = false;
            cbDigitalportEditor.Visible = false;
            nudAnalogEditor.Visible = false;
        }
        private void ChangeEditors()
        {
            HideAllEditors();

            switch(cbDataType.SelectedIndex)
            {
                case 0: // Температура
                    nudTemperatureEditor.Visible = true;
                    break;

                case 1: // Влажность
                    nudHumidityEditor.Visible = true;
                    break;

                case 2: // Освещённость
                    nudLuminosityEditor.Visible = true;
                    break;

                case 3: //Состояние цифрового порта
                    cbDigitalportEditor.Visible = true;
                    break;

                case 4: // Состояние аналогового порта
                    nudAnalogEditor.Visible = true;
                    break;
                    
            } // switch
        }

        private void parseTemperature(decimal val, bool isHumidity = false)
        {
            try
            {
                val *= 100;
                int iVal = Convert.ToInt16(val);
                byte tValue = 0;
                if (iVal >= 0)
                    tValue = Convert.ToByte(iVal / 100);
                else
                {
                    sbyte sb = Convert.ToSByte(iVal / 100);
                    tValue = (byte)sb;
                }
                byte tFract = Convert.ToByte(Math.Abs(iVal)%100);

                DataConverted = tValue.ToString("X2") + tFract.ToString("X2");
                if(isHumidity)
                    DataConverted += "01";
                else
                    DataConverted += "00";
            }
            catch { }

        }

        private void parseHumidity(decimal val)
        {
            parseTemperature(val, true);

        }

        private void parseLuminosity(decimal val)
        {
            try
            {
                int iVal = Convert.ToInt32(val);
                byte[] bytes = BitConverter.GetBytes(iVal);
                for (int i = 0; i < bytes.Length; i++)
                    DataConverted += bytes[i].ToString("X2");
            }
            catch { }
        }

        private void parseDigitalPort()
        {
            DataConverted = "0" + cbDigitalportEditor.SelectedIndex.ToString();
        }

        private void parseAnalogPort(decimal val)
        {
            try
            {
                UInt16 iVal = Convert.ToUInt16(val);
                byte[] bytes = BitConverter.GetBytes(iVal);
                for (int i = 0; i < bytes.Length; i++)
                    DataConverted += bytes[i].ToString("X2");
            }
            catch { }
        }

        private void TryParseData()
        {
            DataConverted = "";
            switch (cbDataType.SelectedIndex)
            {
                case 0: // Температура
                    parseTemperature(nudTemperatureEditor.Value);
                    break;

                case 1: // Влажность
                    parseHumidity(nudHumidityEditor.Value);
                    break;

                case 2: // Освещённость
                    parseLuminosity(nudLuminosityEditor.Value);
                    break;

                case 3: //Состояние цифрового порта
                    parseDigitalPort();
                    break;

                case 4: // Состояние аналогового порта
                    parseAnalogPort(nudAnalogEditor.Value);
                    break;

            } // switch
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            TryParseData();
            DialogResult = DialogResult.OK;
        }

        private void cbDataType_SelectedIndexChanged(object sender, EventArgs e)
        {
            ChangeEditors();
        }
    }
}
